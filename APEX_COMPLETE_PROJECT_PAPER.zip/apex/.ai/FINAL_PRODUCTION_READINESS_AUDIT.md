# FINAL PRODUCTION-READINESS ADVERSARIAL AUDIT

- **Date:** 2026-09-06
- **Scope:** `/home/apex/apex` @ `main` (HEAD `49f4433` — working tree clean)
- **Audit mode:** READ-ONLY. No files modified, no commits made, no refactors, no fixes.
  The single permitted write is this report.
- **Baseline:** 621 tests passing, ruff clean, mypy clean (src/tests/scripts), `git diff --check` clean.
- **System under test:** APEX 24/7 paper/shadow crypto-futures research runtime
  (engine → scanner → orchestrator → detector → OEM → PaperExecutionAdapter →
  PositionTracker → PersistentJournal; crash recovery in `engine.start()`).
- **Key invariant tested:** live/production/real trading is permanently out of scope
  and must be impossible at every layer (config, endpoint, adapter, HTTP, credentials).

---

## A. EXECUTIVE VERDICT

### `READY_WITH_NONBLOCKING_FINDINGS`

**Statement:** The system is ready for human-held production checkpoint review modulo
the non-blocking findings below. **No finding permits or enables real-money trading:
there is no live path anywhere** (see Section D, items 1–3). The mandatory safety
chain (Signal → Idempotency → Kill Switch → Risk Guardian → Endpoint Guard →
Exec Adapter) is intact, fail-closed, and adversarial probes confirmed that
duplicate execution, OEM bypass, concurrency races, and stale-data exits cannot
occur in the paper runtime.

**Three medium findings must be triaged before relying on long-run paper study
results** (they degrade research validity and observability, not exchange safety):

1. **DATA-1** — Total silent data loss (full-universe SKIPPED) reads as `HEALTHY`.
2. **DATA-3** — The entry path disables the freshness gate (`check_fresh=False`).
3. **REC-1** — A crash between `PAPER_FILL` and the OPEN snapshot silently drops a
   filled paper position from recovery (never refired, never flagged).

These are plain-language confirmations of current behavior; per audit instructions
NOTHING was changed and no remediation code was written.

---

## B. FINDINGS TABLE

Severity key: **B**=Blocking (real-money risk / safety-bypass), **M**=Medium (correctness/observability/durability gap, no real-money exposure),
**L**=Low (robustness/defense-in-depth), **OK**=verified sound.

| ID | SEV | AREA | FILE:LINE | FAILURE / ATTACK SCENARIO | CURRENT BEHAVIOR | EXPECTED SAFE BEHAVIOR | EVIDENCE | REMEDIATION | TEST REQUIRED |
|---|---|---|---|---|---|---|---|---|---|
| DATA-1 | **M** | Data-failure gating | `runtime/scanner.py:178-183` (SKIPPED), `:146-153` (counters exclude SKIPPED); `runtime/health.py` `NO_DATA` requires `consecutive_data>0` | Market-data provider returns `None` for every symbol (silent HTTP failure inside `_ScannerProvider.get_series`). With zero open positions the operator keeps seeing `HEALTHY` while the system is fully blind. | Symbol → outcome `SKIPPED`; SKIPPED is neither `errors` nor `data_quality_failures`; scan summary shows "no data" only via `symbol_results`. Probe 1: scan with `symbols_total=2, usable=0, data_failed=False` → `HEALTHY`. | A total-data-loss tick must be counted as a data failure so `consecutive_data` rises and `NO_DATA` triggers (fail in the direction of "untrusted data"). | Probe 1 output (HEALTHY on usable=0); `health.py` NO_DATA gating requires `consecutive_data > 0`; `scanner.py:146-153` drops `SKIPPED` from tallies. | Count `SKIPPED` (usable-series gap) into the health record at engine level; or surface equity/data-channel errors as hard failures instead of `None`. | Health test: full-universe silent skip → `data_health != HEALTHY` within `max` consecutive ticks. |
| DATA-3 | **M** | Entry staleness | `runtime/orchestrator.py:153-156` | Network partitions silently stall the feed; the stale-but-closed candle still passes quality because `check_fresh=False` — entries are authored from old candles while "health" stays green. | `run_quality_gate(list(series.candles), check_fresh=False)` — only format/interval/ordering are checked; freshness is never asserted on the entry path (management/danger path gates staleness separately). Defaults also assume H1 while runtime is M5. | Entry signals must be rejected when the last closed candle is older than a freshness bound; staleness on entry must increase `data_failed`. | `orchestrator.py:153-156`; `market/quality.py:226-231` defaults; management-side staleness lives in `runtime/danger_manager.py`. | Pass M5 `expected_interval_ms` and `check_fresh=True` (or an M5 freshness bound) on the entry quality gate; treat staleness as data failure. | Test: candle 30+ min old at M5 → `DataQualityFailed`, no `SignalAccepted`, health records `data_failed`. |
| DATA-2 | **L** | Observability | `runtime/scanner.py:134-138` | Equity provider raises (e.g. account fetch fails). | `equity = self._equity_provider()` wrapped in `try/except Exception: equity = 0.0`; scan proceeds with `equity_used=0.0`. Downstream, risk/geometry fail-closed per symbol, but the failure is silent at the scan root. | Fail the tick as a data/account-fetch failure (count it) instead of silently continuing with `0.0`. | `scanner.py:134-138`. | Let the exception propagate to a flagged scan or record a `data_failed` tick from equity fetch. | Test: equity_provider raises → scan result `errors>0` and health records data failure. |
| EXEC-1 | **L** | Execution atomicity | `execution/oem.py:135-142` | Adapter raise between Step 6 (record key) and Step 7 (`adapter.execute`). | Idempotency key is registered BEFORE dispatch. Adapter raise → event permanently consumed: no execution, no retry (`DuplicateEventError` on retry). Fail-closed against double-execution; at-least-once semantics lost. Unreachable in shipped config: `PaperExecutionAdapter.execute` never raises (orders.py paper engine), `paper_service` journals `EXECUTION_ERROR` instead. | Decide the write-ordering trade-off explicitly; ideally claim after an "execute intent to local journal" boundary so a raise leaves the event replayable; or document the availability trade-off. | Probe 3: adapter raised → `guard.is_duplicate(key)=True`, re-execution rejected `DuplicateEventError`. `oem.py:135-142`. | If real adapters are ever added: persist the event pre-claim or make execution failure un-claim. | Test: raising adapter → no execution, retry allowed OR documented fail-closed semantics. |
| DUR-1 | **M** | SQLite durability | `persistence/journal.py:110-115` | Journal database grows in DELETE journal mode with `foreign_keys=OFF` while the two sibling stores are WAL+FK-ON. | `_connect()` sets only `row_factory`. Probe 2: `journal_mode=delete`, `synchronous=2` (FULL — committed writes ARE durable), `foreign_keys=0`. | Consistency with `safety/idempotency.py:108-110` and `journal/repository.py:92-94` (both `journal_mode=WAL` + `foreign_keys=ON`); WAL gives concurrent-reader safety and crash containment. | Probe 2 `PersistentJournal` row. | Set `PRAGMA journal_mode=WAL`, `PRAGMA foreign_keys=ON` in `_connect`; add schema FKs where enforced. | Test: pragma assertions on connect + crash-consistency round-trip. |
| REC-1 | **M** | Crash recovery | `persistence/recovery.py:99-112`; paper path in `runtime/engine.py` | Crash lands between `append_execution_event(PAPER_FILL)` and `upsert_position_snapshot(OPEN)`. | On restart: snapshot list has no OPEN entry → position not reconstructed; idempotency key IS reconstructed from the fill (no refire); nothing is flagged as needing reconciliation. The filled position silently vanishes. | A PAPER_FILL with no matching OPEN snapshot must be marked `reconciliation_failures` (fail closed) or have its snapshot reconstructed from the intent. | `recovery.py:99-112` (only snapshots drive reconstruction); step 3 replays fills; `engine.py:452-463` only aborts on corrupt snapshots/reconcil fail. | Add "fill present, snapshot absent" reconciliation detection. | Test: journal with fill-only for symbol → recovery flags reconciliation, engine refuses autonomous start. |
| REC-2 | **L** | Recovery idempotency | `persistence/recovery.py:187-210` | Event whose intent_id/metadata is unparseable (legacy/corrupt) during idempotency reconstruction. | Event skipped with a `messages` note; `keys_reconstructed` unchanged; no failure counter. A skipped key means the same signal is NOT deduped across restart → risk of duplicate execution (only for corrupted legacy events; current pipeline always embeds `idempotency_key` metadata). | Unparseable executed events must count as `reconciliation_failures` (fail closed). | `recovery.py:187-210`. | Count skipped events as failures. | Test: event with garbage intent_id → `reconciliation_failures>0`. |
| REC-3 | L | Recovery fidelity | `persistence/recovery.py:243-263` | Restore drops `breakeven_moved`/`danger_level`/`unrealized_pnl` (fields `create_position` cannot carry). | A stop moved to breakeven before a crash would silently revert to the original SL after restart. **No current runtime impact** — neither `engine.py` nor `danger_manager.py` ever calls `apply_breakeven` (flag is computed, never applied; verified by grep). | Persist the full position tuple on snapshot so restored positions are byte-identical. | `recovery.py:243-263`; grep: no `apply_breakeven` callers in runtime. | Extend snapshot payload when breakeven/trailing becomes live. | Minor; no test today. |
| JRN-1 | **OK** | Trade-journal integrity | `journal/models.py` `record_hash`; `journal/repository.py:83-109` | Duplicate append or hash collision across distinct trades. | Semantic identity = symbol+side+mode+entry/exit/stop/tp+risk_per_unit+realized_pnl+opened/closed. Distinct legit trades cannot collide (`opened_at_ms` differs; signal dedup key `symbol:candle_ts:detector_version`). Duplicate append rejected (`TradeJournalError`); later distinct close accepted. Probe 5. | Append-only, `UNIQUE(record_hash)`, lock+sqlite serialization, malformed rows raise (fail closed). | Probe 5: dup rejected, distinct later close allowed, count=2. | None. | Covered by existing tests + probe. |
| JRN-2 | **OK** | Journal durability | `journal/repository.py:92-94` | — | `journal_mode=WAL`, `synchronous=2`, `foreign_keys=ON`, `busy_timeout=5000`. | — | Probe 2 `TradeJournal` row. | None. | Covered. |

---

## C. EXECUTION TRACES

### TRACE 1 — Signal → Entry → Position (paper, normal)
```
Scheduler.tick()  (runtime/scheduler.py: closed-candle guard, no overlap)
 → Engine._scan_tick()  (runtime/engine.py)
 → Scanner.scan_once()  (runtime/scanner.py:118)
   → _ScannerProvider.get_series → closed candles (reject_open=True)
   → Orchestrator.evaluate (runtime/orchestrator.py:148): run_quality_gate(check_fresh=False) → Detector(signal) → SignalAccepted
 → on_signal → SignalBridge authors OrderIntent (geometry validated)
 → Engine collects orders (engine.py) → OEM.execute_order(intent, portfolio)
   OEM Step1 intent.check_geometry()
   OEM Step2 IdempotencyGuard.compute_event_key + is_duplicate()           [oem.py:101-110]
   OEM Step3 KillSwitch.validate_can_enter()          (ENTRY; blocked when ACTIVE)   [oem.py:113-114]
   OEM Step4 RiskGuardian.evaluate → veto allowed?                             [oem.py:125-127]
   OEM Step5 EndpointGuard.validate_order_routing(mode=PAPER)                 [oem.py:130-133]
   OEM Step6 record_event(key)                                                 [oem.py:136-139]
   OEM Step7 PaperExecutionAdapter.execute → deterministic paper fill → ExecutionReceipt   [oem.py:142]
 → PaperService.handle_execution_receipt → PositionTracker.adopt_position → Position(OPEN)
 → PersistentJournal.append_execution_event(PAPER_FILL) + upsert_position_snapshot(OPEN)
 → (closed candles only; no lookahead anywhere)
```
Adversarial probe: concurrent entry of the same key → exactly one `claimed`, all others rejected (Probe 4).

### TRACE 2 — Exit (danger manager) → Position close → Journal
```
Engine._scan_tick → _manage_open_positions()  (runtime/engine.py; runs BEFORE entries)
 → DangerManager.evaluate (runtime/danger_manager.py) — no direct adapter; prep risk + safety fast path
   hard SL/TP from Position (danger.py) → DangerAction SL_HIT / TP_HIT / FAIL_SAFE_CLOSE / STALE
   CRITICAL danger → force exit; WATCH → status change; freshness/staleness thresholds enforced
 → DangerManager.close_position_through_oem → OrderIntent(EXIT) → OEM (same chain as Trace 1,
   Step 3 now uses can_cancel_or_flatten — flattening NEVER blocked by kill switch)  [oem.py:116-122]
 → PaperExecutionAdapter.execute → receipt
 → PositionTracker.close_position (close_reason, realized_pnl, quantity_to_close=remaining)
 → PersistentJournal.append_execution_event(PAPER_EXIT) + upsert_position_snapshot(CLOSED)
 → TradeJournal.append(from_closed_position) → closed_trades registry (exit_reason, receipt_id,
   strategy_version, duration_ms, r_multiple)  [wal+FK-ON, UNIQUE record_hash]
```
Grep proof: `_adapter.execute` is invoked from exactly one place — `oem.py:142`.
No exit path bypasses the OEM chain (danger manager holds an OEM, never an adapter).

### TRACE 3 — Crash → Startup → Recovery → Runtime
```
Crash. PersistentJournal holds last committed events/snapshots (synchronous=FULL → committed writes survive;
journal_mode=DELETE → no WAL, single-writer).
run_service → ApexEngine.start()  [engine.py:421-430]
 → _crash_recover()                [engine.py:432-463]
   CrashRecovery.recover() [recovery.py:88-157]:
     1. latest_position_snapshots() → deserialize (malformed → corrupt_snapshots++)        [recovery.py:99-112]
     2. INCOMPLETE statuses (CANDIDATE/VALIDATING/ENTERING) + RECONCILE (WATCH/CRITICAL/RECONCILIATION_REQUIRED/EXITING)
        → mark RECONCILIATION_REQUIRED; failure to mark → reconciliation_failures++        [recovery.py:114-139]
     3. Replay PAPER_FILL/PAPER_POSITION_OPENED → reconstruct idempotency keys (dedup across restart)  [recovery.py:159-217]
   corrupt_snapshots>0 OR reconciliation_failures>0 → EngineError → startup aborts, no autonomous op  [engine.py:452-463]
 → Scheduler.start()  (only after successful recovery)
 → normal tick loop (Traces 1–2)
```
Known windows (Section B): REC-1 (fill-without-snapshot silently absent), REC-2 (unparseable
executed event → key not reconstructed) — both low/medium fidelity gaps, none enabling live risk.

---

## D. NEGATIVE PROOF

1. **Autonomous live trading is impossible.** `ApexConfig.validate_safety_invariants`
   rejects `live_trading_enabled=True` and any trading mode `LIVE/PRODUCTION/REAL` before enum
   conversion (`config/settings.py:42-72`), plus a final `validate_live_trading_permanently_false`
   (`:74-79`). No exchange client can place an order. Forensic greps: zero hits for
   API keys/secrets/signing/passphrases/`X-MBX` anywhere in `src`/`scripts`; the ONLY HTTP call
   in the repository is GET-only read-only market data in `scripts/run_service.py:84`
   (`urllib.request.urlopen` on a kline/exchange-info URL; `apex/market/binance_http.py` header
   documents "no authentication, no signing, no order placement, no account access").
2. **OEM bypass is impossible.** The `ExecutionAdapter` reference exists only inside
   `OrderExecutionManager`; it is reachable only through `execute_order`, which always runs
   geometry → idempotency → kill-switch → RiskGuardian veto → EndpointGuard → adapter.
   Grep: `adapter.execute` appears at `oem.py:142` only (other hits are `cursor.execute` in
   `persistence/journal.py`). `EndpointGuard.validate_order_routing` (`endpoint_guard.py:80`)
   rejects non-PAPER/SHADOW destinations before any dispatch.
3. **PAUSED scanning and management are impossible.** Pause flips scheduler state; a paused tick
   returns `success=False` → engine returns an empty scan result (`engine.py:465+`); position
   management runs inside the same `_scan_tick` and is therefore also excluded. (Scheduler tick
   also fires on kill-switch-active, shutdown, or overlap.)
4. **Duplicate execution is impossible.** Probe 4 (8 concurrent claim threads): outcomes
   `['claimed', 'rejected-at-check']` — at most ONE execution. Restart dedup: keys rebuilt from
   execution events (recovery step 3). Journal: `UNIQUE(record_hash)` (JRN-1 probe 5).
5. **Stale-data exits are impossible.** Hard SL/TP are evaluated every management tick from the
   live `Position` and closing intent passes the full OEM chain (`TRACE 2`); exit decisions never
   depend on the entry-mode freshness flag. Kill-switch flattening is permitted (never blocked).
6. **Risk Guardian is the sole veto/sizing authority; learning is proposal-only.** `evaluate` is
   the only allowed authority, invoked inside the OEM. `learning/analyzer.py` computes pure
   arithmetic metrics (raises `InvalidNumericalDataError` on non-finite input — fail closed);
   `learning/proposals.py` tunes ONLY three detector-selectivity keys and clamps every value
   `>= current` (`proposals.py:152-160`), cannot touch config/risk/leverage/code, and emits
   `DRAFT_FOR_REVIEW` documents requiring human approval. No import of learning anywhere in the
   risk/danger runtime.
7. **Kill switch is fail-closed and operator-verified.** `is_active` blocks all new entries
   (`kill_switch.py:74-83`); flatten path requires `can_cancel_or_flatten()` as a runtime
   validation (not an `assert`, cannot be stripped by `-O`) (`oem.py:116-122`).
8. **No unforeseen concurrency.** Grep D: the only threading primitives are `threading.Lock()`
   in `idempotency.py`, `persistence/journal.py`, `journal/repository.py`, `kill_switch.py`
   (connection serialization). No `Thread`/pools/asyncio tasks in the runtime; `run_service.py`
   is a single foreground loop driving the ONE `ApexEngine`/`ScanScheduler` (`run_service.py:186-188`).
   `KlineStreamManager` (async, WS reconnects) is an operator-side API and is NOT wired into the engine.

---

## E. COMMAND & PROBE EVIDENCE

```
$ git log --oneline -1
49f4433 ...                                   (HEAD; prior remediation checkpoint)

$ git status --short                          → (clean; no output)
$ git diff --check                            → DIFF_CLEAN

$ .venv/bin/python -m pytest tests -q         → 621 passed in 1.75s
$ .venv/bin/ruff check .                      → All checks passed!
$ .venv/bin/mypy src                          → Success: no issues found in 73 source files
$ .venv/bin/mypy tests                        → Success: no issues found in 36 source files
$ .venv/bin/mypy scripts                      → Success: no issues found in 2 source files
```

Forensic greps (content summarized in Section D):
- Order/private endpoints: only docstrings and `SQL ORDER BY`; no `place_order`, no `POST /order`,
  no `fapi/dapi` client, no order URL construction anywhere.
- Keys/secrets/tokens/signatures: zero hits (single docstring in `paper_adapter.py:9`).
- HTTP calls: exactly one — `urllib.request.urlopen` GET-only at `scripts/run_service.py:84`.
- Concurrency: only `threading.Lock()` stores (idempotency, journal, repository, kill switch).
- `adapter.execute` call sites: only `execution/oem.py:142`.

Runtime adversarial probes (`/tmp/opencode/audit_probes.py`, read-only; sqlite in memory, not committed):
- **Probe 1 — Health gating:** scan `usable=0, data_failed=False` → `HEALTHY` (confirms DATA-1);
  `data_failed=True` → `NO_DATA` (correct path exists).
- **Probe 2 — SQLite pragmas:** IdempotencyGuard & TradeJournal → `journal_mode=WAL, synchronous=2,
  foreign_keys=ON`; **PersistentJournal → `journal_mode=delete, synchronous=2, foreign_keys=0`**
  (confirms DUR-1).
- **Probe 3 — OEM claim ordering:** raising adapter → `is_duplicate(key)=True` after failure and
  re-execution rejected with `DuplicateEventError` (confirms EXEC-1 fail-closed loop).
- **Probe 4 — TOCTOU dedup:** 8 concurrent claimers → outcomes `['claimed','rejected-at-check']`,
  at most one execution (confirms D.4).
- **Probe 5 — Journal identity:** duplicate append rejected (`TradeJournalError`); distinct later
  close accepted; `count=2` (confirms JRN-1).

---

## NOTES / LIMITATIONS

- Findings are REPORT-ONLY per audit instructions; no remediation code or config was written,
  and nothing was committed. This file is the sole write of the audit session.
- `REC-3` (breakeven SL fidelity on restart) is currently latent: neither `engine.py` nor
  `danger_manager.py` calls `apply_breakeven` (verified by grep), so the flag is never applied.
- `DATA-1`/`DATA-3` interact: with `check_fresh=False` on entry AND silent `SKIPPED` counting,
  a partitioned feed can produce neither signals NOR health flags — the operator may believe the
  system is live while it scans nothing. Recommend triaging both together before long-running study.