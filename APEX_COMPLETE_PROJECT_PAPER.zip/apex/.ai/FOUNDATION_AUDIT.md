# APEX 24/7 — Foundation Architecture Audit

**Document Version:** 1.0.0  
**Audit Date:** 2026-09-04  
**Auditing Agent:** Agent 1 (Foundation Audit)  
**Repository:** `/home/apex/apex`  
**Current Checkpoint:** `7de1b2a chore: establish APEX repository constitution`  
**Scope:** Read-Only Audit & Architecture Definition (No implementation)

---

## 1. Repository State

### 1.1 Git Status & Commit History
* **Current Commit:** `7de1b2a` (`chore: establish APEX repository constitution`)
* **Prior Commit:** `3adf621` (`Initial commit`)
* **Current Branch:** `main` (clean working tree; ahead of `origin/main` by 1 commit)
* **Remote:** `origin` -> `https://github.com/drprottush27-cmyk/Apexu`

### 1.2 Actual Files Found in Repository
```
/home/apex/apex/
├── .ai/
│   ├── DECISIONS.md          # Architecture Decision Records (ADR-0001 to ADR-0005)
│   ├── PROJECT_STATE.md      # Phase tracking & project baseline
│   └── TODO.md               # Master milestone & task checklist
├── .gitignore                # Excludes Python artifacts, venv, secrets, logs, SQLite
├── .venv/                    # Isolated Python virtual environment
├── AGENTS.md                 # Agent Constitution: mandatory safety & engineering invariants
└── README.md                 # Project README baseline
```
* **Status:** Clean foundation. No application code, trading engine code, exchange connections, or database schemas exist yet. The repository is in an ideal baseline state for phased construction.

---

## 2. Environment Verification

### 2.1 Hardware & Operating System
* **Host OS:** Linux 6.8.0-137-generic #137-Ubuntu SMP PREEMPT_DYNAMIC x86_64 (Ubuntu 24.04 LTS)
* **CPU:** 2 vCPU cores (AMD EPYC 9354P 32-Core Processor)
* **Memory:** 7.8 GiB total RAM (5.4 GiB free, 7.1 GiB available, 0B swap)
* **Disk:** 96 GiB NVMe/SSD partition (`/dev/sda1`, 2.2 GiB used, 94 GiB available, 3% utilization)

### 2.2 Python Runtime & Tooling
* **System Python:** Python 3.12.3 (`/usr/bin/python3`)
* **Project Virtual Environment:** `/home/apex/apex/.venv/`
  * Python version: 3.12.3
  * Installed tools: `pip` (26.2.1), `packaging` (26.3), `setuptools` (84.0.0), `wheel` (0.48.0)
  * `venv` standard library module: Available and operational.
* **Build & System Tools:** `git` (2.43.0), `make`, `gcc`, `curl`, `jq`, `node` (v22.23.2), `npm` (10.9.8)
* **Agent CLI:** Antigravity CLI (`agy`) located at `/home/apex/.local/bin/agy`

### 2.3 System Services
* **Redis Server:**
  * Version: Redis 7.0.15
  * Service Status: `active (running)` via systemd (`redis-server.service`)
  * Connectivity: Verified via `redis-cli ping` -> `PONG`
  * Suitable for: Real-time event pub/sub, order idempotency leases, state caching, ticker pub/sub.
* **PostgreSQL:**
  * Version: PostgreSQL 16 (`16/main` on port 5432)
  * Service Status: `active (running)` via systemd (`postgresql.service`)
  * Access Status: Default cluster is online; standard peer authentication is enabled for system user `postgres`. Role `apex` is not yet created.
  * Suitable for: Persistent relational storage (trade journal, historical signal audit, machine-generated proposals).

---

## 3. Architecture Recommendation

To guarantee modularity, determinism, and testability across multi-agent handoffs, the application code should reside under a single top-level package `apex` (`/home/apex/apex/src/apex/`).

```
src/apex/
├── __init__.py
├── config/                  # Immutable typed application & risk configurations
│   ├── __init__.py
│   ├── settings.py          # Pydantic Settings with strict validation
│   └── constants.py         # System constants, asset specifications, safety limits
├── domain/                  # Pure immutable domain models & value objects
│   ├── __init__.py
│   ├── candles.py           # Candle, Timeframe, ClosedCandle validation
│   ├── orderbook.py         # OrderBookSnapshot, DepthLevel, Spread
│   ├── signals.py           # Signal, SignalFactor, FactorAgreement
│   ├── orders.py            # OrderIntent, OrderSide, OrderType, TimeInForce
│   ├── positions.py         # Position, PositionSide, PositionStatus
│   └── execution.py         # ExecutionReceipt, Fill, LiquidationNotice
├── market_data/             # Ingestion & WebSocket handling
│   ├── __init__.py
│   ├── client.py            # Public Binance Futures WebSocket/REST client
│   ├── feed_manager.py      # Connection lifecycle, reconnects, backoff
│   └── candle_builder.py    # Closed candle aggregator (strictly ignores partials)
├── indicators/              # Pure vectorized/deterministic indicators
│   ├── __init__.py
│   ├── volatility.py        # ATR, Bollinger Bands, Keltner Channels
│   ├── momentum.py          # RVOL, Volume Z-Score, ADX, +DI/-DI
│   └── moving_averages.py   # EMA, SMA, WMA (no lookahead, closed candles only)
├── market_structure/        # Deterministic price action & structural levels
│   ├── __init__.py
│   ├── pivots.py            # Swing high/low identification
│   └── compression.py       # Range calculation, volatility contraction detection
├── regime/                  # Regime identification
│   ├── __init__.py
│   └── detector.py          # Trending vs. Choppy vs. Explosive classification
├── pre_pump/                # Deterministic pre-pump engine
│   ├── __init__.py
│   ├── engine.py            # Multi-factor coordinator
│   ├── factors.py           # Individual factor evaluators
│   └── agreement.py         # 2-of-3 factor agreement gating logic
├── risk/                    # Deterministic risk engine & limits
│   ├── __init__.py
│   ├── guardian.py          # Risk Guardian veto evaluator
│   ├── sizer.py             # Fixed percentage equity-based sizing
│   ├── exposure.py          # Portfolio & correlation exposure limits
│   └── drawdown.py          # Daily cumulative drawdown circuit breaker
├── safety/                  # Invariant safety primitives
│   ├── __init__.py
│   ├── kill_switch.py       # Fail-closed software/hardware kill switch
│   ├── endpoint_guard.py    # Live URL/credential interceptor and rejector
│   ├── idempotency.py       # Order intent hashing & duplicate prevention
│   └── gates.py             # Startup, Data-Health, and Reconciliation gates
├── execution/               # Order lifecycle & execution routing
│   ├── __init__.py
│   ├── oem.py               # Order Execution Manager (OEM)
│   ├── router.py            # Mode router (DRY_RUN / SHADOW / PAPER)
│   └── paper_engine.py      # Simulated local fill engine with slippage & latency
├── position/                # Active position management
│   ├── __init__.py
│   ├── tracker.py           # Real-time mark-to-market position tracker
│   ├── danger_protocol.py   # Invalidation exit & emergency position unwind
│   └── trailing.py          # Structural trailing stop ratchet
├── reconciliation/          # Exchange vs Local state auditor
│   ├── __init__.py
│   └── reconciler.py        # State drift detector & trading halt trigger
├── notifications/           # Internal event broadcast
│   ├── __init__.py
│   └── bus.py               # Asynchronous event publisher
├── telegram/                # Telegram monitoring & control
│   ├── __init__.py
│   ├── bot.py               # Read-only alerting & heartbeat bot
│   └── handlers.py          # Emergency manual kill switch trigger handler
├── api/                     # Mini App / Dashboard backend
│   ├── __init__.py
│   ├── server.py            # FastAPI / ASGI read-only API
│   └── routes.py            # Endpoints: /health, /positions, /metrics, /signals
├── journal/                 # Immutable trade & decision journal
│   ├── __init__.py
│   ├── repository.py        # Append-only relational trade logging
│   └── models.py            # Structured schema for trades, context & fills
└── learning/                # Offline advisory proposal engine
    ├── __init__.py
    ├── analyzer.py          # Historical journal performance analyzer
    └── proposals.py         # Markdown/JSON proposal generator (strictly read-only)

tests/                       # Pytest test suite
├── unit/                    # Fast isolated tests (indicators, math, risk, domain)
├── integration/             # Component integration (feeds, redis, database)
├── safety/                  # Dedicated safety invariant & veto tests
└── e2e/                     # End-to-end simulated trading workflows
```

---

## 4. Safety Architecture

Safety in APEX 24/7 is an immutable architectural invariant governed by ADR-0001, ADR-0002, and `AGENTS.md`.

```
                  ┌───────────────────────────────┐
                  │    Deterministic Detector     │
                  └──────────────┬────────────────┘
                                 │ Signal (Advisory Only)
                                 ▼
                  ┌───────────────────────────────┐
                  │         Risk Guardian         │◄─── Portfolio State & Risk Policy
                  └──────────────┬────────────────┘
                                 │ Approved Order Intent (or Veto)
                                 ▼
                  ┌───────────────────────────────┐
                  │ Order Execution Manager (OEM) │◄─── Idempotency & Reconciliation
                  └──────────────┬────────────────┘
                                 │ Routed Order Request
                                 ▼
                  ┌───────────────────────────────┐
                  │        Endpoint Guard         │◄─── HARD BLOCK on Live Trading
                  └──────────────┬────────────────┘
                                 │ Verified Safe Route
                                 ▼
                  ┌───────────────────────────────┐
                  │     PAPER / SHADOW Engine     │
                  └───────────────────────────────┘
```

### 4.1 The Safety Path Components
1. **Signal Generation:** Deterministic engine produces an advisory `Signal`. The signal has **zero execution authority**. It specifies target symbol, direction, trigger price, and recommended structural invalidation point.
2. **Risk Guardian:** Absolute veto authority. Evaluates the `Signal` against current real-time equity, open positions, symbol correlations, daily drawdown limit, and fixed fractional risk policy. If any rule is violated, the intent is immediately **vetoed and discarded**. If valid, it computes the exact deterministic position size and constructs an authorized `OrderIntent`.
3. **Order Execution Manager (OEM):** Validates that no reconciliation discrepancies exist, assigns a deterministic, cryptographically unique `client_order_id`, records the order state in the internal registry, and verifies idempotency leases.
4. **Endpoint Guard:** Hardware/software proxy barrier. Inspects the outbound transport request. If the URL matches any production exchange endpoint, or if production credentials are present, it **terminates the process immediately**. Only routes explicitly flagged for `DRY_RUN`, `SHADOW`, or `PAPER` testnet destinations are permitted.
5. **PAPER / SHADOW Execution:** Simulates execution locally against current orderbook depth and trade prints (with realistic slippage and fee models) or routes to the Binance Futures Testnet sandbox.

### 4.2 Supporting Safety Invariants
* **Kill Switch (Fail-Closed):** Can be tripped via programmatic circuit breaker (daily drawdown breach, data feed loss), system exception, or human command (Telegram/CLI). Upon tripping:
  * Transitions system state immediately to `KILL_SWITCH_ACTIVE`.
  * Cancels all pending unfilled orders.
  * Closes all active open positions using market/aggressive limit orders via the standard safety path.
  * Rejects all new incoming signals.
  * Requires explicit manual intervention/restart to clear.
* **Startup Safety Gate:** On startup, the system cannot enter operational monitoring until:
  * Redis connectivity and write permissions are verified.
  * PostgreSQL persistence is operational.
  * System wall-clock time is synchronized with NTP (delta < 250ms).
  * Public exchange WebSocket feed is connected and has delivered at least 10 consecutive verified candles.
  * Initial position reconciliation passes with zero drift.
* **Data-Health Gate:** Evaluates incoming WebSocket streams continuously:
  * Heartbeat timeout (> 3 seconds without message triggers warning; > 10 seconds trips data halt).
  * Monotonic candle timestamp verification (out-of-sequence or duplicate candles rejected).
  * Max orderbook snapshot latency (< 500ms).
  * If the data health gate fails, all new signal processing is paused. Existing positions enter defensive management.
* **Reconciliation Gate:** Runs on every fill event and periodically (e.g., every 30 seconds). Reconciles local OEM position size, entry price, and open orders against the paper engine / testnet account state. If any drift > 0 is detected:
  * All new order placement is locked.
  * Warning alert dispatched to notifications.
  * Reconciliation resolution sequence initiated.
* **Idempotency Guard:** Every order intent generates a SHA-256 hash derived from `(symbol, side, quantity, price, signal_timestamp, candle_close_time)`. Redis `SET NX EX` distributed lock ensures no duplicate event can trigger a duplicate order within a 120-second window.
* **Crash Recovery:** Upon process restart:
  1. Loads last known state from PostgreSQL journal and Redis.
  2. Queries paper engine / exchange testnet for open orders and positions.
  3. Reconciles state; if discrepancies exist, flags for operator or defensive close.
  4. Resumes trailing stops on open positions.
* **Fail-Closed Principle:** Any unhandled exception in the signal, indicator, or execution pipeline defaults to **ABORT / REJECT**. Under no circumstances does an unhandled error result in order submission.

---

## 5. State Machines

### 5.1 System Lifecycle State Machine
```
   ┌─────────────────────────────────────────────────────────────┐
   │                                                             │
   ▼                                                             │
[BOOTING]                                                        │
   │                                                             │
   ▼                                                             │
[STARTUP_GATING] ──(Gate Failure)──► [STARTUP_FAILED] (Halt)    │
   │                                                             │
   ▼ (All Checks Pass)                                           │
[HEALTHY_MONITORING] ◄─────────────────────────────────────┐     │
   │              ▲                                        │     │
   │ (Signal)     │ (Signal Processed / Vetoed)            │     │
   ▼              │                                        │     │
[ORDER_PENDING] ──┘                                        │     │
   │                                                       │     │
   ▼ (Position Opened)                                     │     │
[POSITION_ACTIVE] ─────────────────────────────────────────┤     │
   │                                                       │     │
   ├─► (Feed Lost / Stale) ─────────► [DATA_DEGRADED] ─────┤     │
   │                                                       │     │
   ├─► (Position Drift) ────────────► [RECONCILIATION_HALT]┘     │
   │                                                             │
   ▼ (Circuit Breaker / Manual Trip)                             │
[KILL_SWITCH_ACTIVE] ──(Liquidate / Cancel Orders)               │
   │                                                             │
   ▼                                                             │
[MANUAL_RECOVERY] ───────────────────────────────────────────────┘
```

### 5.2 Position Lifecycle State Machine
```
[PROPOSED] (Generated by Pre-Pump Detector)
   │
   ▼
[EVALUATING_RISK] ──(Risk Guardian Veto)──► [REJECTED] (Logged to Journal)
   │
   ▼ (Approved)
[AUTHORIZED]
   │
   ▼
[SUBMITTING] ──(Timeout / Network Error)──► [SUBMISSION_FAILED]
   │
   ▼ (Fill Received)
[OPEN]
   │
   ▼
[ACTIVE_MONITORING]
   │
   ├── (Trailing Stop Ratchet) ──► [STOP_ADJUSTED] ──► [ACTIVE_MONITORING]
   │
   ├── (Target Hit) ─────────────► [TP_TRIGGERED] ─────┐
   │                                                   │
   ├── (Invalidation Hit) ───────► [SL_TRIGGERED] ─────┼─► [CLOSING] ──► [CLOSED] ──► [JOURNALED]
   │                                                   │
   └── (Danger Protocol Trip) ───► [EMERGENCY_EXIT] ───┘
```

---

## 6. Pre-Pump Detector Architecture

The Pre-Pump Engine detects emerging volatility and volume expansion **before** parabolic moves peak. It is strictly deterministic and rule-based.

### 6.1 Multi-Factor Detector Specification
The detector monitors candidate symbols across 1-minute, 5-minute, and 15-minute timeframes, computing four core factor groups:

1. **Volume & Relative Volume (RVOL):**
   * Volume Surge: Current candle volume $V_t > \mu_{V, 20} + 2.5 \times \sigma_{V, 20}$.
   * RVOL: Ratio of current closed candle volume to the 20-period moving average of volume for that timeframe: $\text{RVOL} \ge 2.5$.
2. **Momentum & Trend Strength (ADX / DMI):**
   * ADX(14) > 22 and rising ($\text{ADX}_t > \text{ADX}_{t-1}$).
   * Directional Movement: $+DI > -DI$ with expanding spread $(+DI - -DI)_t > (+DI - -DI)_{t-1}$.
3. **Volatility Compression & Structural Breakout:**
   * Bollinger Bandwidth Compression: $\text{Bandwidth} = \frac{UB - LB}{MB} \le \text{Percentile}_{20}(\text{Bandwidth}, 100)$.
   * Breakout Expansion: Current closed candle closes above the upper boundary of the consolidation range (swing high of the last $N$ candles) with candle body ratio $\frac{|\text{Close} - \text{Open}|}{\text{High} - \text{Low}} \ge 0.65$.
4. **Order Book Microstructure Evidence (Closed Snapshots):**
   * Bid/Ask Imbalance: Ratio of aggregate bid depth to aggregate ask depth within the top 15 book levels:
     $$\text{Imbalance} = \frac{\sum_{i=1}^{15} \text{BidQty}_i}{\sum_{i=1}^{15} \text{BidQty}_i + \sum_{i=1}^{15} \text{AskQty}_i} \ge 0.65$$
   * Resistance Thinning: Ask book depth immediately above price is below the 50-snapshot median.

### 6.2 2-of-3 Agreement Gating Rule
A signal is only emitted if there is simultaneous confirmation across at least **two of the three** primary technical factor groups, corroborated by orderbook microstructure:
* Condition A: Volume / RVOL Surge
* Condition B: Structural Compression Breakout
* Condition C: ADX Momentum Expansion
* **Rule:** $(\text{Condition A} \land \text{Condition B}) \lor (\text{Condition A} \land \text{Condition C}) \lor (\text{Condition B} \land \text{Condition C})$, AND verified $\text{OrderBook Imbalance} \ge 0.60$.
* If only 1 factor triggers, the signal is suppressed.

### 6.3 Strict Invariant: Closed Candles & Zero Lookahead
* **Closed-Candle Rule:** All indicator, pattern, and signal computations **MUST** execute strictly on finalized, closed candles ($t_{\text{candle\_end}} \le t_{\text{current}}$). Unclosed/forming candles (`is_closed == False`) are discarded for signal decisions.
* **Closed-Snapshot Rule:** Order book evaluations must use immutable historical snapshots captured at or before the candle close timestamp.
* **No Lookahead Invariant:** In testing and live evaluation, calculating any feature at index $i$ is prohibited from referencing slice $j$ where $j > i$. Unit tests must mathematically enforce this via point-in-time sequential replay.

---

## 7. Risk Architecture

Trading risk is determined entirely by mathematical policy and current account equity.

### 7.1 Risk Policy Specifications
* **Fixed Percentage Risk ($R$):** The monetary risk per trade is strictly capped at a fixed percentage of current paper equity:
  $$\text{Risk Amount (\USD)} = \text{Current Equity} \times R \quad (\text{Default: } R = 1.0\%)$$
* **Stop-Distance Sizing:** Position quantity ($Q$) is derived exclusively from the risk amount and the distance from entry price to the structural stop loss ($SL$):
  $$Q = \frac{\text{Risk Amount}}{|\text{Entry Price} - \text{Stop Loss Price}|}$$
  * A trade lacking a defined structural stop loss is **invalid** and rejected immediately.
  * Minimum stop distance: $0.5\% \times \text{Entry Price}$ (prevents micro-stops generating excessive size).
  * Maximum stop distance: $3.0\% \times \text{Entry Price}$ (prevents over-wide stops).
* **Leverage Caps:**
  * Maximum permissible account leverage is hard-capped at **3.0x** (configurable up to a hard ceiling of 5.0x).
  * Any order whose nominal notional value ($Q \times \text{Entry Price}$) exceeds $\text{Current Equity} \times \text{Max Leverage}$ is automatically scaled down or rejected.
* **Concurrent Position Limits:**
  * Maximum simultaneous open positions: **2** (configurable to at most 3).
  * New signals are automatically rejected if open position slots are full.
* **Correlation & Sector Exposure Limits:**
  * No more than 1 position permitted in the same asset sector (e.g., Meme, AI, L1, DeFi) at any time.
  * Aggregate portfolio exposure across all open positions cannot exceed **150%** of net equity.
* **Daily Drawdown Circuit Breaker:**
  * Tracks high-water mark of equity at 00:00:00 UTC daily.
  * If daily cumulative loss (realized + unrealized) reaches **3.0%**, the daily circuit breaker trips:
    * All open positions are closed.
    * Trading is halted until 00:00:00 UTC next day.

### 7.2 Strict Invariance Rules
* **Paper-Equity Target Independence:** Informational equity goals (e.g. 4x growth benchmark) are external metrics and must **never** be used as inputs to the risk engine.
* **Deficit & Streak Independence:** Risk parameters must never increase to "recover" past losses or capitalize on "hot streaks." Martingale sizing, anti-martingale sizing, and emotional tilt compensations are prohibited by design.

---

## 8. Execution Modes

APEX 24/7 strictly supports three development execution modes. **Live production trading is permanently out of scope.**

| Mode | Market Data Ingestion | Order Routing | Fill Simulation | Network Outbound |
| :--- | :--- | :--- | :--- | :--- |
| `DRY_RUN` | Live / Historical | In-Memory Intercept | Mock Instant Fill | In-Process Only |
| `SHADOW` | Live WebSocket | In-Memory Intercept | Realistic Book Matching (Slippage + Latency) | Public WS Read-Only |
| `PAPER` | Live WebSocket | Sandbox / Testnet API | Binance Futures Testnet Matching | Testnet Endpoints Only |

### 8.1 Safety Enforcement on Production Isolation
* **No Live Pathway:** The codebase contains no routing path, logic switch, or configuration parameter that enables live order execution.
* **Endpoint Guard Interception:** The `EndpointGuard` inspects all outgoing HTTP/REST requests. If a request targets `fapi.binance.com` (Binance Futures Live) rather than `testnet.binancefuture.com` (Testnet Sandbox), the application triggers a fatal `AssertionError` and aborts immediately.
* **No Production Credentials:** The configuration validator rejects any API key matching production formats or failing the testnet credential assertion.

---

## 9. Testing Strategy

Autonomous PAPER operation cannot be enabled until every safety layer is validated by comprehensive tests.

```
┌─────────────────────────────────────────────────────────────┐
│                       E2E Validation                        │
│   (24-48h continuous paper test, full pipeline stability)   │
├─────────────────────────────────────────────────────────────┤
│                 Safety & Fault Injection                    │
│  (Risk veto, Kill switch, Feed gaps, Drift, Endpoint block) │
├─────────────────────────────────────────────────────────────┤
│                     Integration Layer                       │
│    (WebSocket ingestion, Redis pub/sub, Postgres journal)   │
├─────────────────────────────────────────────────────────────┤
│                        Unit Layer                           │
│  (Indicators, Math invariants, Domain immutability, Sizing) │
└─────────────────────────────────────────────────────────────┘
```

### 9.1 Mandatory Test Layers & Scenarios
1. **Unit Tests:**
   * Indicator correctness against reference fixtures (ATR, RVOL, ADX).
   * Strict closed-candle verification: Ensure unclosed candles raise errors or are ignored.
   * Point-in-time calculation tests: Ensure calculation on historical slice $[0..t]$ exactly equals the streaming calculation at step $t$ (zero lookahead).
   * Risk sizing invariance: Assert identical position size regardless of past win/loss streak or target deficit.
   * Domain entity immutability: Assert `FrozenInstanceError` when attempting to mutate domain objects.
2. **Integration Tests:**
   * WebSocket client auto-reconnection and backoff.
   * Order intent deduplication via Redis idempotency locks.
   * Relational journal persistence and transaction rollback on error.
3. **Safety & Fault Injection Tests:**
   * **Endpoint Isolation:** Mock an attempt to dispatch an order to a production URL; assert that `EndpointGuard` intercepts and raises a fatal exception.
   * **Risk Guardian Veto:** Attempt orders exceeding leverage cap, lacking stop loss, or violating daily drawdown; verify 100% rejection rate.
   * **Kill Switch Tripping:** Inject kill switch signal during active order execution; assert pending orders cancel and state locks.
   * **Duplicate WebSocket Events:** Inject identical trade/fill messages; assert OEM processes each execution receipt exactly once.
   * **Data-Health Gate Degradation:** Simulate 15-second WebSocket silent gap; assert new order placement is immediately blocked.
   * **Reconciliation Discrepancy:** Inject simulated out-of-band balance/position mismatch; assert OEM halts all trading until reconciled.
   * **AI/LLM Output Disconnection:** Ensure AI advisory components have no direct callable reference to the OEM or risk parameter modifiers.

---

## 10. Agent Handoff Plan

To accommodate daily context and token limits, the implementation is decomposed into 10 sequential, bite-sized phases. Each phase is self-contained with clear completion criteria.

```
PHASE 1 (Safety Core) ──► PHASE 2 (Market Data) ──► PHASE 3 (Pre-Pump Engine)
       │
       ▼
PHASE 4 (Risk / Sizing) ──► PHASE 5 (Execution) ──► PHASE 6 (Position Mgmt)
       │
       ▼
PHASE 7 (Telegram) ─────► PHASE 8 (Mini App API) ─► PHASE 9 (Journal/Learn)
       │
       ▼
PHASE 10 (Full E2E Validation & Autonomous Run)
```

### Phase Breakdown

#### PHASE 1 — Safety Core & Repository Harness
* **Purpose:** Establish `pyproject.toml`, test harness, domain models, and core safety primitives (`KillSwitch`, `EndpointGuard`, `IdempotencyGuard`).
* **Likely Files:**
  * `pyproject.toml`, `pytest.ini`
  * `src/apex/domain/{candles.py, orders.py, positions.py, signals.py}`
  * `src/apex/safety/{kill_switch.py, endpoint_guard.py, idempotency.py}`
  * `tests/unit/test_safety.py`, `tests/unit/test_domain.py`
* **Tests:** Domain immutability, endpoint guard live-URL rejection, fail-closed kill switch behavior.
* **Completion Condition:** 100% pass on safety unit tests; baseline architecture verified.
* **Assigned Role:** Primary Builder (Reviewed by Independent Reviewer).

#### PHASE 2 — Market Data Pipeline
* **Purpose:** Implement public Binance Futures WebSocket client, closed-candle aggregator, and data health gating.
* **Likely Files:**
  * `src/apex/market_data/{client.py, feed_manager.py, candle_builder.py}`
  * `src/apex/safety/gates.py` (`DataHealthGate`)
  * `tests/unit/test_market_data.py`, `tests/integration/test_feed.py`
* **Tests:** Closed-candle enforcement, WebSocket reconnection, stale data detection.
* **Completion Condition:** Reliable streaming of closed 1m/5m candles from public testnet/live streams without data drops.
* **Assigned Role:** Primary Builder.

#### PHASE 3 — Deterministic Indicators & Pre-Pump Engine
* **Purpose:** Implement pure indicators (ATR, RVOL, ADX), market structure pivots, compression detector, and 2-of-3 agreement detector.
* **Likely Files:**
  * `src/apex/indicators/{volatility.py, momentum.py, moving_averages.py}`
  * `src/apex/market_structure/{pivots.py, compression.py}`
  * `src/apex/pre_pump/{engine.py, factors.py, agreement.py}`
  * `tests/unit/test_indicators.py`, `tests/unit/test_pre_pump.py`
* **Tests:** Mathematical accuracy vs reference data, point-in-time sequential replay (no lookahead), 2-of-3 agreement validation.
* **Completion Condition:** Deterministic signals generated from closed candle test fixtures with zero lookahead.
* **Assigned Role:** Primary Builder.

#### PHASE 4 — Risk Guardian & Sizing Engine
* **Purpose:** Implement fixed fractional risk engine, equity-based stop-distance sizing, leverage limiter, correlation governor, and daily drawdown tracker.
* **Likely Files:**
  * `src/apex/risk/{guardian.py, sizer.py, exposure.py, drawdown.py}`
  * `tests/unit/test_risk.py`
* **Tests:** Veto on missing stop, equity sizing invariance, streak/deficit independence, leverage clamp.
* **Completion Condition:** 100% test coverage on all Risk Guardian veto pathways.
* **Assigned Role:** Primary Builder (Reviewed by Independent Reviewer).

#### PHASE 5 — Order Execution Manager & PAPER/SHADOW Execution
* **Purpose:** Implement OEM lifecycle coordinator, mode router, and local paper fill engine with simulated slippage and latency.
* **Likely Files:**
  * `src/apex/execution/{oem.py, router.py, paper_engine.py}`
  * `tests/unit/test_execution.py`, `tests/integration/test_oem.py`
* **Tests:** Idempotent client order ID generation, duplicate order suppression, order routing through `EndpointGuard`.
* **Completion Condition:** Order intents flow from OEM -> EndpointGuard -> PaperEngine with zero live leak possibility.
* **Assigned Role:** Primary Builder.

#### PHASE 6 — Position Management, Reconciliation & Danger Protocol
* **Purpose:** Implement active position mark-to-market tracking, trailing stop ratchet, reconciliation drift detection, and danger protocol (invalidation exit).
* **Likely Files:**
  * `src/apex/position/{tracker.py, danger_protocol.py, trailing.py}`
  * `src/apex/reconciliation/reconciler.py`
  * `tests/unit/test_position.py`, `tests/integration/test_reconciliation.py`
* **Tests:** Reconciliation drift halts order placement, structural trailing stop ratchet behavior, invalidation emergency exit.
* **Completion Condition:** Full position lifecycle simulated safely with reconciliation gating.
* **Assigned Role:** Primary Builder.

#### PHASE 7 — Notifications & Telegram Monitoring
* **Purpose:** Implement event broadcast bus and read-only Telegram alert bot with emergency manual kill switch command.
* **Likely Files:**
  * `src/apex/notifications/bus.py`
  * `src/apex/telegram/{bot.py, handlers.py}`
  * `tests/unit/test_notifications.py`
* **Tests:** Message formatting, Telegram API error handling, manual kill switch trigger.
* **Completion Condition:** Telegram bot sends heartbeat/status alerts and can trigger local kill switch.
* **Assigned Role:** Primary Builder.

#### PHASE 8 — Mini App / Dashboard API
* **Purpose:** Implement lightweight read-only FastAPI service for monitoring system health, open positions, metrics, and closed trades.
* **Likely Files:**
  * `src/apex/api/{server.py, routes.py}`
  * `tests/integration/test_api.py`
* **Tests:** Endpoint response formats, read-only guarantees, CORS & auth token verification.
* **Completion Condition:** API service serves health, metrics, and position endpoints cleanly.
* **Assigned Role:** Primary Builder.

#### PHASE 9 — Trade Journal & Human-Gated Learning Proposals
* **Purpose:** Implement append-only PostgreSQL/SQLite trade journal and offline proposal generator that produces candidate strategy parameters for human review.
* **Likely Files:**
  * `src/apex/journal/{repository.py, models.py}`
  * `src/apex/learning/{analyzer.py, proposals.py}`
  * `tests/unit/test_journal.py`, `tests/unit/test_learning.py`
* **Tests:** Journal immutability, proposal generation without code/config write capability.
* **Completion Condition:** Completed trades logged with full context; offline analysis outputs reviewable markdown proposals.
* **Assigned Role:** Primary Builder.

#### PHASE 10 — Full End-to-End Validation & Autonomous Run
* **Purpose:** Execute comprehensive simulated and testnet trading sessions, failure injection suites, and 24-hour continuous autonomous paper trading verification.
* **Likely Files:**
  * `tests/e2e/test_full_lifecycle.py`
  * `scripts/run_paper.py`
* **Tests:** Full failure injection (network drop, stale feeds, kill switch, reconciliation mismatch), 24h stability run.
* **Completion Condition:** Zero safety violations, all ADRs satisfied, formal sign-off report.
* **Assigned Role:** Independent Reviewer & Primary Builder Joint Verification.

---

## 11. Key Decisions & Blockers Summary

### 11.1 Key Decisions Established
1. **Safety First (ADR-0001):** The safety chain `Signal -> Risk Guardian -> OEM -> Endpoint Guard -> PAPER` is non-negotiable. Risk Guardian has absolute veto.
2. **Strict Mode Restriction (ADR-0002):** Only `DRY_RUN`, `SHADOW`, and `PAPER` modes exist. Live production routing is excluded from the design.
3. **Closed Candles Only (ADR-0003):** Indicators and pre-pump detectors operate strictly on closed candles and closed snapshots to eliminate lookahead bias.
4. **Risk Invariance:** Sizing is strictly derived from account equity, stop distance, and fixed risk fraction. Equity targets, streaks, and deficit goals cannot alter sizing.
5. **Human-Gated Learning (ADR-0005):** Self-tuning and machine learning modules are proposal-only. Human approval is mandatory.

### 11.2 Blockers / Action Items for Next Phase
* **PostgreSQL Credentials:** Local PostgreSQL 16 is running, but standard peer authentication is enabled for user `postgres`. In Phase 1 or when persistent storage is configured, a local role `apex` with a dedicated database `apex_journal` should be provisioned.
* **Python Dependencies:** Virtual environment `/home/apex/apex/.venv` is created but empty. Phase 1 must establish `pyproject.toml` with base dependencies (`pydantic`, `pytest`, etc.).

---

*Audit Complete. Document preserved for implementation phase handoff.*
