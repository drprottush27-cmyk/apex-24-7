# APEX 24/7 — Project State

## Current Phase

Phase 25 — Comprehensive Gap Audit, Full Telemetry Observability & 24-Hour Paper Run (Active Monitoring)

Phases 1–24 are complete. Phase 25 completes the full 8-point gap audit, exposes
comprehensive scan latency and failure health telemetry on `/api/v1/health`, enables
autonomous paper auto-trading with all safety circuit breakers active, and launches
a detached 24-hour monitored paper execution run supervised by `apex-24h-monitor.service`.

crypto-futures PAPER trading system: 100 USDT-M continuous background universe
scanning paced safely within Binance REST rate limits, per-second active trade
management via direct Binance Futures WebSockets (`markPrice@1s`, `aggTrade`,
`forceOrder`), dynamic trailing stop ladder (+1.0R -> BE, +1.5R -> +0.75R,
+2.0R -> +1.25R, +3.0R -> +2.0R), 4-factor real-time risk evaluation (SL breach,
adverse liquidation cascades, funding rate flips, volatility spikes), and an
alert-then-autoclose override protocol with configurable grace period, manual
override ("HOLD" / "CLOSE NOW"), fail-safe OEM close execution, and high-priority
Telegram Mini App visual alert countdown.

## Repository

Initialized and structured under `src/apex/`.

## Trading Mode

Strictly constrained to safe development modes:
- `DRY_RUN`
- `SHADOW`
- `PAPER`

Live/production trading is permanently prohibited by architecture and code validation. `ApexConfig` hard-rejects any LIVE mode or `live_trading_enabled=True`; `EndpointGuard` blocks production endpoints; the `scripts/run_paper.py` harness aborts on any LIVE/PRODUCTION/REAL mode value.

## Implementation Status

### Phase 1 — Safety Core (Completed)
- `src/apex/domain/`: `Candle`, `Signal`, `OrderIntent`, `Position`, `types.py`
- `src/apex/config/`: `ApexConfig`, `constants.py`
- `src/apex/safety/`: `KillSwitch`, `EndpointGuard`, `IdempotencyGuard`, fail-closed exceptions
- `src/apex/risk/`: `RiskGuardian`, `PortfolioState`, `RiskDecision`
- `src/apex/execution/`: `OrderExecutionManager`, `MockExecutionAdapter`

### Phase 2 — Pre-Pump Detector (Completed)
- `src/apex/engines/prepump/`: `PrePumpDetector`, `PrePumpConfig`, `PrePumpDecision`
- `src/apex/indicators/`: indicative primitives (EMA, ATR, RSI, ADX, RVOL, BB, pivots)

### Phase 3 — Market Data Foundation (Completed)
- `src/apex/market/`: `MarketClient`, normalization, quality gate, discovery,
  historical klines, `CandleSeries`, HTTP/WS transport protocols

### Phase 4 — Runtime Scan & Signal Orchestration (Completed)
- `src/apex/runtime/state.py`: deterministic fail-closed system state machine
- `src/apex/runtime/clock.py`: injectable Clock/Sleeper (real + deterministic mocks)
- `src/apex/runtime/scheduler.py`: deterministic scan scheduler — configurable interval,
  injectable clock/sleeper, no overlapping/duplicate scans, pause/resume, shutdown
- `src/apex/runtime/orchestrator.py`: signal orchestrator — market data → quality gate
  → detector → deterministic signal result → journal. No order execution.
- `src/apex/runtime/journal.py`: append-only InMemoryJournal, immutable `EvaluationRecord`
- `src/apex/runtime/events.py`: `DecisionEvent` / `DecisionEventType` decision trail

### Phase 5 — PAPER Execution Service (Completed)
- `src/apex/execution/adapter.py`, `oem.py`, `paper_adapter.py`: linear order gateway with
  PAPER-only adapters; mode routing; target-endpoint isolation
- `src/apex/runtime/paper_service.py`: `PaperExecutionService` — closed-signal bridge,
  PAPER fill simulation, tracker adoption via `adopt_position()`
- `src/apex/runtime/execution_journal.py`: typed execution event records

### Phase 6 — Position Lifecycle & Danger Protocol (Completed)
- `src/apex/runtime/position_tracker.py`: `PositionTracker` — mark-to-market tracking,
  hard SL/TP, reconcile, exit evaluation (`TradeManagementResult`)
- `src/apex/runtime/position_state.py`, `danger.py`: position state machine + danger
  assessment

### Phase 7 — Crash Recovery (Completed)
- `src/apex/persistence/journal.py`: `PersistentJournal` (SQLite) — crash recovery,
  replayable event log
- `src/apex/persistence/recovery.py`: `CrashRecovery` — startup replay and reconciliation
- `src/apex/safety/idempotency.py`: persistent `PersistentIdempotencyGuard` for
  duplicate-event protection across restarts

### Phase 8 — Engine Integration (Completed)
- `src/apex/runtime/engine.py`: `ApexEngine` — unified authority boundary: scan → signal
  → RiskGuardian veto → OEM → EndpointGuard → paper fill → tracker. No live execution path,
  no caller-supplied approval, no bypass surface
- `src/apex/runtime/scanner.py`: scan loop across universe with per-symbol outcomes
- `tests/unit/test_phase8_integration.py`: end-to-end engine integration suite

### Phase 9 — Trade Journal & Human-Gated Learning Proposals (Completed)
- `src/apex/journal/`: `TradeContext`, `ClosedTradeRecord`, `from_closed_position`,
  `TradeJournal` — append-only SQLite, `record_hash` UNIQUE dedup, no UPDATE/DELETE
- `src/apex/learning/`: `PerformanceAnalyzer` (win rate, expectancy, PF, drawdown),
  `ProposalGenerator` — review-only `DRAFT_FOR_REVIEW` proposals that can only raise
  detector selectivity (thresholds clamped `>= current`), never loosen risk; no file/DB
  write primitives in the learning package
- `tests/unit/test_phase9_journal_learning.py`: 22 tests

### Phase 10 — Full E2E Validation & Continuous Autonomous Run (Completed)
- `tests/e2e/test_full_lifecycle.py`: full lifecycle (signal → fill → TP close → journal
  → proposal), failure injection (network drop, data-quality gap, kill switch, no
  execution bypass), stability/determinism, ADR sign-off — 15 tests
- `scripts/run_paper.py`: deterministic offline continuous autonomous PAPER session —
  synthetic closed candles → scan → RiskGuardian → OEM → EndpointGuard → paper fill →
  tracking → close → journal → review-only proposal. Aborts on any LIVE config.

### Phase 11 — Position Danger Protocol: Fail-Safe Close (Completed)
- `src/apex/runtime/danger.py`: pure deterministic per-position danger evaluation
  (`evaluate_position_danger` → `PositionDangerAssessment`) — new `DangerAction`
  (NONE / FAIL_SAFE_CLOSE / RECONCILE_ONLY) and triggers (INVALID_PRICE,
  INVALID_QUANTITY, STOP_LOSS_BREACH, TAKE_PROFIT_BREACH, STALE_DATA,
  INVALID_GEOMETRY, RECONCILIATION_REQUIRED, AMBIGUOUS_STATE, DATA_QUALITY_FAILURE,
  KILL_SWITCH_ACTIVE). Deterministic gate order: status guards → data-integrity
  gates → stale-data → hard SL/TP breach → R-loss/risk-unmeasurable → advisory-only
  WATCH indicators. Emerging stale data prescribes FAIL_SAFE_CLOSE at the last
  known price; invalid price/quantity/geometry prescribes RECONCILE_ONLY (never
  fabricates prices).
- `src/apex/runtime/danger_manager.py` (NEW): `PositionDangerManager` — journal-first
  DANGER_EVALUATED, re-reads tracker truth, pre-transitions
  OPEN/WATCH/CRITICAL → EXITING, builds a canonical EXIT `OrderIntent` bound to
  position identity via a documented `fail-safe-close-v1` / M5 idempotency namespace
  (`exit_idempotency_key_for`), dispatches ONLY through the OEM safety chain, then
  EXITING → CLOSED on fill. Duplicate/kill-switch/veto/endpoint/unknown failures
  leave the position legitimately EXITING (crash recovery already flags EXITING)
  and journal DANGER_RECONCILIATION_REQUIRED / DANGER_EXIT_BLOCKED. EXIT quantity =
  remaining quantity, clamped to position quantity (no over-close). No adapter
  reference, no approval surface, no learning/proposal authority.
- `src/apex/risk/guardian.py`: EXIT-aware branch — after the mode check,
  non-ENTRY intents are risk-reducing and skip entry-centric checks; ENTRY intents
  keep the full veto chain. Kill switch never blocks flattening exits.
- `src/apex/runtime/engine.py`: `danger_manage_position` entry point +
  `_persist_danger_result` (persistence failures journaled explicitly, never silent).
- `src/apex/config/settings.py`: `danger_stale_threshold_ms` (default 3 600 000;
  bounded [1 000, 86 400 000]).
- `src/apex/runtime/execution_journal.py`: new event types DANGER_EVALUATED,
  FAIL_SAFE_CLOSE, DANGER_RECONCILIATION_REQUIRED, DANGER_EXIT_BLOCKED.
- `tests/unit/test_phase11_danger_protocol.py`: 48 tests (evaluation matrix,
  OEM-only execution, kill-switch parity, duplicate/restart prevention, no
  over-close, exit-aware RiskGuardian, config bounds, engine integration).

## Implementation Status — Phases 12–15

### Phase 12 — Tactical Confluence Analytics (Completed)
- `src/apex/engines/tactical/`: `model.py` (`TacticalConfig` pydantic frozen with
  threshold-ordering validation; observation dataclasses `OpenInterestPoint`,
  `FundingPoint`, `DepthLevel`, `DepthSnapshot`, `LiquidationPoint` with side
  normalization; `TacticalObservations`, `TacticalFeatures`, `TacticalVerdict`
  HIGH/MEDIUM/LOW/NO_DATA, `TacticalResult` with JSON-safe `to_metadata()`),
  `analytics.py` (pure deterministic functions: `bbw_percentile_rank`,
  `directional_bias`, `oi_expansion_pct`, `funding_rate`, `depth_imbalance`,
  `liquidation_imbalance_pct`, `compute_features` — closed-candle only, no
  lookahead, fail-safe), `scorer.py` (`TacticalScorer.evaluate()` → 0–100
  advisory score, verdict, reasons). All advisory; never an order input.
- `tests/unit/test_phase12_tactical_analytics.py`: 19 tests.

### Phase 13 — Multi-Timeframe Signals & Advisory Context (Completed)
- `src/apex/engines/tactical/mtf.py`: `HtfTrend` +
  `HtfTrendConfluence` (with `to_metadata()`), `resample_to_higher_timeframe`
  (only fully-populated closed buckets; None if <1 complete bucket),
  `htf_trend_confluence` (EMA 9/21 alignment).
- `src/apex/engines/tactical/context.py`: `TacticalContext.build()` combining
  tactical score + `multi_timeframe` conﬂuence into one advisory metadata dict.
- `src/apex/runtime/orchestrator.py`: optional `context_builder` callable on
  `SignalOrchestrator`; `_build_evidence_metadata` adds `advisory_context`
  (exceptions → `advisory_context: None`, never breaks signal emission).
- `src/apex/runtime/engine.py`: `_build_advisory_context` uses `TacticalContext`
  with H1→H4 fallback. AI output remains advisory only.
- `tests/unit/test_phase13_tactical_context.py`: 11 tests.

### Phase 14 — Market Observations (Completed)
- `src/apex/market/observations.py`: read-only public endpoints only
  (`/fapi/v1/openInterestHist`, `/fapi/v1/fundingRate`, `/fapi/v1/depth`);
  `ObservationUnavailableError(ApexError)`; strict parsers
  (`parse_open_interest_payload`, `parse_funding_payload`, `parse_depth_payload`
  with mid from best bid/ask, `parse_liquidation_payload`); `MarketObservationClient`
  (`fetch_open_interest_history`, `fetch_funding_history`, `fetch_depth`,
  `fetch_all` → `ObservationResult`) — any transport/HTTP/parse error → None
  (fail-safe, no silent throws). Market-data reads only; no execution surface.
- `tests/unit/test_phase14_observations.py`: 11 tests with `MockTransport`.

### Phase 15 — 24/7 Operational Hardening (Completed)
- `src/apex/runtime/observability.py`: structured JSON logging
  (`JsonLogger`, `CapturingLogger` for tests, `StructuredLogger` protocol).
  Never raises on write failure; no credentials/PII logged.
- `src/apex/runtime/health.py`: `RuntimeHealthMonitor` (data-health and
  execution-health gates, deterministic rolling failure counts, fail-closed
  threshold semantics), `HealthSnapshot` (immutable, `to_metadata()`), and
  `HealthStatus` (HEALTHY/DEGRADED/UNHEALTHY). Observability only; cannot
  authorize or execute.
- `src/apex/runtime/engine.py`: health monitor wired into scan ticks and
  equity-failure path (`record_execution_failure`), `get_health()` snapshot API.
- `scripts/run_service.py`: 24/7-capable foreground PAPER service — scheduled
  scanning on the same engine/scheduler, structured JSON logs, health reporting,
  graceful SIGINT/SIGTERM shutdown, restart-proof persistent journal +
  idempotency, offline by default. No systemd, no second scheduler, no
  production endpoints/credentials.
- `tests/unit/test_phase15_observability.py` (10 tests) +
  `tests/unit/test_phase15_engine_health.py` (2 tests).

## Audit Remediation — Autonomous Management & Operational Hardening

Remediates the verifiable findings in `.ai/FINAL_NARROW_AUDIT_REPORT.md`
(decision record: `.ai/DECISIONS.md`). No phase numbering change; all changes
kept safety-preserving and proven by new/updated tests.

### Autonomous open-position management (Finding: no engine-side management)

- `runtime/engine.py`: every scan tick now runs `_manage_open_positions()`
  FIRST. Per open position: `CandleSeries` of `symbol`; no series →
  `record_data_failure()` + EXECUTION_ERROR journal, skip (never fabricates a
  price); equity-provider exception → `record_execution_failure()` + journal,
  untouched; else mark-to-market at last closed candle close and
  `danger_manage_position(...)` with EMA 9/21 context. Management failures are
  merged into the tick's health record so they are never masked by a healthy
  scan.
- `runtime/danger_manager.py`: `DangerCloseResult.exit_price` set on
  FAIL_SAFE_CLOSE; engine only records a CLOSED trade when exit_price > 0.
- Exit idempotency keys (fail-safe-close-v1 / M5) unchanged → post-restart
  duplicates still rejected.
- `tests/unit/test_phase8_autonomous_management.py` (9 tests): TP/SL auto
  close, stale-data fail-safe close, equity failure blocks management,
  no-market-data fail-closed (health NO_DATA/DEGRADED), PAUSED blocks
  management then resume closes, restart reconstruction + duplicate rejection,
  corrupt-snapshot startup abort, clean-journal start proceeds.

### Crash recovery at engine startup (Finding: recovery not wired to start)

- `runtime/engine.py`: `start()` calls `_crash_recover()` → `CrashRecovery`
  replay + reconciliation. `corrupt_snapshots > 0` OR
  `reconciliation_failures > 0` → `EngineError` raised, engine NEVER starts in
  an untrusted state (fail-closed).
- `persistence/recovery.py`: corrupt snapshots / reconciliation failures are
  counted and surfaced (no silent pass). `_mark_reconciliation` returns bool.
- `persistence/journal.py`: `execution_symbols()` (DISTINCT symbols from
  `execution_events`) is the authoritative source for idempotency
  reconstruction; snapshot-derived symbols only as an empty fallback.
- `runtime/position_state.py`: `RECONCILIATION_REQUIRED` is a valid next state
  for CANDIDATE/VALIDATING/ENTERING/WATCH/CRITICAL/EXITING (one-way
  fail-closed bin; terminal states unchanged).
- `runtime/engine.py`: `_recover_position_for` no longer swallows failures —
  unexpected exceptions are surfaced via health + journal.
- Tests: `tests/unit/test_phase7_persistence.py` recovery hardening
  (corrupt-snapshot count, reconciliation flags, execution_symbols-driven
  idempotency reconstruction, EXITING recovery).

### Position management survives restarts

- Recovered OPEN positions carry `source_signal_id` → engine
  `_signal_records` replay; `_build_trade_context` reconstructs a
  `TradeContext` (None when the record is missing post-restart) so closed-trade
  records append on restarts with full exit context.
- e2e `test_full_pipeline_crash_recovery_and_dedup` now asserts the recovered
  OPEN position stays OPEN after restart and is still managed to close (with
  fresh candle data from re-anchored fixtures).

### PAUSED halts all autonomous activity (Finding: PAUSED still scanned)

- `runtime/state.py`: `_SCANNING_PERMITTED = {SCANNING, DATA_CONNECTING}`.
  PAUSED blocks scanning AND management; pause/resume round-trip preserved.
- Tests: `tests/test_phase4_runtime.py` — `test_cannot_scan_in_paused_state`,
  `test_can_scan_in_data_connecting_state`, `test_resume_restores_scan_ability`.

### NO_DATA health gating (Finding: data-loss could read as healthy)

- `runtime/health.py`: `HealthStatus.NO_DATA` — consecutive data failures over
  the full universe (zero usable symbols) is DEGRADED/NO_DATA, escalating to
  UNHEALTHY; `HealthSnapshot` carries `available_symbols`/`total_symbols`.
- Tests: `tests/unit/test_phase15_observability.py` NO_DATA coverage.

### Operator market-data + runtime wiring (Finding: no real data client)

- `scripts/run_service.py`: `--market-client {offline,binance}` +
  `APEX_MARKET_DATA_CLIENT` env. Binance wires `MarketClient` with a GET-only
  stdlib `HTTPTransport` (no credentials, no signing, no private endpoints).
  `TradeJournal` is now wired to the engine so closed trades land in the
  review-only journal.
- `scripts/run_paper.py`: rewritten — fixed-base-timestamp synthetic client +
  price-override driver; positions are managed to TP by the ENGINE (no direct
  `close_position` in the script); trade journal drives the end-of-run
  review-only proposal.
- `docs/OPERATIONS.md` updated (market-client option, NO_DATA semantics,
  management health folding, fail-closed startup).

## Next Phase

None. All defined phases and audit remediations are complete. Follow-up work
is tracked in `.ai/TODO.md`.

## Production Readiness Remediation Checkpoint

Remediates the three MEDIUM findings from
`.ai/FINAL_PRODUCTION_READINESS_AUDIT.md` (DATA-1, DATA-3, REC-1) with small
safety-preserving changes and regression coverage. Report:
`.ai/PRODUCTION_READINESS_REMEDIATION_REPORT.md`.

### DATA-1 — Coverage accounting (skipped symbols vs data failures)

- `runtime/scanner.py`: `MarketScanResult.symbols_skipped` — symbols skipped
  (no data delivered) are tallied separately from hard errors.
- `runtime/health.py`: `HealthSnapshot.skipped_symbols` / `failed_symbols`
  (both in `to_metadata()`); `record_scan` accepts `symbols_skipped` /
  `symbols_failed`. Observability only.
- `runtime/engine.py`: `_scan_tick` treats `symbols_skipped > 0` as a data
  failure for the health gate, so a complete universe delivering no data can
  never read as HEALTHY; per-event scan monitoring passes the counts through.

### DATA-3 — Timeframe-aware freshness gate on the entry path

- `market/quality.py`: `timeframe_interval_ms()` for the six timeframes
  (M1/M5/M15/H1/H4/D1); `check_freshness` / `run_quality_gate` accept an
  injected `now_ms` (deterministic, wall clock removed for callers that have
  a Clock).
- `runtime/orchestrator.py`: entry gate now `check_fresh=True` with
  `stale_threshold_ms = 2 * interval` (detects a feed that is behind by >= 2
  bars per timeframe: M5 -> 10 min, H1 -> 2 h, D1 -> 2 d) and
  `expected_interval_ms = interval` (missing-bar detection is timeframe-aware)
  driven by the injected clock. Previously the entry path ran with
  freshness disabled (`check_fresh=False`).
- Fixtures that relied on stale/anchored-to-ancient timestamps for ENTRIES
  were re-anchored to freshly-closed candles; the stale-feed danger-close
  test now opens on fresh data and goes stale on a later tick.

### REC-1 — Executed events without a backing position snapshot

- `persistence/recovery.py`: `CrashRecovery` detects executed events
  (`PAPER_FILL`, `PAPER_POSITION_OPENED`) with no matching position snapshot;
  correlation is event `intent_id` == snapshot `source_signal_id` OR
  `receipt_id` == snapshot `execution_receipt_id`, using ALL snapshots (incl.
  CLOSED, which legitimately backs completed trades). Each unmatched event is
  counted (`RecoveryResult.unmatched_executed_events`), folded into
  `reconciliation_failures`, and reported in the recovery messages.
- `runtime/engine.py`: `_crash_recover` message updated — the engine remains
  fail-closed (aborts startup with `EngineError`) when executed events have no
  backing snapshot rather than fabricating or ignoring that state.

### Production Paper Readiness Remediation — FINDINGS A, B, C, DUR-1, DATA-2 (Completed)

1. FINDING A — Daily Drawdown Kill Protection Wired and Persisted:
   - `src/apex/runtime/position_tracker.py`:
     - Added UTC day index tracking (`DAY_MS = 86_400_000`, `_daily_start_day: int | None`).
     - Added `daily_starting_equity`, `daily_start_day` properties.
     - Added `daily_drawdown_pct(current_equity)` calculation.
     - Added `update_daily_baseline(current_equity, now_ms)` with automatic UTC day rollover reset.
     - Updated `register_daily_start(equity, day, now_ms)` to record UTC day index.
     - Updated `check_daily_drawdown(current_equity, now_ms)` to update baseline and use configured `config.daily_drawdown_kill_pct`.
     - Updated `build_portfolio(equity, now_ms)` to compute and pass `daily_drawdown_pct` into `PortfolioState`.
   - `src/apex/risk/guardian.py`:
     - Evaluates `portfolio.daily_drawdown_pct >= max_dd` to veto new entry intents while allowing risk-reducing exit intents.
   - `src/apex/runtime/engine.py`:
     - `start()` initializes daily baseline via `_init_daily_baseline()`.
     - `_scan_tick()` calls `_check_daily_drawdown_tick()` at the start of each tick, evaluating UTC day rollover and tripping the kill switch on drawdown breach.
   - `src/apex/persistence/recovery.py`:
     - Restores `daily_start_day` and `daily_starting_equity` from journal metadata upon startup/recovery if within the current UTC day.

2. FINDING B — Post-Restart Exposure Reconstruction & Risk Evaluation:
   - `src/apex/runtime/paper_service.py`:
     - When `PositionTracker` is injected, `paper_positions` returns `self._tracker.open_positions`.
     - `build_portfolio_state(equity)` delegates to `self._tracker.build_portfolio(equity)`.
     - `execute_signal` evaluates risk using `self._tracker.build_portfolio(equity)`.
   - Post-restart entry risk evaluations now see all recovered open positions, properly enforcing `max_concurrent_positions` and aggregate leverage caps.

3. FINDING C — Recovery Orphan Execution & Fail-Safe Close Window:
   - `src/apex/persistence/recovery.py`:
     - Added `ExecutionEventType.FAIL_SAFE_CLOSE` to `_EXECUTED_EVENT_TYPES`.
     - Reconstructs exit idempotency keys from `FAIL_SAFE_CLOSE` events.
     - If an executed event's idempotency key cannot be derived/reconstructed, `reconciliation_failures` is incremented (fail-closed startup).
     - Enhanced `_find_unmatched_executed_events()`: validates that `FAIL_SAFE_CLOSE` events have a matching position snapshot AND that the latest snapshot status is `CLOSED` (unclosed snapshots for executed exits trigger reconciliation failures).
   - `src/apex/persistence/journal.py`:
     - `all_positions()` preserves `position_id` and `status` from database rows.

4. DUR-1 — Persistent Journal SQLite Pragmas:
   - `src/apex/persistence/journal.py`:
     - Configured SQLite connection pragmas: `PRAGMA journal_mode=WAL`, `PRAGMA synchronous=FULL`, `PRAGMA foreign_keys=ON`.
     - Added `set_meta(key, value)` and `get_meta(key)` for storing operational metadata in `journal_meta`.

5. DATA-2 — Scanner Equity Provider Failure Data Health:
   - `src/apex/runtime/scanner.py`:
     - Sanitized equity sampling to default to `0.0` on exception or non-positive equity, allowing detector to reject with `"invalid equity"`.
   - `src/apex/runtime/engine.py`:
     - Folded `"invalid equity"` rejections into `data_failed` inside `_scan_tick()`, properly degrading data health monitor when equity fetch fails.

### Phase 17A — Targeted Operational Remediation (Completed)

1. BLOCKER 1 — Kline Normalization (12-field Binance USDⓈ-M Futures REST response):
   - `src/apex/market/normalize.py`: `normalize_kline()` accepts 11 or 12 fields (ignoring 12th unused field).
   - Strict OHLCV timestamp alignment and validation preserved without index shifting.
   - 7 new regression tests in `tests/unit/test_phase3_normalize.py`.

2. BLOCKER 2 — HTTP Rate-Limit Resilience (ResilientHTTPTransport):
   - `src/apex/market/transport.py`: `ResilientHTTPTransport` implements `HTTPTransport` protocol.
   - Public GET only (mutating methods assert and fail closed).
   - HTTP 429 rate-limit exponential backoff with Retry-After header parsing.
   - HTTP 418 IP-ban immediate fail closed unless bounded Retry-After provided.
   - Bounded retries and explicit timeouts (no infinite loops or retry storms).
   - 9 new regression tests in `tests/unit/test_resilient_transport.py`.

### Phase 17B — Controlled Real-Data PAPER Soak (Completed)

- 30-minute controlled real Binance PAPER soak executed with 4 liquid symbols (`BTCUSDT`, `ETHUSDT`, `SOLUSDT`, `BNBUSDT`).
- 31 / 31 ticks completed cleanly at 60s interval; 124 REST fetches, 0 errors, 0 rate limits (0 429s, 0 418s).
- Zero resource leaks: RSS stable at 36.1 MB, 12 open file descriptors, <0.6s total CPU time consumed.
- Natural selectivity preserved ("NO NATURAL SIGNAL DURING SOAK"); zero manufactured trades.
- Clean graceful shutdown (exit code 0); SQLite database integrity verified.
- Post-soak restart validation executed cleanly against persisted soak state.

### Master Production Hardening & Advanced System Audit (Completed)

1. REC-3 — Position Snapshot Completeness:
   - `src/apex/persistence/recovery.py`: `_deserialize_position()` uses full `Position.model_validate()` preserving `remaining_quantity`, `breakeven_moved`, `danger_level`, `unrealized_pnl`, with fallback to `create_position` for legacy records.
   - Restored positions seamlessly repopulate `PositionTracker._breakeven_moved` and tracking state.
   - Regression tested in `tests/unit/test_phase7_persistence.py`.

### Phase 18 — Binance MCP Fix & Telegram Mini App Unification (Completed)

1. Binance Official Agentic MCP Server Fix:
   - Diagnosed root cause of 404 SSE error: Binance's `Tesla-MCP-Server` (v1.0.0 at `https://agent.binance.com/mcp/agentic`) uses Streamable HTTP POST (JSON-RPC), not legacy SSE GET transport, and enforces CIMD client registration incompatible with OpenCode dynamic registration.
   - Created `/usr/local/bin/binance-mcp-bridge` (stdio JSON-RPC to Streamable HTTP POST bridge) reading OAuth bearer tokens from `/home/apex/.config/binance-mcp/credentials.json`.
   - Configured `opencode` for both `root` and `apex` to use the bridge. Verified with `opencode mcp list` (`● ✓ binance-mcp-server connected`) and live read-only ticker call (`BTCUSDT` -> `$79,672.30`).

2. Apex Read-Only HTTP API Server:
   - `src/apex/api/server.py` (`ApexApiServer`): strictly localhost-bound (127.0.0.1), rejects non-localhost requests with 403, rejects mutating methods (POST/PUT/DELETE) with 405 Method Not Allowed.
   - Endpoints: `/api/v1/health`, `/api/v1/risk`, `/api/v1/account`, `/api/v1/signals`, `/api/v1/dashboard`.
   - Daemon service configured and running at `apex-api.service` via `scripts/run_api.py`.
   - Unit tests in `tests/unit/test_api_server.py` (7 tests).

3. SFP (Swing Failure Pattern) Indicator:
   - Ported deterministic swing failure pattern detection from `/root/prepump-scanner` into `src/apex/indicators/sfp.py`.
   - Full test coverage in `tests/unit/test_indicators_sfp.py` (5 tests).
   - Documented audit in `.ai/TACTICAL_DATA_INVENTORY.md`: redundant components (CVD without taker volumes, uncalibrated volume profile, coupled RS scanner) intentionally excluded to protect safety core.

4. Telegram Mini App Integration:
   - `/root/binance-agent/miniapp/server.py`: replaced 19s LLM subprocess dashboard call with direct async fetch to Apex API (<10ms).
   - Fail-closed trade intent check against Apex Risk Guardian and Kill Switch: trades blocked immediately when Kill Switch is engaged or safety limits exceeded.
   - Fast structured queries for price, balance, signals, and safety.
   - Webapp UI updated with honest provenance badges (`[REAL]` vs `[ESTIMATED]`), signal reasons, and safety banners.

### Phase 19 — Universe Expansion & WeightLimiter Pacing (Completed)
- `src/apex/market/rate_limiter.py`: `WeightLimiter` token-bucket rate limiter pacing requests to remain safely within Binance's 2,400 weight/min ceiling.
- `src/apex/market/discovery.py`: dynamic discovery of top 100 USDT-M perpetuals by 24h quote turnover ($10M min cutoff).
- `scripts/run_api.py`: added `--universe auto`, `--universe-top-n 100`, `--min-quote-volume 10000000.0`.
- Unit tests in `tests/unit/test_weight_limiter.py` and `tests/unit/test_discovery_expansion.py` (9 tests).

### Phase 20 — Advanced Multi-Factor Signal Engine & Honest Provenance (Completed)
- `src/apex/engines/tactical/analytics.py` & `model.py`:
  - Volatility Regime classification (`COMPRESSION`, `EXPANSION`, `HIGH_VOLATILITY`, `NORMAL`).
  - Cross-sectional relative strength percentiles across all 100 perpetuals.
  - Swing Failure Pattern (SFP) integration into composite confluence score.
  - Explicit provenance tracking (`REAL FEED` vs `ESTIMATED PROXY`).
  - Honest Telegram alert formatting with full factor provenance breakdown in `alerts.py`.
- Unit tests in `tests/unit/test_tactical_expansion.py` (5 tests).

### Phase 21 — Trade Control Dashboard & Pinpoint Planner (Completed)
- `src/apex/api/server.py`:
  - Implemented `/api/v1/plan?symbol=XYZ` and `/api/v1/signals/{symbol}/plan`.
  - Dynamic sub-dollar pricing precision (up to 8 decimals for DOGE/PEPE/BONK).
  - ATR(14) stop loss, entry zone, and 3-stage profit targets (TP1 1.5R @ 40%, TP2 2.5R @ 30%, TP3 4.0R @ 30%).
  - Risk-managed position sizing (equity * risk% / stop distance) capped by 3.0x leverage.
- Mini App Webapp:
  - `<dialog id="pinpoint-dialog">` modal with entry zone, stop loss, targets, sizing, and multi-factor confluence breakdown.
  - "Prepare Order →" action button pre-filling chat composer with confirmation gating.

### Phase 22 — Safe Auto-Trade Logic & Hard Circuit Breakers (Completed)
- `src/apex/runtime/auto_trade.py`:
  - `AutoTradeConfig` (immutable, strongly validated Pydantic model).
  - `SafeAutoTradeManager`: coordinator for autonomous PAPER trading.
  - 6 hard circuit breakers:
    1. Master Enable gate (default False)
    2. Strict PAPER mode check (`TRADING_MODE_VIOLATION` failsafe)
    3. Kill switch fail-closed veto (`KILL_SWITCH`)
    4. Consecutive loss circuit breaker (3 realized losses, auto-resets on profit)
    5. Daily drawdown circuit breaker (2.0% daily DD limit)
    6. Staleness guard (180s candle age limit)
    7. Volatility surge breaker (>5% single candle move or >3x ATR)
    8. Symbol cooldown guard (300s per-symbol cooldown)
  - 500-entry audit trail ring buffer and `/api/v1/auto-trade` observability endpoint.
  - Integrated into `ApexEngine` signal pipeline and position closing callbacks.
- Unit tests in `tests/unit/test_auto_trade_safety.py` (10 tests).

### Phase 23 — Mini App Full Control Surface & Live Grounded Chat (Completed)
- Persistent visual Auto-Trade ribbon visible across ALL tabs (OFF, ACTIVE, PAUSED, BLOCKED).
- Expanded Universe Dashboard: 100 USDT-M perpetuals monitor with instant search and filter pills (All, Signals Only, Gainers, Losers).
- Scanner ranking: signals sorted by conviction score descending (highest-conviction first) with 70+ and 50+ filters.
- Dedicated Safe Auto-Trade Settings: master toggle, risk-per-trade %, min score, and non-bypassable circuit breaker thresholds with safe bounds validation.
- Live grounded chat analysis: structured zero-latency handlers for "why alert", "current exposure", "circuit breaker status", "auto trade status", and live Apex state injection into Codex LLM prompts.
- Unit tests in `tests/unit/test_phase5_miniapp_control.py` (4 tests).

### Phase 24 — 24/7 Continuous Scanning, Real-Time Trade Management (1s WS), Dynamic Trailing Stop Ladder & Alert-Then-Autoclose (Completed)
- **Part 1: 24/7 Background Scan Reliability**:
  - Paced sustainable scan cadence across 100 USDT-M perpetuals (15s–20s interval, ~23.3% utilization of Binance's 2,400 weight/min limit).
  - Health observability metrics: `scan_latency_ms`, `consecutive_scan_failures`, `last_successful_scan_ts_ms`.
  - Systemd service resiliency: `apex-api.service` configured with `Restart=always` and `RestartSec=3`.
- **Part 2: Real-Time Active Trade Management (Open Positions Only)**:
  - Dedicated background WebSocket loop to Binance Futures (`wss://fstream.binance.com/ws`) subscribing specifically to `markPrice@1s`, `aggTrade`, and `forceOrder` for active symbols.
  - Fail-safe fallback to engine cached series and entry price if stream is quiet.
  - Dynamic trailing stop ratcheting ladder (+1.0R -> BE, +1.5R -> +0.75R, +2.0R -> +1.25R, +3.0R -> +2.0R) with forward-only ratcheting via `PositionTracker.update_stop_loss()`.
  - 4-factor risk checks: stop loss breach, adverse liquidation cascade ($50k+ in 60s), funding flip adverse to position, and 60s volatility spike (>2%).
- **Part 3: Alert-Then-Autoclose Risk Override Protocol**:
  - `src/apex/runtime/autoclose.py`: `AlertThenAutoCloseManager` coordinator with configurable grace period (15–300s, default 60s).
  - Manual override endpoints: `HOLD` (cancels countdown, keeps trade open) and `CLOSE_NOW` (triggers immediate OEM close).
  - Automatic fail-safe close upon grace period expiry: routes through `PositionDangerManager.force_close()` and `OrderExecutionManager` safety chain.
  - Fail-closed KillSwitch compliance: flattening exits are never blocked by kill switch.
  - Complete 500-entry audit trail buffer.
- **Part 4: Mini App Full UI Integration**:
  - Live high-priority risk alert banner with smooth 1-second countdown and "HOLD" / "CLOSE NOW" action buttons.
  - Real-time active positions card view with `⚡ 1s WS` pulsing live badge, current R-multiple, mark price, and ratcheted trailing stop indicators.
  - Settings screen controls for autoclose enable, grace period seconds, trailing stop toggle, and liquidation threshold.
  - Grounded chat command handlers for "hold", "close now", and "autoclose status".
- Unit tests in `tests/unit/test_real_time_autoclose.py` (18 tests).

#### Phase 25 — Comprehensive Gap Audit, Full Telemetry Observability & 24-Hour Paper Run Launch (In Progress / Active Monitoring)
- **Comprehensive Audit**: Verified 8/8 core items from prior master prompts (100 markets continuous scan, 13-feature/11-factor signals, pinpoint planner, paper auto-trade circuit breakers, 1s WebSocket position manager, alert-then-autoclose override protocol, 24/7 background scan pacing, and Mini App UI controls).
- **Gaps Closed**:
  - Enhanced `/api/v1/health` with `scan_latency_ms`, `consecutive_scan_failures`, and `last_successful_scan_ts_ms`.
  - Configured `Environment=PYTHONUNBUFFERED=1` in `apex-api.service`.
  - Enabled `"auto_trade": {"enabled": true}` across configuration files with all 4 safety circuit breakers active.
  - Implemented 24-hour background telemetry runner `scripts/monitor_24h_run.py` writing continuous `run_timeseries.jsonl`, `run_summary.json`, and `RUN_REPORT.md` to `data/run_24h/`.
  - Installed and launched systemd service `apex-24h-monitor.service` with automated restart and detached persistence.
- Unit tests updated in `tests/unit/test_api_server.py` (745 passing).
- **Phase 25.1 — Production Hardening Pass (Completed)**:
  - Fixed PositionTracker stale-snapshot resurrection defect: `mark_to_market`, `update_stop_loss`, and `apply_breakeven` re-read the authoritative tracked position and no-op when it is no longer active, so a stale snapshot can never resurrect a closed position back to OPEN.
  - Made `RealTimePositionManager._execute_autoclose` fail-closed when no engine is wired: the previous direct `tracker.close_position` fallback bypassed the OEM/RiskGuardian/EndpointGuard chain and was a constitution violation; it now logs CRITICAL and refuses the unguarded close for reconciliation.
  - Converted silent `except Exception: pass` in the `auto_trade` volatility-surge ATR gate to a logged warning.
  - Verified cleared: `PaperExecutionFailure(intent=None)` is valid (intent is `OrderIntent | None`); `evaluate_second` SL-breach precedence is correct; engine-less autoclose path unreachable in production; consecutive-loss counter conservative (fail-closed direction); no double-drive scheduler in `run_service.py` (`engine.start()` is state-only); API `CLOSE_NOW` routes through `force_close_position` OEM chain; `WeightLimiter` thread-safe.
  - Regression tests added: 5× `TestStaleSnapshotGuard` in `test_phase6_position_lifecycle.py`, 1× `test_evaluate_second_no_engine_fails_closed` in `test_real_time_autoclose.py`.
  - Full suite: **751/751 passed**; ruff + mypy clean. Checkpoint: `11eeeca`.

## Agent Policy

One agent edits at a time.
Implementation agents receive bounded tasks.
Independent review occurs after implementation phases.

## Last Verification

Phase 25.1 Production Hardening Verification (checkpoint `11eeeca`):
- `pytest -q`: 751 passed (0 failed, 0 skipped, 0 xfail)
- `ruff check src tests scripts`: passed (clean, 0 warnings/errors)
- `mypy src tests scripts`: passed (strict, 0 issues across 130 source files)
- `git diff --check`: clean

Phase 25 Independent Verification & 24-Hour Run Launch:
- `pytest -q`: 745 passed (0 failed, 0 skipped, 0 xfail)
- `ruff check .`: passed (clean, 0 warnings/errors)
- `mypy src tests scripts`: passed (strict, 0 issues across 130 source files)
- `git diff --check`: clean
- `apex-api.service`: active, running on 127.0.0.1:8765, 100 USDT-M markets tracked, scan latency ~10.5s, auto-trade enabled
- `apex-24h-monitor.service`: active, detached supervisor logging telemetry every 5s to `data/run_24h/`
- `binance-miniapp-server.service`: active on 127.0.0.1:8008
- `cloudflared-miniapp.service`: active, tunnel healthy
- Forensics: strict PAPER mode isolation, zero live credentials or real-money execution paths, fail-closed kill switch, non-bypassable circuit breakers, AI advisory-only.

### Phase 26 — Final Mini App Command Center UI Implementation (Completed)
- **Front-End Architecture (`/home/apex/apex/webapp/`)**:
  - Semantic HTML shell (`webapp/index.html`) with exactly 5 top-level views:
    1. 🏠 **Home**: Quick status, portfolio equity, daily PnL, active trades count, universe overview, danger/circuit status, recent alerts.
    2. 🔍 **Scanner**: Full 100 USDT-M ranked list, category filtering (`qualified`, `watching`, `rejected`, `unavailable`, `all`), search query input, and dedicated "VIEW ANALYSIS" triggers.
    3. 📈 **Trades**: Active trades with real-time mark price, unrealized PnL, current R, peak R, and ratcheted trailing stop state; trade history with win/loss badges, realized PnL, R-multiple, and exit reasons; explicit "Standby — no active position" state when flat.
    4. 🛡 **Risk**: Risk Guardian status, active exposure, daily drawdown meter, circuit breaker triggers, fail-closed kill switch toggle with double-confirmation dialog, and manual emergency exit ("PANIC CLOSE").
    5. ⚙️ **System**: Engine state, scan latency, 24h background monitor status, WebSocket streaming health, settings controls (auto-trade toggle, risk-per-trade %, min score, autoclose grace period).
  - High-performance trading terminal styling (`webapp/style.css`): dark theme (`#090d14`), responsive card components, Telegram safe-area insets (`env(safe-area-inset-top)` / `env(safe-area-inset-bottom)`), zero horizontal overflow.
  - Reactive application controller (`webapp/app.js`): smooth pull-to-refresh, 3-second live polling loop, "VIEW ANALYSIS" drawer with multi-factor breakdown, grounded AI assistant drawer ("APEX AI Advisory") with strictly advisory-only guardrails, and action confirmations.
- **Backend API Server Enhancements (`src/apex/api/server.py`)**:
  - Added `/trades`, `/api/v1/trades`, `/history`, `/api/v1/history` endpoints extracting active positions from `PositionTracker` and closed trade history from `TradeJournal` or `var/trades.db`.
  - Added `/ui`, `/app`, `/command-center` and `/assets/{filename}` static asset handlers.
  - Enriched `/api/v1/dashboard` with active and historical trades, engine health telemetry, and real-time streaming state (`status_message: "Standby — no active position"`).
- **Service Integration**:
  - Symlinked `/root/binance-agent/miniapp/webapp -> /home/apex/apex/webapp`.
  - Verified live access through Cloudflare tunnel (`https://direction-ada-councils-cloudy.trycloudflare.com`) and local endpoints (`http://127.0.0.1:8008/`, `http://127.0.0.1:8765/ui`).
- **Safety & Verification**:
  - All 752 tests passing (`.venv/bin/pytest -q`).
  - Zero exchange API keys, zero outbound live trading mutations, fail-closed kill switch.
  - Running 24-hour paper monitor (`apex-24h-monitor.service`) continuously active.

### Phase 27 — Production-Safety Hardening & Observability (Completed)
- **Market Data Freshness & Staleness Hardening**:
  - Enhanced `/api/v1/health` with explicit data freshness indicators: `data_age_seconds` (elapsed seconds since last successful scan), `is_data_stale` (boolean flag), and `stale_threshold_seconds` (180.0s).
  - When scan metrics indicate stale data (>180s elapsed), `health_status` automatically degrades from `HEALTHY` to `DEGRADED`.
  - In `_handle_risk()`, `can_trade` evaluates to `False` if market data is stale, enforcing fail-closed safety so stale data is never interpreted as permission to trade.
- **API Error Boundary & Information Disclosure Hardening**:
  - Sanitized 500 error responses in `ApexApiHandler.do_GET` to avoid leaking internal exception details or paths.
  - Enforced strict allowed extension filtering (`.js`, `.css`, `.html`, `.svg`, `.png`, `.json`, `.ico`) on static asset handler `_handle_static_asset` and sanitized 404 error messages.
  - Updated `_handle_root` to comprehensively catalog all active read-only endpoints (`/api/v1/positions`, `/api/v1/history`, `/api/v1/realtime`, `/api/v1/autoclose`).
- **Mini App Proxy Boundary Hardening**:
  - Hardened `/api/v1/{path:path}` in `miniapp/server.py`: strictly enforces allowed endpoint root whitelist (`health`, `risk`, `account`, `balance`, `signals`, `dashboard`, `plan`, `auto-trade`, `trades`, `history`, `realtime`, `autoclose`, `positions`, `status`).
  - Added path traversal prevention (rejects `..` or leading `/` with 400 Bad Request).
  - Preserves upstream status codes (e.g. 404, 503) rather than masking them with generic 502s.
- **Verification**:
  - 754 pytest tests passing (`.venv/bin/pytest -q`, +2 regression tests).
  - Clean bytecode compilation (`python -m compileall src`).
  - Clean `git diff --check`.
  - All 4 systemd services continuously active and healthy.
  - Telemetry continuously logging in `data/run_24h/run_timeseries.jsonl` (980+ rows, 0 gaps).

### Phase 28 — Read-Only Telegram Alert Delivery & OpenTerminalUI Migration (Completed)
- **Workstream 1: Telegram Alert Dispatcher (`src/apex/engines/tactical/alerts.py`)**:
  - Implemented `TelegramAlertDispatcher`, `TelegramConfig`, and `TelegramDeliveryResult` with safe, fail-closed outbound delivery.
  - Secret token sanitization via `redact_secrets()`, ensuring bot tokens never leak in logs, error strings, or API responses.
  - Deduplication within configurable cooldown window (default 300s) on `(symbol, candle_timestamp_ms)`.
  - Configurable retry backoff and timeout parameters.
  - Wired into `src/apex/api/server.py` (`/api/v1/health`, `/api/v1/dashboard`, and `/api/v1/telegram`) reporting configured state, status (CONNECTED/UNAVAILABLE/DELIVERY_ERROR), and delivery counters.
  - Hooked non-blocking advisory alert dispatch into `src/apex/runtime/engine.py` on accepted signals.
  - Added 13 comprehensive unit tests in `tests/unit/test_telegram_alert_dispatcher.py` verifying error handling, timeout, network failure, deduplication, secret redaction, authentic data assertion, zero execution capability, and monitoring loop resilience.
  - All 769 unit tests passing (`pytest -q`), with zero ruff and zero mypy errors.
- **Workstream 2: OpenTerminalUI Adaptation (`/home/apex/apex-openterminal-ui`)**:
  - Cloned and verified upstream OpenTerminalUI commit `fc16fd646405aec7a5525387be89c0cb376137c5` under MIT License.
  - Produced comprehensive technical assessment artifact `OPENTERMINALUI_APEX_COMPATIBILITY.md` covering all 12 architectural sections.
  - Created isolated workspace `/home/apex/apex-openterminal-ui` on branch `feat/openterminal-migration`.
  - Bypassed native heavy backend; connected frontend directly to APEX via `src/api/apexAdapter.ts`.
  - Permanently neutered and intercepted all order placement pathways in `src/api/oms.ts`, `src/api/portfolio.ts`, and `src/components/trading/HotKeyPanel.tsx`.
  - Added client-side request interceptor in `src/api/base.ts` rejecting non-GET mutating requests.
  - Built custom `ApexTerminalLayout.tsx` supporting 8 core views: Overview, Signals, Positions, Risk, Alerts, Blueprint, Monitoring, and Journal.
  - Integrated Telegram WebApp SDK (`useTelegramWebApp.ts`, `index.html`) with responsive viewport support (320px–1366px) and touch targets >= 44x44px.
  - Verified clean static compilation (`npm run build` in 21s) and preview server running on port 8768.
  - Production services (`apex-api`, `binance-miniapp-server`, `cloudflared-miniapp`, `apex-24h-monitor`) remain 100% untouched and running.

### Phase 29 — Claude Handoff Remediation, Dead WebSocket Elimination, & WebApp Data Binding (Completed)
- **Dead/Fake WebSocket Elimination (`webapp/app.js`)**:
  - Removed `connectWebSocket()` and infinite 2-second reconnect retry loop against nonexistent `/ws/chat`.
  - Replaced with authoritative HTTP polling on `/api/v1/dashboard` every 5 seconds.
  - Replaced fake "1s WS STREAM" badges with truthful "MANAGED (5s POLL)" badges.
  - Routed AI Assistant in Mini App directly to backend `POST /api/v1/control/intelligence` (xAI/Grok read-only research connector) with mandatory disclaimer.
- **Screen Data-Binding Audit & Fixes (`webapp/app.js`, `src/apex/api/server.py`)**:
  - Bound all previously static/placeholder DOM elements across all 9 screens: `global-mode-badge`, `global-regime-badge`, `master-mode-pill`, `team-active-pill`, `risk-guardian-badge`, `risk-endpoint-mode-val`, `risk-runtime-mode-val`, `risk-per-trade-val`, `system-overall-badge`, `sys-api-health`, `sys-conn-health`, `sys-market-badge`, `tg-dispatcher-status-pill`, `audit-event-count`.
  - Enriched `/api/v1/dashboard` payload with `daily_drawdown_kill_pct` and `current_equity`.
  - Added 4 comprehensive automated unit tests in `tests/unit/test_webapp_bindings.py` verifying no dead websockets, complete route table alignment, exhaustive DOM ID binding, and AI intelligence grounding.
- **Test Integrity**:
  - Full test suite: 811 of 811 passed in 9.50s (100% pass rate).
  - All production services remain untouched and healthy.
- **Reports**:
  - Generated `/home/apex/apex/reports/AGY_IMPLEMENTATION_HANDOFF_AFTER_CLAUDE.md`.