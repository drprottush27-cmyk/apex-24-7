# APEX 24/7 — Architecture Decisions

## ADR-0001 — Safety First

Trading safety is a system invariant, not an optional feature.

Risk Guardian, Endpoint Guard, kill switch, reconciliation,
data-health checks, and execution-health checks must fail closed.

## ADR-0002 — No Live Trading Path

APEX development is restricted to DRY_RUN, SHADOW, and PAPER modes.

Production/live trading is explicitly out of scope.

## ADR-0003 — Deterministic Core

Trading signal generation, risk calculation, position management,
and execution authorization must be deterministic.

LLMs may provide advisory summaries only.

## ADR-0004 — Bounded Agent Workflow

Agents work in explicit phases. Only one agent edits the repository
at a time. Every phase requires verification and a Git checkpoint.

## ADR-0005 — Learning Is Human-Gated

Automated analysis can propose changes but cannot activate strategy,
risk, or code changes automatically.

## ADR-0006 — Authoritative Risk Guardian Veto & Caller Bypass Prevention

The Risk Guardian is the exclusive, authoritative veto authority over every
order intent. Callers (detectors, AI agents, execution coordinators) cannot
fabricate or supply an "approved" token or boolean to bypass Risk Guardian.
OrderExecutionManager directly asks RiskGuardian and will fail closed on any
missing or ambiguous safety data.

## ADR-0007 — Strict Endpoint Isolation & Production Interception

The EndpointGuard structurally isolates execution code from live exchange
endpoints. Only explicitly allowlisted testnet, sandbox, and local simulator
endpoints are permitted. Production domains (e.g. fapi.binance.com, api.binance.com)
are permanently blocked and raise fatal exceptions on detection.

## ADR-0008 — Deterministic Event Idempotency

Order deduplication uses stable, deterministic trade-event keys derived from
(symbol, timeframe, closed candle timestamp, detector version) rather than
random UUIDs. Duplicate events resulting from network replays or reconnects
are rejected prior to risk evaluation or execution.

## ADR-0009 — Closed-Candle Invariant & Zero Lookahead Boundary

Signal-generating and detector domain boundaries strictly consume confirmed,
closed candles (`is_closed=True`). Unclosed or forming candles are hard-rejected
at the domain boundary (`ensure_closed()`), eliminating lookahead bias.

## ADR-0010 — Fail-Safe Kill Switch with Permitted Flattening Pathway

The KillSwitch is fail-safe and fail-closed. When active, all new entry orders
are strictly blocked. However, emergency risk-reducing actions (order cancellation
and position flattening exits) do not depend on disabling the kill switch and
are explicitly permitted.

## ADR-0011 — Autonomous Open-Position Management Inside the Engine Scan (Audit)

Every engine scan tick runs open-position management FIRST (`_manage_open_positions`),
before new-signal scanning. Management consumes only closed candles (mark-to-market at
the last closed candle close, EMA 9/21 from those closes) and dispatches ALL exits
(TP/SL/fail-safe) through the same certified chain as entries
(RiskGuardian → OEM → EndpointGuard → PAPER). A missing series, provider exception, or
equity failure disables that position's management tick and is recorded in the scan
health record (`data_failed`/`execution_failed`) plus the execution journal — management
failure can never be masked by a healthy scan, and prices are never fabricated
(NO_DATA is reported, the position is left untouched). Exits use the existing
fail-safe-close-v1 / M5 idempotency keys so restarts cannot double-close.

## ADR-0012 — Crash Recovery Is Fail-Closed at Engine Startup (Audit)

`ApexEngine.start()` runs `CrashRecovery` replay + reconciliation before autonomous
operation begins. Corrupt position snapshots (`corrupt_snapshots > 0`) or failed
reconciliation (`reconciliation_failures > 0`) raise `EngineError` and abort startup —
the engine never operates on untrustworthy state. Recovered open positions resume
engine-driven management; closed/reconciled positions transition through the
`RECONCILIATION_REQUIRED` bin (added as a valid next state for all open states,
one-way, fail-closed).

## ADR-0013 — PAUSED Halts All Autonomous Activity (Audit)

`_SCANNING_PERMITTED` is `{SCANNING, DATA_CONNECTING}`. When PAUSED, the engine neither
scans for new signals nor manages open positions; pause/resume round-trips and
`get_state()` semantics are unchanged. PAUSED is a full autonomous-activity halt, not a
partial one.

## ADR-0014 — NO_DATA Health Gate (Audit)

When consecutive data-fetch/data-quality failures coincide with zero usable symbols
across the universe, the data gate reports `NO_DATA` (overall DEGRADED, escalating to
UNHEALTHY) instead of reading as healthy. The `HealthSnapshot` carries
`available_symbols`/`total_symbols`. Health remains observational only.

## ADR-0015 — Execution Events Drive Recovery Symbol Reconstruction (Audit)

`PersistentJournal.execution_symbols()` (DISTINCT symbols from `execution_events`) is the
authoritative source for reconstructing per-symbol idempotency state after a restart.
Snapshot-derived symbols are only an empty fallback, so a lost snapshot cannot silently
narrow the recovered guard and re-trigger duplicate entries.

## ADR-0016 — Operator Market-Data Client Is Read-Only and GET-Only (Audit)

`scripts/run_service.py --market-client binance` (or `APEX_MARKET_DATA_CLIENT=binance`)
wires the public Binance `MarketClient` over a stdlib `HTTPTransport` that refuses any
non-GET request and holds no credentials, no signing material, and no private endpoint,
so operator-provided market data remains a read-only, execution-free input.

## ADR-0017 — Shared Engine Fixtures Use Fresh (Not Stale) Candle Timestamps (Audit Test Fix)

The shared engine fixture series (`trigger_series` / `_build_series`) that simulate
"just closed" candle windows were re-anchored to now-aligned 5-minute timestamps so the
engine's management phase sees FRESH candles. Consequences: the e2e crash-recovery test
asserts `open_count == 1` after the restart tick (the recovered OPEN position is kept
open and managed, not fail-safe-closed on configurable staleness), and unit tests with
persistent idempotency but no persistent journal still assert `open_count == 0`.

## ADR-0018 — Binance 12-Field Kline Normalization & Resilient HTTP Transport

Binance USDⓈ-M Futures public REST API returns 12 elements per kline, where index 11 is an unused "ignore" field.
`normalize_kline()` now accepts 11 or 12 fields without shifting OHLCV timestamps.
For sustained public market-data reading without credentials, `ResilientHTTPTransport` was introduced:
- Public GET requests only (all mutating methods assert and fail closed)
- Strict timeouts per request
- Rate-limit handling: HTTP 429 parses `Retry-After` header and applies bounded exponential backoff
- IP-ban protection: HTTP 418 fails closed immediately unless an explicit bounded `Retry-After` is supplied
- Bounded retry limits (default 3 retries, base backoff 0.5s, max backoff 10.0s) to prevent runaway retry storms
- All failures surface as explicit `RuntimeError` rather than silent drops.

## ADR-0019 — Position Snapshot Byte-Identical Recovery (REC-3) & Modular Tactical Interfaces

1. `CrashRecovery._deserialize_position()` now executes full Pydantic model validation on position snapshot JSON, preserving all runtime fields (`remaining_quantity`, `breakeven_moved`, `danger_level`, `unrealized_pnl`, `realized_pnl`, `close_reason`, `close_timestamp_ms`) with fallback to `create_position` for legacy records.
2. Modular future market intelligence interfaces (`LiquidationContext`, `LiquidationCluster`, `LiquidationSource`, `WhaleFlowContext`, `WhaleFlowLabelQuality`) are introduced into `src/apex/engines/tactical/model.py`. Proxies are explicitly labeled `is_estimated=True` with no fabricated precision, and exchange wallet attribution requires explicit label quality (`VERIFIED_EXCHANGE_LABEL` vs `HEURISTIC` vs `UNKNOWN`). All outputs are advisory metadata for journaling and review only, with zero execution or risk authority.
