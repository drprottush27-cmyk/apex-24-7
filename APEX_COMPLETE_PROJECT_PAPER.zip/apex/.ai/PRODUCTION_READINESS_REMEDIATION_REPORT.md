# APEX 24/7 — Production Readiness Remediation Report

- Branch: `main`
- Base commit: `49f4433`
- Scope: remediate the three MEDIUM findings from
  `.ai/FINAL_PRODUCTION_READINESS_AUDIT.md` — **DATA-1**, **DATA-3**, **REC-1**
- Constraint: small, targeted, safety-preserving changes only; the remaining
  LOW findings (EXEC-1, DUR-1, REC-2, DATA-2) are intentionally NOT in scope.

---

## 1. CHECKPOINT

| Item | Status |
| --- | --- |
| DATA-1 coverage accounting | Remediated |
| DATA-3 timeframe-aware freshness gate | Remediated |
| REC-1 executed-events reconciliation | Remediated |
| Regression tests | 19 new (total 640 passing) |
| Static gates | ruff / mypy / diff-check clean |
| Smoke | run_paper lifecycle EXIT 0; run_service offline clean |
| Forensics | safety chain intact |
| Commit | single focused commit |

---

## 2. SCOPE

Only the three MEDIUM audit findings were touched. No other findings were
changed (EXEC-1, DUR-1, REC-2, DATA-2 remain open LOW items for a future
checkpoint). One test-only collateral adaptation was required by DATA-3 (see
5.4) because enabling the entry freshness gate means entries can no longer be
opened on candles anchored to ancient timestamps — the adapted tests still
exercise exactly the behaviors they were written for.

---

## 3. DATA-1 — Coverage accounting for SKIPPED symbols

### 3.1 Finding

A launch with zero delivered market data could read as `HEALTHY` because the
health gate counted only hard errors, not "skipped" (no-data) outcomes, and
the scanner had no visibility into how many symbols delivered nothing.

### 3.2 Remedy

- `src/apex/runtime/scanner.py`
  - `MarketScanResult.symbols_skipped: int = 0` (no-data skips are now an
    explicit, observable quantity).
  - `scan_once` tallies every `SKIPPED` symbol outcome and records it.
- `src/apex/runtime/health.py`
  - `HealthSnapshot.skipped_symbols` / `failed_symbols`, both serialized by
    `to_metadata()`.
  - `RuntimeHealthMonitor.record_scan(..., symbols_skipped, symbols_failed)`.
    Observability only — health can never authorize anything.
- `src/apex/runtime/engine.py`
  - `_scan_tick`: `data_failed` is True when `symbols_skipped > 0` (in
    addition to hard errors), and the health monitor receives both counts, so
    a full-universe no-data launch surfaces as `NO_DATA` / `DEGRADED` — never
    as `HEALTHY`. Per-event scan monitoring passes the counts unchanged.

### 3.3 Verification

- Scanner: `test_scan_skips_missing_data` extended; new
  `test_scan_counts_skipped_symbols_alongside_evaluated`,
  `test_scan_empty_universe_reports_zero_skipped`.
- Health: new `test_health_snapshot_captures_skipped_and_failed_symbols`,
  `test_health_full_universe_skipped_is_no_data`.
- Engine: new `test_full_universe_skip_reads_no_data_not_healthy`,
  `test_partial_universe_skip_reads_degraded`.
- Live proof: offline `run_service` smoke reports each tick as
  `data_health=NO_DATA`, `health=DEGRADED` — exactly the intended wiring.

---

## 4. DATA-3 — Timeframe-aware freshness on the entry path

### 4.1 Finding

The orchestrator entry gate ran the data-quality gate with
`check_fresh=False`: a series of closed candles with no delivery recency
guarantee — even hours/days old — could produce entry signals. Every other
caller already gated on freshness; only the actual entry path did not.

### 4.2 Remedy

- `src/apex/market/quality.py`
  - `timeframe_interval_ms(Timeframe)` for M1/M5/M15/H1/H4/D1.
  - `check_freshness` / `run_quality_gate` accept an injected `now_ms`
    (defaults to wall clock for callers without a `Clock`) — deterministic in
    the engine because the gate is driven by the injected engine clock.
- `src/apex/runtime/orchestrator.py`
  - Entry gate now: `check_fresh=True`,
    `stale_threshold_ms = 2 * timeframe_interval_ms(timeframe)`,
    `expected_interval_ms = timeframe_interval_ms(timeframe)`,
    `now_ms = self._clock.now_ms()`.
  - `stale_threshold_ms = 2 * interval` (not a flat 1 h): the gate detects a
    feed that is behind by >= 2 completed bars of *its own timeframe*
    (M5 -> 10 min, H1 -> 2 h, D1 -> 2 d). X 1-hour default would let a broken
    M5 feed stream data 30+ minutes late; 2x the timeframe is the deterministic
    "feed not producing" signal per timeframe.
  - `expected_interval_ms = interval` makes missing-bar detection
    timeframe-aware too (a 10-minute hole is a fatal gap on M5 and a non-event
    on H1).

### 4.3 Verification

- Quality: `test_timeframe_interval_mapping`,
  `test_freshness_deterministic_now_ms`, `test_run_quality_gate_deterministic_now_ms`,
  `test_missing_interval_is_timeframe_aware`.
- Orchestrator: `test_recent_past_series_passes_freshness_gate` (last close
  60 s old -> accepted), `test_series_older_than_two_intervals_rejected`
  (3 h old on H1 -> `DataQualityFailed`), `test_missing_interval_series_rejected`.
- Engine: `test_stale_feed_blocks_entry_via_freshness_gate` (stale M5 feed:
  `data_quality_failures == 1`, zero fills, zero positions).

### 4.4 Test-only collateral (required by the gate, documented)

Enabling freshness means a stale feed can no longer open an entry — the
pre-condition that several fixtures abused (candles anchored to 2003/2001).
These are test-data updates only; production logic unchanged:

- `tests/unit/test_phase11_danger_protocol.py`: `_build_series` now anchors to
  a freshly closed 5-minute period (mirrors `test_phase8_integration.py`).
- `tests/unit/test_phase8_autonomous_management.py`: `_stale_series` removed;
  `PriceDriverClient.make_stale()` added. The stale-feed fail-safe-close test
  now opens the position on fresh data, then makes the feed stale on the next
  tick — the same danger-protocol behavior under test, with a realistic
  entry precondition.

---

## 5. REC-1 — Executed events without a backing position snapshot

### 5.1 Finding

`CrashRecovery` reconstructed positions and idempotency state but did not
check for executed journal events (a `PAPER_FILL` / `PAPER_POSITION_OPENED`)
that have no matching position snapshot. The journal saying "executed" while
no position exists is an untrusted state (e.g. a crash between event
persistence and snapshot upsert) that the old recovery hand-waved past.

### 5.2 Remedy

- `src/apex/persistence/recovery.py`
  - New step in `recover()`: `_find_unmatched_executed_events()` reads the
    intersection of executed-event identity and snapshot identity.
  - Correlation is authoritative-event-bindings: event `intent_id` == snapshot
    `source_signal_id` OR event `receipt_id` == snapshot
    `execution_receipt_id` — using `all_positions()` (including CLOSED, which
    legitimately backs a completed trade).
  - Each unmatched executed event increments `unmatched_executed_events`,
    is folded into `reconciliation_failures`, and is surfaced in the recovery
    messages.
- `src/apex/runtime/engine.py`
  - `_crash_recover` fail-closed message updated: startup aborts with
    `EngineError` on "executed events without a matching position snapshot".
    State is never fabricated and never silently dropped.

### 5.3 Verification

- `test_executed_events_without_snapshots_reconstruct_dedup_and_fail_closed`
  (adapted `test_execution_symbols_drive_idempotency_reconstruction`): the
  unmatched state still reconstructs idempotency keys (so a human resolving
  the reconciliation can never trigger a double-execution) while
  `unmatched_executed_events == 2` and `reconciliation_failures >= 2`.
- `test_executed_events_backed_by_open_snapshot_pass`
- `test_executed_events_backed_by_closed_snapshot_pass`
- `test_executed_event_matching_only_by_receipt_passes`
- `test_intent_created_only_is_not_unmatched`
- `test_engine_refuses_start_on_executed_event_without_snapshot` (engine-level
  `EngineError` abort).

---

## 6. SAFETY INVARIANTS

Re-verified unchanged after the remediation (forensics section in 8):

- Recovery remains `reconciliation_failures`-driven, fail-closed; NEW detection
  only ADDS cases that abort startup — it never lowers existing thresholds.
- The entry-quality gate is now fresh AND deterministic via the injected
  clock; it cannot be influenced by the wall clock in the engine path.
- No new network, credentials, signing, or authentication was introduced.
- The mandatory execution chain (Signal -> RiskGuardian -> OEM ->
  EndpointGuard -> PAPER/SHADOW adapter) is untouched.
- AI/LLM advisory metadata unchanged (advisory-only).
- Coverage counters are observability-only; health cannot authorize.

---

## 7. VALIDATION

```
pytest -q                 -> 640 passed (0 failed, 0 skipped, 0 xfail)
ruff check .              -> All checks passed
mypy src tests scripts    -> Success: no issues found in 111 source files
git diff --check          -> clean

Smoke 1: scripts/run_paper.py --ticks 5
  -> tick 1: accepted=2 filled=2; ticks 2-5: engine-managed TP closes x2 ->
     open=0; lifecycle complete: 2 trades recorded; review-only proposal; EXIT 0
Smoke 2: scripts/run_service.py --ticks 3 --interval-ms 200 --market-client offline
  -> 3 clean ticks, data_health=NO_DATA / health=DEGRADED (online-universe
     blueprint), execution_health=HEALTHY, graceful stop, JSON logs
```

New/adapted regression tests by file:

- `tests/unit/test_phase8_scanner.py`          — 3 tests
- `tests/unit/test_phase15_observability.py`   — 2 tests
- `tests/unit/test_phase15_engine_health.py`   — 3 tests
- `tests/unit/test_phase3_quality.py`          — 4 tests
- `tests/test_phase4_runtime.py`               — 3 tests
- `tests/unit/test_phase7_persistence.py`      — 5 tests
- `tests/unit/test_phase8_integration.py`      — 1 test
- `tests/unit/test_phase11_danger_protocol.py` — fixture re-anchor (no new tests)
- `tests/unit/test_phase8_autonomous_management.py` — `make_stale` rework (no new tests)

---

## 8. FORENSIC RESULTS

- Paper adapter (`apex/execution/paper_adapter.py`): zero network endpoints,
  zero credentials, deterministic simulated receipts, `PAPER_SIMULATED`
  provenance. No bypass introduced.
- `EndpointGuard`: approved endpoints are `local://`, `dry-run://`,
  `shadow://` only; prohibited patterns include `fapi.binance.com`,
  `api.binance.com`, `stream.binance.com`, `production`, `live`. Verified the
  engine wires it into every order path.
- Binance data client: read-only public REST GETs (`/fapi/v1/klines`,
  exchangeInfo, ticker) only; no key, no signature, no private path.
- Threads/async: the scheduler uses a `threading.Lock` only — no background
  threads, no async/consumer loops, no subprocesses.
- Credentials: no `api_key`/`api_secret`/`nonce`/`signature`/
  `Authorization`/`Bearer` anywhere in `src/` or `scripts/`.
- AI/LLM: no model call or authorization surface; `advisory_context` and
  `_build_advisory_context` are metadata-only.

---

## 9. REMAINING FINDINGS

Deliberately not remediated in this checkpoint (LOW severity, require their
own scoped change + risk/humany-review):

- **EXEC-1** — unrelated-symbol reconciliation edge in OEM.
- **DUR-1** — fractional-r delta duration observability.
- **REC-2** — NO_DATA/data-health edge detail in recovery messaging.
- **DATA-2** — cross-bar open-price purity detail in `CandleSeries`.

None of these affect the safety chain or the fixes above.

---

## 10. FINAL VERDICT

**READY_FOR_NEXT_HUMAN_REVIEW.**

The three MEDIUM findings (DATA-1, DATA-3, REC-1) are remediated with small,
fail-closed, determinism-preserving changes, each proven by regression tests;
the full baseline suite plus 19 new tests pass (640), all static gates are
clean, both smoke runs complete successfully, and the production-safety chain
is re-verified intact.