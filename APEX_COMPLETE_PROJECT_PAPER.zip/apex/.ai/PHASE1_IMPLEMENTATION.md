# APEX 24/7 — Phase 1 Implementation Specification

**Phase:** Phase 1 — Safety Core & Repository Harness  
**Status:** Completed  
**Repository Working Directory:** `/home/apex/apex`  
**Date:** 2026-09-04  

---

## 1. Overview & Objectives

Phase 1 establishes the deterministic safety harness, foundational domain models, and core execution gating mechanisms for APEX 24/7. Live/production trading is permanently prohibited by architecture and code validation.

The primary deliverable of Phase 1 is the linear safety path:
```
Signal
  │ (Advisory Proposal Only)
  ▼
Risk Guardian (Authoritative Veto Authority)
  │ (Authorized Order Intent)
  ▼
Order Execution Manager (OEM)
  │ (Idempotency & Kill Switch Assertion)
  ▼
Endpoint Guard (Production Isolation Interceptor)
  │ (Verified Safe Route: DRY_RUN / SHADOW / PAPER Sandbox)
  ▼
Execution Adapter Boundary (Local Mock / Test Receiver)
```

---

## 2. Files Created & Modified

### Packaging & Tooling
- `pyproject.toml`: Modern PEP 621 packaging harness specifying Python 3.12 compatibility, minimal dependencies (`pydantic>=2.7.0`), optional dev tooling (`pytest`, `mypy`, `ruff`), and strict tool configurations.
- `.gitignore`: Updated with `*.egg-info/` exclusion.

### Application Source (`src/apex/`)
- `src/apex/__init__.py`: Package root definition.
- `src/apex/domain/types.py`: Core domain enumerations (`TradingMode` strictly supporting `PAPER`, `SHADOW`, `DRY_RUN` with NO `LIVE` enum, `OrderSide`, `PositionSide`, `PositionStatus`, `Timeframe`, `OrderIntentType`, `SignalDirection`).
- `src/apex/domain/candles.py`: Immutable `Candle` model with OHLC geometric validation, physical price sanity, and the strict closed-candle invariant (`ensure_closed()`, `require_closed_candle()`).
- `src/apex/domain/signals.py`: Immutable `Signal` candidate and `AIAdvisoryMetadata` container with zero authorization authority.
- `src/apex/domain/orders.py`: Immutable `OrderIntent` model enforcing entry/stop-loss/take-profit geometry (`stop_loss < entry < take_profit` for BUY; `stop_loss > entry > take_profit` for SELL).
- `src/apex/domain/positions.py`: Minimal immutable `Position` tracking model.
- `src/apex/config/constants.py`: Hard safety limits (`HARD_MAX_LEVERAGE = 5.0`, `HARD_MAX_RISK_PER_TRADE = 0.05`, `HARD_MAX_CONCURRENT_POSITIONS = 3`, `MIN_STOP_DISTANCE_PCT = 0.005`, `MAX_STOP_DISTANCE_PCT = 0.03`), approved testnet endpoint allowlists, and prohibited production domain patterns.
- `src/apex/config/settings.py`: Strongly validated `ApexConfig` model with pre-validators failing closed on any live trading attempt or out-of-bounds safety parameters.
- `src/apex/safety/exceptions.py`: Fail-closed exception hierarchy (`SafetyViolationError`, `SafetyConfigurationError`, `KillSwitchActiveError`, `ProductionEndpointBlockedError`, `EndpointViolationError`, `DuplicateEventError`, `RiskVetoError`, `UnclosedCandleError`, `InvalidGeometryError`, `InvalidNumericalDataError`).
- `src/apex/safety/kill_switch.py`: Thread-safe, fail-safe `KillSwitch` tracking active state, trigger reasons, and actors. Guaranteed flattening pathway (`can_cancel_or_flatten()` always returns `True`).
- `src/apex/safety/endpoint_guard.py`: Physical network isolation guard intercepting live Binance URLs (`fapi.binance.com`, `api.binance.com`, etc.) and enforcing mode allowlists.
- `src/apex/safety/idempotency.py`: Deterministic SHA-256 event deduplicator keyed exclusively on immutable trade identity (`symbol:timeframe:candle_timestamp:detector_version`).
- `src/apex/risk/policy.py`: `PortfolioState` snapshot and immutable `RiskDecision` token.
- `src/apex/risk/guardian.py`: Authoritative `RiskGuardian` evaluating order intents against portfolio equity, leverage caps, concurrent position limits, stop distance geometry, and kill switch status.
- `src/apex/execution/adapter.py`: Outbound `ExecutionAdapter` protocol and in-memory `MockExecutionAdapter`.
- `src/apex/execution/oem.py`: `OrderExecutionManager` implementing the linear execution pipeline with zero bypass paths.

### Test Suite (`tests/`)
- `tests/conftest.py`: Shared pytest fixtures for configurations, models, and safety components.
- `tests/unit/test_config.py`: Safety mode and configuration boundary tests.
- `tests/unit/test_kill_switch.py`: Kill switch state transitions, entries rejection, and flattening allowance.
- `tests/unit/test_endpoint_guard.py`: Production URL blocking and allowlist enforcement.
- `tests/unit/test_idempotency.py`: Deterministic key derivation, deduplication, and replay rejection.
- `tests/unit/test_candles.py`: Closed-candle invariant and OHLC mathematical sanity.
- `tests/unit/test_domain.py`: Signal, OrderIntent geometry, Position immutability, and numerical bounds.
- `tests/unit/test_risk_guardian.py`: Authoritative veto tests across all risk dimensions.
- `tests/unit/test_oem.py`: Complete linear safety chain and bypass prevention tests.
- `tests/unit/test_ai_boundary.py`: Proof that AI advisory data possesses zero authorization capability.

---

## 3. Core Architectural Guarantees

### 3.1 Mode Isolation & No Live Pathway
- Only `PAPER`, `SHADOW`, and `DRY_RUN` exist in `TradingMode`.
- If `live_trading_enabled=True` or `trading_mode="LIVE"` is supplied in configuration, the system raises `SafetyConfigurationError` during initialization and terminates startup.

### 3.2 Authoritative Risk Guardian Authority
- Risk Guardian provides the sole authoritative decision (`RiskDecision(allowed=bool, reason=str)`).
- OEM does not accept caller-supplied approval flags. No `approved=True` parameter on `OrderIntent` or method on OEM exists.
- If portfolio state is missing or equity is invalid, Risk Guardian fails closed (`allowed=False`).

### 3.3 Fail-Safe Kill Switch
- When active, all new entry orders are strictly rejected (`KillSwitchActiveError`).
- Cancellation and flattening pathways never depend on disabling the kill switch (`can_cancel_or_flatten() == True`).

### 3.4 Production Isolation (EndpointGuard)
- Production domains (e.g., `fapi.binance.com`, `api.binance.com`, `dapi.binance.com`) are permanently prohibited and raise `ProductionEndpointBlockedError`.
- Only explicitly approved endpoints matching the active mode (e.g. `https://testnet.binancefuture.com` for `PAPER`) can be routed to.

### 3.5 Deterministic Idempotency
- Trade event keys are computed from:
  $$\text{Key} = \text{SHA-256}(\text{SYMBOL} : \text{TIMEFRAME} : \text{CANDLE\_TIMESTAMP} : \text{DETECTOR\_VERSION})$$
- Duplicate triggers and network replays are halted before risk evaluation or adapter dispatch.

### 3.6 Closed-Candle Invariant (Zero Lookahead)
- Detector and signal-generating domain boundaries strictly consume confirmed, closed candles (`is_closed=True`).
- Unclosed/forming candles raise `UnclosedCandleError` if submitted to signal processing.

### 3.7 AI/LLM Advisory Boundary
- AI metadata (`AIAdvisoryMetadata`) is strictly informational and advisory.
- AI cannot authorize orders, modify risk limits, override Risk Guardian vetoes, disable the kill switch, or select production endpoints.

---

## 4. Test Coverage & Verification

Executed 64 unit tests covering 100% of Phase 1 requirements:
- Safety configuration validation: 9 tests
- Kill switch behavior: 5 tests
- Endpoint guard isolation: 6 tests
- Idempotency deduplication: 5 tests
- Candle model & closed-candle invariant: 9 tests
- Domain model & geometry constraints: 9 tests
- Risk Guardian authoritative evaluation: 9 tests
- Order Execution Manager pipeline: 7 tests
- AI advisory boundary isolation: 5 tests

Total: **64 tests passed, 0 failed, 0 skipped** in 0.12s.  
Code analysis: **Ruff clean (0 errors)**, **Ruff format clean (0 diffs)**, **Mypy strict clean (0 errors across 33 source files)**.

---

## 5. Explicit Non-Goals for Phase 1

The following components were strictly excluded from Phase 1 and deferred to their assigned future phases:
- Binance Futures REST API client (Phase 2)
- Binance Futures WebSocket streaming client (Phase 2)
- Market scanner & pre-pump detector (Phase 3)
- Technical indicators (ATR, RVOL, ADX) (Phase 3)
- Order-book depth imbalance detector (Phase 3)
- Trading strategies (Phase 3)
- Live exchange execution (Permanently Out of Scope)
- PAPER / SHADOW exchange adapter beyond the minimal test mock (Phase 5)
- Telegram alert bot & control handlers (Phase 7)
- FastAPI Mini App & API server (Phase 8)
- PostgreSQL journal persistence (Phase 9)
- Redis pub/sub integration (Phase 2/5)
- Machine learning & proposal generator (Phase 9)
- Frontend / Dashboards (Phase 8)
- Systemd service configurations & deployment scripts (Phase 10)
