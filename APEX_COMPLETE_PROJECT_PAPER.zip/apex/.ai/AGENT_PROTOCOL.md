# APEX — MULTI-AGENT ENGINEERING & SAFETY PROTOCOL

Status: ACTIVE
Version: 1.0
Repository: APEX
Primary branch: main

This document is the authoritative coordination protocol for all AI coding
agents working on APEX.

============================================================
1. CORE PRINCIPLE
============================================================

APEX is an autonomous crypto-futures PAPER/SHADOW system.

Safety takes priority over speed, profitability, token usage, convenience,
or feature completeness.

No agent may weaken a safety invariant to make tests pass or to complete
a feature faster.

The system must remain incapable of live trading unless a future,
explicitly authorized architecture change creates such a capability.

At present:

TRADING_MODE:
    PAPER / SHADOW / DRY_RUN only

LIVE_TRADING_ENABLED:
    MUST remain false

No production trading pathway may be introduced.

============================================================
2. AGENT ROLES
============================================================

CHATGPT
--------
Role:
    Architecture owner, adjudicator, phase gatekeeper.

Responsibilities:
    - Define architecture and phase boundaries.
    - Produce implementation/review instructions.
    - Adjudicate conflicting agent findings.
    - Decide whether findings are real vulnerabilities.
    - Approve phase transitions.
    - Prevent scope creep.
    - Require evidence before certification.

ChatGPT does NOT directly modify the repository.

OPENCode
--------
Role:
    PRIMARY ENGINEERING AGENT.

Responsibilities:
    - Major implementation work.
    - Refactoring authorized by the current phase.
    - Integration work.
    - Large test suites.
    - E2E implementation.
    - Fixing confirmed findings.

OpenCode must obey the current phase scope.

ANTIGRAVITY
-----------
Role:
    INDEPENDENT SECURITY / ARCHITECTURE REVIEWER.

Default authority:
    READ ONLY.

Responsibilities:
    - Adversarial audits.
    - Safety-boundary review.
    - Execution-path review.
    - Live-pathway analysis.
    - RiskGuardian analysis.
    - Kill-switch analysis.
    - Authentication/security review.
    - Independent regression verification.

Antigravity must not silently fix what it finds during an audit.

When explicitly authorized to fix a finding, it may modify only the
specified scope.

JULES
-----
Role:
    ISOLATED INDEPENDENT WORKER.

Responsibilities:
    - Independent tests.
    - Synthetic fixtures.
    - Documentation tasks.
    - Small isolated engineering tasks.
    - Independent verification.
    - GitHub PR-based work.

Jules should normally work in an isolated branch/task.

COPILOT
-------
Role:
    MICRO-ENGINEER / LOCAL ASSISTANT.

Responsibilities:
    - Small deterministic changes.
    - Test additions.
    - Type annotations.
    - Documentation.
    - Boilerplate.
    - Small cleanup tasks.

Copilot must NOT independently redesign:
    - RiskGuardian
    - EndpointGuard
    - KillSwitch
    - OrderExecutionManager
    - live-trading boundaries
    - core risk policy

============================================================
3. AUTHORITY MODEL
============================================================

No single coding agent may self-certify safety-critical work.

Required model:

    BUILD
      |
      v
    AUDIT
      |
      v
    ADJUDICATE
      |
      v
    FIX CONFIRMED FINDINGS
      |
      v
    TEST
      |
      v
    INDEPENDENT RE-AUDIT
      |
      v
    CERTIFY
      |
      v
    COMMIT
      |
      v
    NEXT PHASE

A phase cannot advance merely because tests pass.

============================================================
4. ONE EDITOR AT A TIME
============================================================

NEVER allow two agents to modify the same working tree simultaneously.

Before an agent receives write authority:

    git status --short

must be checked.

After the agent finishes:

    git status --short
    git diff --stat
    git diff --check

must be checked.

If another agent has uncommitted changes, stop.

Do not overwrite another agent's work.

============================================================
5. MAIN BRANCH POLICY
============================================================

main is the protected integration branch.

Do not use main as a scratchpad for experimental work.

Preferred flow:

    feature/phase-X-<agent>
            |
            v
          tests
            |
            v
        independent audit
            |
            v
           PR
            |
            v
          main

For small local tasks, direct work may be permitted only when explicitly
authorized by the phase owner.

Never force-push main.

Never rewrite published history without explicit authorization.

============================================================
6. PHASE CONTRACT
============================================================

Every phase must define:

    PHASE NUMBER
    OBJECTIVE
    IN-SCOPE FILES
    OUT-OF-SCOPE FILES
    SAFETY INVARIANTS
    ACCEPTANCE TESTS
    SECURITY TESTS
    REQUIRED AUDIT
    CERTIFICATION CONDITION

Agents must stop when the phase is complete.

No opportunistic feature additions.

No "while I was here" architecture changes.

============================================================
7. SAFETY-CORE PROTECTION
============================================================

The following components are safety-critical:

    src/apex/safety/
    src/apex/risk/
    src/apex/execution/

Especially:

    RiskGuardian
    EndpointGuard
    KillSwitch
    OrderExecutionManager
    IdempotencyGuard

Changes to these components require explicit phase authorization.

Tests must never be weakened to accommodate unsafe behavior.

============================================================
8. EXECUTION GATE
============================================================

All order execution must ultimately pass through the authoritative path:

    OrderIntent
        |
        v
    structural validation
        |
        v
    idempotency
        |
        v
    KillSwitch
        |
        v
    authoritative RiskGuardian
        |
        v
    EndpointGuard
        |
        v
    Execution Adapter

No caller-supplied approval may authorize execution.

No AI/LLM output may authorize execution.

No Telegram command may bypass this path.

No Mini App command may bypass this path.

No emergency mechanism may create an alternate execution pathway.

Emergency flatten/cancel functionality must use the same controlled
execution architecture while respecting the kill-switch semantics.

============================================================
9. AI BOUNDARY
============================================================

AI is ADVISORY ONLY.

AI may:

    - summarize
    - classify
    - suggest
    - analyze
    - propose parameter changes
    - produce research

AI may NOT:

    - authorize orders
    - bypass RiskGuardian
    - bypass EndpointGuard
    - disable KillSwitch
    - increase hard risk limits
    - increase leverage limits
    - change safety mode
    - select a production endpoint
    - directly submit orders
    - deploy learned strategy changes automatically

Learning systems are proposal generators, not autonomous safety-policy
editors.

============================================================
10. NO LIVE TRADING PATHWAY
============================================================

The current system must not contain a usable production execution route.

Production endpoints such as:

    fapi.binance.com
    api.binance.com
    dapi.binance.com

and their production WebSocket equivalents must not be usable by the
execution layer.

Do not introduce:

    live mode
    production mode
    live adapter
    production fallback
    hidden endpoint override
    environment-variable bypass
    arbitrary caller-controlled execution URL

PAPER/SHADOW/DRY_RUN must fail closed if their safety configuration is
invalid.

============================================================
11. RISK POLICY
============================================================

Risk is determined by deterministic code.

AI cannot alter it.

Current intended sizing principle:

    position_size =
        (risk_percent * current_equity)
        / abs(entry - stop_loss)

Then enforce:

    hard risk cap
    leverage cap
    stop-distance validation
    concurrent-position cap
    exposure/correlation cap
    kill-switch state
    mode safety

Never increase risk merely because:

    - a profit target has not been reached
    - a losing streak occurred
    - a winning streak occurred
    - an AI recommendation says to
    - the account is behind a target

Compounding changes equity-based size naturally; it does not change the
risk percentage.

============================================================
12. DATA SAFETY
============================================================

Market-data logic must:

    - use closed candles/snapshots for decisions
    - reject NaN/Inf
    - handle zero volume
    - handle stale data
    - handle reconnects
    - detect timestamp anomalies
    - prevent lookahead
    - prevent duplicate event execution

Never assume a WebSocket event is unique.

============================================================
13. TESTING STANDARD
============================================================

Required:

    unit tests
    integration tests
    negative tests
    adversarial tests
    regression tests
    E2E tests where applicable

Never:

    - skip a failing test
    - xfail a real failure
    - weaken an assertion merely to pass
    - delete a regression test
    - claim E2E verification without actually performing it

A green test suite is evidence, not proof of safety.

============================================================
14. AUDIT STANDARD
============================================================

Auditors must assume:

    - callers can be malicious
    - configuration can be malformed
    - environment variables can be wrong
    - URLs can be malicious
    - events can duplicate
    - data can become stale
    - AI output is untrusted
    - developers can call lower-level APIs directly

Comments and documentation do not count as enforcement.

Only actual code paths count.

============================================================
15. REQUIRED AUDIT QUESTIONS
============================================================

Every safety audit should answer:

1. Can a production order be submitted?
2. Can EndpointGuard be bypassed?
3. Can RiskGuardian be bypassed?
4. Can a caller fabricate approval?
5. Can a caller inject relaxed risk policy?
6. Can KillSwitch be bypassed?
7. Can duplicate events create duplicate orders?
8. Can AI authorize execution?
9. Can configuration create a live path?
10. Can lower-level adapters be called directly?
11. Can emergency exits bypass safety architecture?
12. Can restart/recovery create duplicate execution?

If any answer is unexpectedly YES, the phase is not certified.

============================================================
16. FINDING SEVERITY
============================================================

CRITICAL
--------
Live pathway, safety bypass, unauthorized execution, RiskGuardian bypass,
EndpointGuard bypass, kill-switch bypass, credential exposure.

HIGH
----
Major safety weakness likely to cause incorrect execution, duplicate
orders, incorrect sizing, unsafe recovery, or unauthorized control.

MEDIUM
------
Meaningful robustness/security deficiency without an immediate execution
bypass.

LOW
---
Documentation, maintainability, or non-safety issue.

============================================================
17. FINDING LIFECYCLE
============================================================

AUDITOR:
    Report only.

CHATGPT:
    Determine whether finding is real.

BUILDER:
    Fix only confirmed findings.

TEST:
    Demonstrate remediation.

AUDITOR:
    Re-audit the remediation.

CHATGPT:
    Certify or reject.

No agent may close its own critical security finding without independent
verification.

============================================================
18. DOCUMENTATION
============================================================

The following are authoritative project-control documents:

    .ai/DECISIONS.md
    .ai/PROJECT_STATE.md
    .ai/TODO.md
    .ai/AGENT_PROTOCOL.md

Agents must read relevant documents before acting.

Do not contradict an explicit safety decision without raising the issue
for adjudication.

============================================================
19. STOP CONDITIONS
============================================================

An agent MUST stop and report if:

    - requested work exceeds phase scope
    - live trading capability is requested
    - safety invariant must be weakened
    - a required dependency is missing
    - repository state is unexpectedly dirty
    - another agent appears to be editing simultaneously
    - tests reveal an unexplained regression
    - production credentials are requested
    - a security finding cannot be resolved safely

============================================================
20. CURRENT PHASE
============================================================

PHASE 1:
    Safety Core + Repository Harness + Foundational Domain Models

Current state:

    Implementation exists locally.
    Tests reported:
        64 passed

    Ruff:
        PASS

    Mypy:
        PASS

    Git:
        UNCOMMITTED

Phase 1 is NOT CERTIFIED yet.

Required next action:

    Independent adversarial security audit.

No Phase 2 implementation begins until Phase 1 certification.

============================================================
21. PHASE GATE
============================================================

A phase is considered CERTIFIED only when:

    [ ] Implementation complete
    [ ] Scope respected
    [ ] Unit tests pass
    [ ] Static analysis passes
    [ ] Adversarial audit complete
    [ ] Critical findings = 0
    [ ] High findings = 0 OR explicitly accepted by architecture owner
    [ ] Required remediation re-tested
    [ ] Independent re-audit complete
    [ ] Git diff reviewed
    [ ] No unauthorized live pathway
    [ ] Documentation updated
    [ ] Architecture owner approves checkpoint

Only then:

    commit
    tag/checkpoint if appropriate
    begin next phase

============================================================
END OF PROTOCOL
============================================================
