# APEX 24/7 — Tactical Data Inventory (Phase 3)

**Generated:** 2026-09-06
**Baseline:** HEAD 1521b55, 680 tests passing

---

## Classification Legend

| Classification | Meaning |
|---|---|
| **REAL** | Fetched from public read-only endpoint; validated parser; fail-safe |
| **ESTIMATED** | Computed from REAL observations (time-series math); explicit None when insufficient |
| **INTERFACE_ONLY** | Data model exists; NO source endpoint; NO fetch implementation |
| **NO_DATA** | Not available; returns None; never fabricated |

---

## 1. Open Interest (OI)

| Aspect | Status |
|---|---|
| **Classification** | **REAL** |
| **Implementation** | `src/apex/market/observations.py:144-166` `parse_open_interest_payload` |
| **Source** | Binance `/fapi/v1/openInterestHist` (public, unauthenticated) |
| **Endpoint** | `build_open_interest_hist_url(symbol, period="5m", limit=30)` |
| **Read-only** | ✅ GET only; no credentials |
| **Symbol coverage** | All USDⓈ-M futures on Binance |
| **Freshness** | Period-based (5m default); last point timestamp in payload |
| **Rate limits** | Public endpoint; subject to Binance IP limits |
| **Failure behavior** | `ObservationUnavailableError` → `fetch_open_interest_history` returns `None` |
| **Provenance** | Raw payload timestamp + `sumOpenInterest` field; parsed to `OpenInterestPoint` |
| **Influences tactical score** | YES — via `oi_expansion_pct` → `TacticalFeatures.oi_expansion_pct` → `TacticalScorer._score` adds `score_weight_oi` (default 10) when `>= oi_expansion_min_pct` (default 5%) |

**Key Code Path:**
```
MarketObservationClient.fetch_open_interest_history()
  → HTTP GET /fapi/v1/openInterestHist
  → parse_open_interest_payload() → tuple[OpenInterestPoint]
  → TacticalObservations.oi_history
  → analytics.oi_expansion_pct() → TacticalFeatures.oi_expansion_pct
  → TacticalScorer._score() → +score_weight_oi if expansion >= threshold
```

---

## 2. Open Interest Velocity

| Aspect | Status |
|---|---|
| **Classification** | **ESTIMATED** |
| **Implementation** | `src/apex/engines/tactical/analytics.py:99-122` `oi_expansion_pct()` |
| **Source** | Derived from `oi_history` (REAL OI observations) |
| **Calculation** | `(last.value - first.value) / first.value * 100` over `config.oi_window_ms` (default 1h) |
| **Freshness** | Bound to latest OI observation timestamp |
| **Failure behavior** | Returns `None` if `< 2` points in window or anchor OI ≤ 0 |
| **Provenance** | Explicit timestamps on each `OpenInterestPoint`; window start logged |
| **Influences tactical score** | YES — same as OI (it IS the OI feature) |

---

## 3. Funding Rate

| Aspect | Status |
|---|---|
| **Classification** | **REAL** |
| **Implementation** | `src/apex/market/observations.py:169-191` `parse_funding_payload` |
| **Source** | Binance `/fapi/v1/fundingRate` (public, unauthenticated) |
| **Endpoint** | `build_funding_rate_url(symbol, limit=30)` |
| **Read-only** | ✅ GET only; no credentials |
| **Symbol coverage** | All USDⓈ-M futures on Binance |
| **Freshness** | Last `fundingTime` in payload (typically 8h intervals) |
| **Rate limits** | Public endpoint; subject to Binance IP limits |
| **Failure behavior** | `ObservationUnavailableError` → `fetch_funding_history` returns `None` |
| **Provenance** | Raw payload `fundingTime` + `fundingRate` field; parsed to `FundingPoint` |
| **Influences tactical score** | YES — via `funding_rate()` → `TacticalFeatures.funding_rate` → `TacticalScorer._score` adds `score_weight_funding` (default 10) when `<= funding_max_rate` (default 0.0005) |

---

## 4. Funding Velocity

| Aspect | Status |
|---|---|
| **Classification** | **INTERFACE_ONLY** (model exists; no computation) |
| **Model** | `FundingPoint` has `timestamp_ms` + `rate`; time-series available in `TacticalObservations.funding_history` |
| **Missing** | No `funding_velocity()` analytics function; no feature field |
| **Could implement** | Rate of change of funding rate over lookback (e.g., `(latest - oldest) / hours`) |
| **Influences tactical score** | NO — not computed, not a feature |

---

## 5. Order Book Depth Skew

| Aspect | Status |
|---|---|
| **Classification** | **REAL** (snapshot) |
| **Implementation** | `src/apex/market/observations.py:194-234` `parse_depth_payload` |
| **Source** | Binance `/fapi/v1/depth` (public, unauthenticated) |
| **Endpoint** | `build_depth_url(symbol, limit=20)` |
| **Read-only** | ✅ GET only; no credentials |
| **Symbol coverage** | All USDⓈ-M futures on Binance |
| **Freshness** | Snapshot at request time; `lastUpdateId` in payload |
| **Rate limits** | Public endpoint; subject to Binance IP limits (weight: 5) |
| **Failure behavior** | `ObservationUnavailableError` → `fetch_depth` returns `None` |
| **Provenance** | Best bid/ask → mid price; bids/asks arrays → `DepthLevel` tuples |
| **Feature** | `depth_imbalance()` → `(ask_notional - bid_notional) / total` within ±`band_pct`/2 of mid |
| **Influences tactical score** | YES — `TacticalScorer._score` adds `score_weight_depth` (default 10) when `depth_imbalance <= -depth_imbalance_min` (bid-heavy, default -0.15); logs "ask-heavy depth (no confluence)" when positive |

**Depth Bands:** Configurable via `TacticalConfig.depth_band_pct` (default 1%). Only levels within `mid ± band_pct/2` counted.

---

## 6. Liquidation Context

| Aspect | Status |
|---|---|
| **Classification** | **INTERFACE_ONLY** |
| **Models** | `LiquidationPoint`, `LiquidationCluster`, `LiquidationContext`, `LiquidationSource` |
| **Parser** | `parse_liquidation_payload()` exists (configurable field names) |
| **Source endpoint** | **NONE** — no public Binance liquidation feed; Coinglass/Bybit/etc. require auth or are unreliable |
| **Fetch implementation** | **NONE** — `MarketObservationClient` has NO `fetch_liquidations()` |
| **Feature** | `liquidation_imbalance_pct()` computes from `TacticalObservations.liquidations` (if provided) |
| **Influences tactical score** | ONLY if `liquidations` manually injected (tests do this); production path: **NO_DATA** |
| **Provenance** | If ever sourced: must set `LiquidationContext.is_estimated=True`, `source=PROXY`, `confidence<1.0` |

---

## 7. Whale Flow Context

| Aspect | Status |
|---|---|
| **Classification** | **INTERFACE_ONLY** |
| **Models** | `WhaleFlowContext`, `WhaleFlowLabelQuality` |
| **Parser** | NONE |
| **Source endpoint** | **NONE** — no free/public on-chain indexer with verified exchange labels |
| **Fetch implementation** | **NONE** |
| **Influences tactical score** | NO — not integrated into `TacticalFeatures` or `TacticalScorer` |
| **Provenance requirements** | If ever implemented: `label_quality` (VERIFIED_EXCHANGE_LABEL / HEURISTIC / UNKNOWN), `source`, `confidence`, `is_estimated=True` |

---

## Current Integration Gap

**The tactical observations are NOT being fetched during scanning.**

```python
# src/apex/runtime/engine.py:384-401
def _build_advisory_context(self, symbol, timeframe, series):
    htf = _Timeframe.H1 if timeframe != _Timeframe.H1.value else _Timeframe.H4
    return TacticalContext(htf_timeframe=htf).build(symbol, timeframe, series)
    # observations=None — NO market observations fetched!
```

**SignalOrchestrator** calls `context_builder(symbol, timeframe, series)` without observations.

**MarketObservationClient** is instantiated in `run_service.py` but never passed to engine.

---

## Priority Implementation Order (Phase 4)

| Priority | Signal | Status | Action |
|---|---|---|---|
| **A** | Open Interest | REAL (endpoint exists, not wired) | Wire `MarketObservationClient` into scan tick; fetch OI for each symbol |
| **B** | Funding Velocity | INTERFACE_ONLY (data exists, no computation) | Add `funding_velocity()` analytics; add feature field |
| **C** | Order Book Depth Skew | REAL (endpoint exists, not wired) | Wire depth fetch; already has feature + scorer integration |

---

## Phase 5/6 Decision Matrix

| Signal | Public Source Exists? | Recommendation |
|---|---|---|
| Liquidations | NO (Coinglass requires auth; no reliable free feed) | Keep `LiquidationContext` as `is_estimated=True`, `source=PROXY`, `confidence=0.0`; return `NO_DATA` |
| Whale Flow | NO (no free verified exchange labels) | Keep `WhaleFlowContext` as `label_quality=UNKNOWN`, `source=UNAVAILABLE`, `confidence=0.0`; return `NO_DATA` |

---

## Next Steps

1. **Phase 4A**: Wire `MarketObservationClient` into engine scan tick for OI + Funding + Depth
2. **Phase 4B**: Add `funding_velocity` analytics + feature
3. **Phase 7**: Verify `TacticalScorer` advisory-only firewall (already solid)
4. **Phase 8**: Add adversarial transport tests for OI/Funding/Depth endpoints