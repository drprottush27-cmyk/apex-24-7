# APEX 24/7 — TODO

## Phase 0 — Foundation & Architecture Audit (COMPLETED)

- [x] Complete repository architecture audit
- [x] Define application package structure
- [x] Define state machines
- [x] Define safety contracts
- [x] Define test strategy
- [x] Define configuration contract

## Phase 1 — Safety Core & Repository Harness (COMPLETED)

- [x] Configure `pyproject.toml` and Python 3.12 build harness
- [x] Implement foundational domain models (`Candle`, `Signal`, `OrderIntent`, `Position`, `types`)
- [x] Implement strict closed-candle invariant (`ensure_closed()`, `require_closed_candle()`)
- [x] Implement fail-safe `KillSwitch` with permitted flattening path
- [x] Implement `EndpointGuard` production isolation and URL allowlists
- [x] Implement deterministic `IdempotencyGuard` event deduplication
- [x] Implement authoritative `RiskGuardian` veto engine
- [x] Implement `OrderExecutionManager` linear gateway
- [x] Establish and test AI advisory boundary (zero authorization power)
- [x] Configure strict `ApexConfig` (hard-reject `LIVE` and `live_trading_enabled=True`)
- [x] Build comprehensive Phase 1 test suite (64 unit tests, 100% pass rate)

## Phase 2 — Pre-Pump Detector (COMPLETED)

- [x] `engines/prepump`: deterministic 2-of-3 agreement pre-pump detector
- [x] `indicators`: EMA, ATR, RSI, ADX, RVOL, BB, pivots
- [x] Detector test suite

## Phase 3 — Market Data Foundation (COMPLETED)

- [x] `MarketClient`, normalization, discovery, historical klines
- [x] `CandleSeries` strict closed-candle invariant (closed, positive volume, increasing timestamps)
- [x] Data-health quality gate (freshness, missing intervals, anomalies)

## Phase 4 — Runtime Scan & Signal Orchestration (COMPLETED)

- [x] `runtime/state.py` deterministic fail-closed state machine
- [x] `runtime/scheduler.py` deterministic scan scheduler (no overlap, pause/resume, shutdown)
- [x] `runtime/orchestrator.py` signal orchestration with quality gate (observational only)
- [x] `runtime/clock.py` injectable Clock/Sleeper + mocks

## Phase 5 — PAPER Execution Service (COMPLETED)

- [x] `execution/oem.py`, `adapter.py`, `paper_adapter.py` linear gateway
- [x] `runtime/paper_service.py` PAPER fill simulation with tracker adoption
- [x] `runtime/execution_journal.py` typed execution event records

## Phase 6 — Position Lifecycle & Danger Protocol (COMPLETED)

- [x] `runtime/position_tracker.py` mark-to-market tracking, hard SL/TP
- [x] `runtime/position_state.py`, `danger.py` state machine + danger assessment
- [x] Reconciliation and crash consistency

## Phase 7 — Crash Recovery (COMPLETED)

- [x] `persistence/journal.py` `PersistentJournal` (SQLite), replayable event log
- [x] `persistence/recovery.py` `CrashRecovery` startup replay/reconciliation
- [x] `safety/idempotency.py` persistent duplicate-event protection

## Phase 8 — Engine Integration (COMPLETED)

- [x] `runtime/engine.py` `ApexEngine` unified authority boundary (scan → risk veto → OEM → EndpointGuard → paper fill → tracker)
- [x] `runtime/scanner.py` universe scan with per-symbol outcomes
- [x] `tests/unit/test_phase8_integration.py` engine integration suite
- [x] No execution bypass surface on the engine

## Phase 9 — Trade Journal & Human-Gated Learning Proposals (COMPLETED)

- [x] `journal/` append-only SQLite journal (`ClosedTradeRecord`, `record_hash` dedup, no UPDATE/DELETE)
- [x] `learning/analyzer.py` performance metrics (win rate, expectancy, PF, drawdown)
- [x] `learning/proposals.py` review-only proposals — thresholds clamped `>= current`, never loosen risk
- [x] No write primitives in the learning package; `DRAFT_FOR_REVIEW` requires human approval
- [x] `tests/unit/test_phase9_journal_learning.py` (22 tests)

## Phase 11 — Position Danger Protocol: Fail-Safe Close (COMPLETED)

- [x] `runtime/danger.py` pure `evaluate_position_danger` → `PositionDangerAssessment` (deterministic gate order; FAIL_SAFE_CLOSE / RECONCILE_ONLY semantics)
- [x] `runtime/danger_manager.py` OEM-only fail-safe close coordinator (journal-first, EXITING pre-transition, canonical EXIT intent, restart/duplicate prevention)
- [x] `risk/guardian.py` EXIT-aware branch (non-ENTRY risk-reducing; ENTRY fully gated; kill switch never blocks flattening)
- [x] `runtime/engine.py` `danger_manage_position` + explicit persistent-failure journaling
- [x] `config/settings.py` `danger_stale_threshold_ms` bounded setting
- [x] `runtime/execution_journal.py` Phase 11 event types
- [x] `tests/unit/test_phase11_danger_protocol.py` (48 tests)
- [x] 548/548 tests passing; `ruff check`, `mypy src`, `mypy tests`, `git diff --check` all clean

## Phase 10 — Full E2E Validation & Continuous Autonomous Run (COMPLETED)

- [x] `tests/e2e/test_full_lifecycle.py` full lifecycle + failure injection + stability/determinism + ADR sign-off (15 tests)
- [x] `scripts/run_paper.py` deterministic offline continuous autonomous PAPER session
- [x] 500/500 tests passing; `ruff check`, `mypy src`, `mypy tests`, `git diff --check` all clean
- [x] Safety audit: no skips/xfails, no silent exception swallowing, no write capability in learning modules

## Phase 12 — Tactical Confluence Analytics (COMPLETED)

- [x] `engines/tactical/model.py` — `TacticalConfig`, observation dataclasses, `TacticalFeatures`, `TacticalVerdict`, `TacticalResult`
- [x] `engines/tactical/analytics.py` — pure deterministic feature functions (BBW percentile, directional bias, OI expansion, funding, depth, liquidation imbalance)
- [x] `engines/tactical/scorer.py` — `TacticalScorer.evaluate()` (0–100 advisory score, verdict, reasons)
- [x] `tests/unit/test_phase12_tactical_analytics.py` (19 tests)
- [x] Advisory only — never an order input; closed-candle/no-lookahead verified in tests

## Phase 13 — Multi-Timeframe Signals & Advisory Context (COMPLETED)

- [x] `engines/tactical/mtf.py` — `HtfTrend`, `HtfTrendConfluence`, complete-bucket-only resampler, EMA 9/21 confluence
- [x] `engines/tactical/context.py` — `TacticalContext.build()` combined advisory metadata
- [x] `runtime/orchestrator.py` — optional `context_builder` callable; `advisory_context` in evidence metadata (exceptions → None, never breaks signal)
- [x] `runtime/engine.py` — `_build_advisory_context` wiring with H1→H4 fallback
- [x] `tests/unit/test_phase13_tactical_context.py` (11 tests)

## Phase 14 — Market Observations (COMPLETED)

- [x] `market/observations.py` — read-only public endpoints (OI history, funding, depth); strict parsers; `MarketObservationClient` fully fail-safe
- [x] `tests/unit/test_phase14_observations.py` (11 tests, `MockTransport`)
- [x] No execution surface; data reads only (mirrors existing `binance_http.py` behavior)

## Phase 15 — 24/7 Operational Hardening (COMPLETED)

- [x] `runtime/observability.py` — structured JSON logging (`JsonLogger` never raises; `CapturingLogger` for tests)
- [x] `runtime/health.py` — `RuntimeHealthMonitor` data/execution health gates, `HealthSnapshot`, fail-closed semantics
- [x] `runtime/engine.py` — health monitoring wired into scan ticks + equity-failure path; `get_health()` API
- [x] `scripts/run_service.py` — foreground 24/7 PAPER service (scheduled scans, JSON logs, graceful shutdown, restart-proof journal/idempotency, offline default)
- [x] `tests/unit/test_phase15_observability.py` (10) + `tests/unit/test_phase15_engine_health.py` (2)
- [x] 601/601 tests passing; ruff/mypy/diff-check clean; offline service smoke clean

## Phase 16 — Documentation (COMPLETED)

- [x] `.ai/PROJECT_STATE.md` updated with Phases 12–15
- [x] `.ai/TODO.md` updated with Phases 12–16
- [x] `README.md` rewritten (counts, safety invariants)
- [x] `docs/OPERATIONS.md` — 24/7 PAPER service operations guide

## Audit Remediation — Autonomous Management & Operational Hardening (COMPLETED)

Remediates the verified findings from `.ai/FINAL_NARROW_AUDIT_REPORT.md`; every
change is proven by regression tests (see `decision_record` in
`.ai/DECISIONS.md`).

- [x] `runtime/engine.py` — autonomous open-position management wired into every
      scan tick (`_manage_open_positions` runs FIRST, before scanning): closed
      candle → last-close mark-to-market → `danger_manage_position` → TP/SL /
      fail-safe exits all routed through RiskGuardian → OEM → EndpointGuard.
      Management failures folded into scan health (`data_failed` /
      `execution_failed`) so a failed management cycle can never be masked by
      a healthy scan.
- [x] `runtime/engine.py` — crash recovery wired into `start()`: corrupt
      position snapshots or failed reconciliation abort startup (fail-closed),
      open positions reconstructed and management resumes after restart,
      duplicate restarts rejected by the persistent idempotency guard.
- [x] `runtime/engine.py` + `journal/` — TradeJournal runtime wiring: engine
      appends closed-trade records with full exit context on TP/SL/fail-safe
      closes (requires valid `exit_price`; otherwise journals EXECUTION_ERROR,
      never silent).
- [x] `runtime/danger_manager.py` — `DangerCloseResult.exit_price` so exit
      price is never fabricated by callers; document recovery/`RECONCILIATION_REQUIRED`
      path following a fail-safe close.
- [x] `runtime/position_state.py` — `RECONCILIATION_REQUIRED` added as valid
      next state for all open states (fail-closed bin during recovery).
- [x] `runtime/state.py` — `_SCANNING_PERMITTED` = {SCANNING, DATA_CONNECTING};
      PAUSED halts ALL autonomous scanning and management (fail-closed);
      resumes still valid.
- [x] `runtime/health.py` — `HealthStatus.NO_DATA` gate: consecutive data
      failures with zero usable symbols no longer read as HEALTHY; snapshot
      carries `available_symbols`/`total_symbols`; overall DEGRADED on NO_DATA.
- [x] `persistence/journal.py` — `execution_symbols()` as authoritative source
      for idempotency reconstruction after restart.
- [x] `persistence/recovery.py` — corrupt snapshots / reconciliation failures
      counted and surfaced (never silent); `CrashRecovery.recover()` reports
      them to the engine for fail-closed abort.
- [x] `scripts/run_paper.py` — rewritten: synthetic client with a fixed base
      timestamp + price override driver (no shared lookahead clock); positions
      are managed to TP by the ENGINE, never closed directly by the script.
- [x] `scripts/run_service.py` — `--market-client {offline,binance}` +
      `APEX_MARKET_DATA_CLIENT` env; binance wires the read-only public
      MarketClient (GET-only STDlib transport, no credentials, no signing);
      TradeJournal wired to the engine; `docs/OPERATIONS.md` updated.
- [x] Tests: `tests/unit/test_phase8_autonomous_management.py` (9 new);
      `tests/unit/test_phase7_persistence.py` recovery hardening;
      `tests/unit/test_phase15_observability.py` NO_DATA tests;
      `tests/test_phase4_runtime.py` state-gating tests; shared e2e fixtures
      re-anchored to fresh timestamps so management sees fresh (not stale)
      candles.
- [x] Final gates: 621 passed; ruff clean; mypy src/tests clean;
      `git diff --check` clean; forensics clean (single scheduler, no order
      endpoints, no signing/credentials, no live flags, no bypasses).

## Phase 25.1 — Production Hardening Pass (COMPLETED)

Fix + fail-closed hardening of post-checkpoint `1521b55` changes. Commit `11eeeca`.

- [x] PositionTracker stale-snapshot resurrection guard: `mark_to_market`,
      `update_stop_loss`, `apply_breakeven` re-read authoritative tracked
      position and no-op when the position is no longer active. A stale
      snapshot can never resurrect a closed position back to OPEN.
      5 regression tests (`TestStaleSnapshotGuard`).
- [x] `RealTimePositionManager._execute_autoclose` engine-less fallback made
      fail-closed: previously closed directly via `tracker.close_position`,
      bypassing the OEM/RiskGuardian/EndpointGuard chain (constitution
      violation). Now logs CRITICAL and refuses the unguarded close.
      Regression test `test_evaluate_second_no_engine_fails_closed`.
- [x] `auto_trade.py` volatility-surge ATR `except Exception: pass` changed to
      an explicit `logger.warning(...)` (no silent exception swallowing).
- [x] Cleared (no change): `PaperExecutionFailure(intent=None)` valid;
      `evaluate_second` SL-breach operator precedence correct; engine-less
      autoclose path unreachable in production; consecutive-loss counter
      fail-closed; `run_service.py` has no double-drive (`engine.start()` is
      state-only); API `CLOSE_NOW` routes through `force_close_position` OEM
      chain; `WeightLimiter` thread-safe; dashboard silent ticker swallows are
      read-only observability (documented, not safety-relevant).
- [x] Final gates: 751/751 tests passed; ruff clean; mypy src/tests/scripts
      clean; `git diff --check` clean.

## Remaining TODO (out of strict scope — documented, not actioned)

- [ ] `_init_daily_baseline` `except Exception: pass` in `engine.py` (pre-1521b55):
      equity-provider failure leaves daily baseline unset (drawdown kill switch
      inert until a subsequent success). Pre-existing; candidate for a future
      hardening pass.
- [ ] Cross-thread tracker access is guarded per-method; a coarse per-position
      lock on `PositionTracker` (read path is the hot path) is a candidate
      future improvement, not a verified defect.
- [ ] `scripts/run_service.py` silently falls back to `[BTCUSDT, ETHUSDT]` when
      auto-discovery raises; fails safe (smaller universe) but could log.

## Next Phase

- [ ] Independent review of Phase 25.1 changes (one agent edits at a time).
      Monitor the 24h run; re-certify at next scheduled checkpoint.

## Production Readiness Remediation — DATA-1 / DATA-3 / REC-1 (COMPLETED)

Remediates the three MEDIUM findings from
`.ai/FINAL_PRODUCTION_READINESS_AUDIT.md` (report:
`.ai/PRODUCTION_READINESS_REMEDIATION_REPORT.md`).

- [x] DATA-1 — `runtime/scanner.py`: `MarketScanResult.symbols_skipped`
      (no-data skips counted separately from hard errors); `runtime/health.py`:
      `HealthSnapshot.skipped_symbols`/`failed_symbols` in snapshot +
      `to_metadata()`; `record_scan` accepts the counts; `runtime/engine.py`:
      `_scan_tick` folds `symbols_skipped > 0` into the data-failure gate so a
      full-universe no-data scan can never read as HEALTHY.
- [x] DATA-3 — `market/quality.py`: `timeframe_interval_ms()` +
      deterministic `now_ms` on `check_freshness`/`run_quality_gate`;
      `runtime/orchestrator.py`: entry gate `check_fresh=True`,
      `stale_threshold_ms = 2 * interval`, `expected_interval_ms = interval`,
      clock-driven `now_ms` (previously `check_fresh=False`).
- [x] REC-1 — `persistence/recovery.py`: unmatched executed events
      (`PAPER_FILL`/`PAPER_POSITION_OPENED` with no backing snapshot) detected
      via `intent_id`↔`source_signal_id` / `receipt_id`↔`execution_receipt_id`
      over `all_positions()` (incl. CLOSED); `unmatched_executed_events` count
      folded into `reconciliation_failures`; `runtime/engine.py` fail-closed
      abort message updated.
- [x] Regression tests (19 new): scanner skipped-counting; health skipped/
      failed snapshot + NO_DATA full-universe-skip; engine full-skip NO_DATA,
      partial-skip DEGRADED, stale-feed blocked (no execution); orchestrator
      recent-past accepted / >2-interval rejected / missing-interval rejected;
      quality `now_ms` determinism + timeframe-aware intervals; recovery
      unmatched/backed-by-open/backed-by-closed/receipt-only/intent-only;
      engine startup abort on unmatched executed event.
- [x] Fixture re-anchoring (test-only): phase11 + autonomous-management series
      anchored to freshly closed candles so ENTRIES see fresh data; stale-feed
      danger-close test opens fresh then makes the feed stale.
- [x] Final gates: 640 passed; ruff clean; mypy src/tests/scripts clean;
      `git diff --check` clean; run_paper + run_service offline smokes clean;
      forensics clean (zero-network paper adapter, allowlist-only EndpointGuard,
      no background threads, AI advisory-only, no credentials/signing).

## Production Paper Readiness Remediation — FINDINGS A, B, C, DUR-1, DATA-2 (COMPLETED)

Remediates all findings from the production paper-readiness forensic evaluation:

- [x] FINDING A — Daily Drawdown Kill Protection Wired and Persisted:
      - `PositionTracker.build_portfolio(equity)` computes and passes `daily_drawdown_pct`.
      - `PositionTracker` tracks UTC day index (`DAY_MS = 86_400_000`, `daily_start_day`) and rolls over automatically.
      - `RiskGuardian` vetoes new entries when `daily_drawdown_pct >= config.daily_drawdown_kill_pct` while allowing exits.
      - `ApexEngine.start()` initializes baseline; `ApexEngine._scan_tick()` triggers fail-closed kill switch on breach.
      - Daily baseline persists in SQLite `journal_meta` and restores on restart across same UTC day.
- [x] FINDING B — Post-Restart Entry Risk Evaluation Exposure Reconstruction:
      - `PaperExecutionService` delegates `paper_positions` and `build_portfolio_state(equity)` directly to `PositionTracker`.
      - `execute_signal` evaluates risk against reconstructed portfolio rather than isolated empty list.
      - Concurrent position limits and leverage caps enforced post-restart.
- [x] FINDING C — Recovery Orphan Execution & Fail-Safe Close Window:
      - `_EXECUTED_EVENT_TYPES` includes `FAIL_SAFE_CLOSE`.
      - Exit idempotency keys reconstructed during recovery.
      - `CrashRecovery` fails closed if exit snapshot is missing or remains in non-CLOSED status.
      - Recovery increments `reconciliation_failures` if an executed event's idempotency key is unparseable.
- [x] DUR-1 — Persistent Journal SQLite Pragmas:
      - Configured `PRAGMA journal_mode=WAL`, `PRAGMA synchronous=FULL`, `PRAGMA foreign_keys=ON`.
      - Added key-value metadata store `set_meta` / `get_meta` on `PersistentJournal`.
- [x] DATA-2 — Scanner Equity Provider Failure Data Health:
      - `FullMarketScanner` sanitizes equity provider failures/non-positive equity to `0.0`.
      - `ApexEngine._scan_tick()` folds `"invalid equity"` rejections into `data_failed`, causing health monitor to flag degraded/unhealthy data state.
- [x] Regression tests (18 new, 658 total):
      - `test_risk_guardian.py`: entry vetoed on drawdown breach; exit permitted on drawdown breach.
      - `test_phase6_position_lifecycle.py`: `build_portfolio` computes drawdown; UTC day rollover resets baseline; profit drawdown is 0; `update_daily_baseline` logic.
      - `test_phase5_paper_execution.py`: portfolio delegation to tracker; recovered tracker enforces concurrent position limits.
      - `test_phase7_persistence.py`: SQLite pragmas; `journal_meta` get/set; `FAIL_SAFE_CLOSE` idempotency reconstruction; `FAIL_SAFE_CLOSE` without snapshot fails closed; `FAIL_SAFE_CLOSE` with unclosed snapshot fails closed; unparseable idempotency fails closed; daily baseline restored from metadata.
      - `test_phase8_integration.py`: post-restart entry risk evaluation respects recovered positions; engine trips kill switch on daily drawdown breach.
      - `test_phase15_engine_health.py`: equity provider failure marks data health degraded.
- [x] Final gates: 658 passed; ruff clean; mypy src/tests/scripts clean;
      `git diff --check` clean; run_paper (5 ticks) + run_service offline (3 ticks) clean;
      forensics clean (PAPER/SHADOW only, zero credentials/signing, zero live endpoints).

## Phase 17A — Targeted Operational Remediation (COMPLETED)

- [x] BLOCKER 1 — Kline Normalization (12-field Binance USDⓈ-M Futures REST response):
      - `src/apex/market/normalize.py`: `normalize_kline()` accepts 11 or 12 fields (ignoring 12th unused field).
      - Strict OHLCV timestamp alignment and validation preserved without field shifting.
      - 7 new regression tests in `tests/unit/test_phase3_normalize.py` (TestTwelveFieldKline).
- [x] BLOCKER 2 — HTTP Rate-Limit Resilience (ResilientHTTPTransport):
      - `src/apex/market/transport.py`: `ResilientHTTPTransport` implements `HTTPTransport` protocol.
      - Public GET only (mutating methods assert and fail closed).
      - HTTP 429 rate limit exponential backoff with Retry-After header parsing.
      - HTTP 418 IP-ban immediate fail closed unless bounded Retry-After provided.
      - Bounded retries and explicit timeouts (no infinite loops or retry storms).
      - 9 new regression tests in `tests/unit/test_resilient_transport.py`.
- [x] Total test suite expanded to 674 passed; ruff and mypy clean.

## Phase 17B — Controlled Real-Data PAPER Soak (COMPLETED)

- [x] 30-minute controlled real Binance PAPER soak executed with 4 liquid symbols (BTCUSDT, ETHUSDT, SOLUSDT, BNBUSDT).
- [x] 31 / 31 ticks completed cleanly at 60s interval; 124 REST fetches, 0 errors, 0 rate-limits (0 429s, 0 418s).
- [x] Zero resource leaks: RSS stable at 36.1 MB, 12 open file descriptors, <0.6s total CPU time consumed.
- [x] Natural selectivity preserved ("NO NATURAL SIGNAL DURING SOAK"); zero manufactured trades.
- [x] Clean graceful shutdown (exit code 0); SQLite database integrity verified.
- [x] Post-soak restart validation executed cleanly against persisted soak state.

## Master Production Hardening & System Audit (COMPLETED)

- [x] REC-3 — Position Snapshot Completeness:
      - `src/apex/persistence/recovery.py`: `_deserialize_position()` uses full `Position.model_validate()` preserving `remaining_quantity`, `breakeven_moved`, `danger_level`, `unrealized_pnl`, with fallback to `create_position` for legacy records.
      - Tested with round-trip and legacy fallback tests in `tests/unit/test_phase7_persistence.py`.
- [x] Future Market Intelligence Interfaces (Liquidation & Whale Flow):
      - `src/apex/engines/tactical/model.py`: Added `LiquidationContext`, `LiquidationCluster`, `LiquidationSource`, `WhaleFlowContext`, `WhaleFlowLabelQuality`.
      - Strict numeric bounds, no fabricated precision (`is_estimated=True`), explicit wallet attribution labeling.
      - Tested in `tests/unit/test_phase12_tactical_analytics.py`.
- [x] Total test suite expanded to 680 passed; ruff clean; mypy clean.
