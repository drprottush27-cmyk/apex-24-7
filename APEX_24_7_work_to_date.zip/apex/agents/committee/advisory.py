"""Advisory committee agent — P2-21.

Advisory-only, deterministic, fail-closed.  Provides a local advisory
committee summary that can be used to enrich the orchestrator's
FINAL_REVIEW stage.  This is distinct from ``orch.committee.AgentCommittee``
which is the orchestrator-level advisory committee.  This agent provides
a per-symbol advisory committee opinion that can be consumed by the
orchestrator pipeline.

No network calls, no credential access, no execution authority.  Invalid
or insufficient data fails closed to an inconclusive advisory outcome.
"""

from enum import Enum
from typing import List, Optional, Dict, Any
from dataclasses import dataclass

from core.logging.logger import logger


class CommitteeVote(str, Enum):
    APPROVE = "APPROVE"
    REJECT = "REJECT"
    ABSTAIN = "ABSTAIN"


@dataclass(frozen=True)
class AdvisoryOpinion:
    """A single advisory committee member's opinion."""
    member_name: str
    vote: CommitteeVote
    reasoning: str


@dataclass(frozen=True)
class CommitteeVerdict:
    """Immutable advisory committee verdict."""
    symbol: str
    opinions: List[AdvisoryOpinion]
    final_verdict: str
    confidence: float
    summary: str
    advisory_only: bool = True


class AdvisoryCommitteeAgent:
    """Deterministic, hermetic, advisory-only committee agent.

    Aggregates multiple advisory opinions into a structured committee
    verdict.  The verdict is purely advisory — it has no authority over
    the deterministic SafetyReviewer or Risk Guardian.

    This agent exists at the ``agents/`` layer to provide a local
    advisory committee perspective that may enrich the orchestrator's
    advisory pipeline.
    """

    DEFAULT_MEMBERS = [
        "SENTIMENT_COMMITTEE_MEMBER",
        "TECHNICAL_COMMITTEE_MEMBER",
        "RISK_COMMITTEE_MEMBER",
    ]

    def __init__(self, members: Optional[List[str]] = None):
        self._members = members or list(self.DEFAULT_MEMBERS)

    def deliberate(
        self,
        symbol: str,
        technical_bias: Optional[str] = None,
        sentiment_bias: Optional[str] = None,
        risk_approved: Optional[bool] = None,
        additional_context: Optional[Dict[str, Any]] = None,
    ) -> CommitteeVerdict:
        """Produce an advisory committee verdict for *symbol*.

        Each member independently assesses the provided context and votes.
        The aggregation follows a fail-closed consensus rule: any REJECT
        yields a REJECTED verdict, and insufficient usable votes yields
        INCONCLUSIVE.
        """
        sym = symbol.upper() if isinstance(symbol, str) else "UNKNOWN"
        opinions: List[AdvisoryOpinion] = []

        for member in self._members:
            opinion = self._member_opinion(member, technical_bias, sentiment_bias, risk_approved, additional_context)
            if opinion:
                opinions.append(opinion)

        final, confidence = self._aggregate(opinions)
        summary = self._build_summary(sym, final, confidence, opinions)

        logger.info("advisory_committee_complete", symbol=sym, verdict=final, confidence=round(confidence, 3))

        return CommitteeVerdict(
            symbol=sym,
            opinions=opinions,
            final_verdict=final,
            confidence=round(confidence, 4),
            summary=summary,
        )

    def _member_opinion(
        self,
        member: str,
        technical_bias: Optional[str],
        sentiment_bias: Optional[str],
        risk_approved: Optional[bool],
        additional_context: Optional[Dict[str, Any]],
    ) -> Optional[AdvisoryOpinion]:
        if member == "SENTIMENT_COMMITTEE_MEMBER":
            return self._sentiment_opinion(sentiment_bias)
        if member == "TECHNICAL_COMMITTEE_MEMBER":
            return self._technical_opinion(technical_bias)
        if member == "RISK_COMMITTEE_MEMBER":
            return self._risk_opinion(risk_approved)
        if additional_context and member in additional_context:
            ctx = additional_context[member]
            if isinstance(ctx, dict):
                vote_str = ctx.get("vote", "ABSTAIN").upper()
                try:
                    vote = CommitteeVote(vote_str)
                except ValueError:
                    vote = CommitteeVote.ABSTAIN
                return AdvisoryOpinion(
                    member_name=member,
                    vote=vote,
                    reasoning=ctx.get("reasoning", "No reasoning provided."),
                )
        return AdvisoryOpinion(
            member_name=member,
            vote=CommitteeVote.ABSTAIN,
            reasoning="Insufficient data to form opinion.",
        )

    def _sentiment_opinion(self, sentiment_bias: Optional[str]) -> AdvisoryOpinion:
        if sentiment_bias is None:
            return AdvisoryOpinion(
                member_name="SENTIMENT_COMMITTEE_MEMBER",
                vote=CommitteeVote.ABSTAIN,
                reasoning="No sentiment data available.",
            )
        bias = sentiment_bias.upper()
        if "BULLISH" in bias and "BEARISH" not in bias:
            return AdvisoryOpinion(
                member_name="SENTIMENT_COMMITTEE_MEMBER",
                vote=CommitteeVote.APPROVE,
                reasoning=f"Sentiment bias is {bias} — supports long positioning.",
            )
        if "BEARISH" in bias and "BULLISH" not in bias:
            return AdvisoryOpinion(
                member_name="SENTIMENT_COMMITTEE_MEMBER",
                vote=CommitteeVote.REJECT,
                reasoning=f"Sentiment bias is {bias} — opposes long positioning.",
            )
        return AdvisoryOpinion(
            member_name="SENTIMENT_COMMITTEE_MEMBER",
            vote=CommitteeVote.ABSTAIN,
            reasoning=f"Sentiment bias is {bias} — inconclusive.",
        )

    def _technical_opinion(self, technical_bias: Optional[str]) -> AdvisoryOpinion:
        if technical_bias is None:
            return AdvisoryOpinion(
                member_name="TECHNICAL_COMMITTEE_MEMBER",
                vote=CommitteeVote.ABSTAIN,
                reasoning="No technical data available.",
            )
        bias = technical_bias.upper()
        if "BULLISH" in bias and "BEARISH" not in bias:
            return AdvisoryOpinion(
                member_name="TECHNICAL_COMMITTEE_MEMBER",
                vote=CommitteeVote.APPROVE,
                reasoning=f"Technical analysis shows {bias} bias.",
            )
        if "BEARISH" in bias and "BULLISH" not in bias:
            return AdvisoryOpinion(
                member_name="TECHNICAL_COMMITTEE_MEMBER",
                vote=CommitteeVote.REJECT,
                reasoning=f"Technical analysis shows {bias} bias.",
            )
        return AdvisoryOpinion(
            member_name="TECHNICAL_COMMITTEE_MEMBER",
            vote=CommitteeVote.ABSTAIN,
            reasoning=f"Technical analysis shows {bias} — inconclusive.",
        )

    def _risk_opinion(self, risk_approved: Optional[bool]) -> AdvisoryOpinion:
        if risk_approved is None:
            return AdvisoryOpinion(
                member_name="RISK_COMMITTEE_MEMBER",
                vote=CommitteeVote.ABSTAIN,
                reasoning="No risk assessment available.",
            )
        if risk_approved:
            return AdvisoryOpinion(
                member_name="RISK_COMMITTEE_MEMBER",
                vote=CommitteeVote.APPROVE,
                reasoning="Risk Guardian approved — risk parameters within tolerance.",
            )
        return AdvisoryOpinion(
            member_name="RISK_COMMITTEE_MEMBER",
            vote=CommitteeVote.REJECT,
            reasoning="Risk Guardian rejected — risk parameters breached.",
        )

    def _aggregate(self, opinions: List[AdvisoryOpinion]) -> tuple:
        if not opinions:
            return "INCONCLUSIVE", 0.0
        usable = [o for o in opinions if o.vote != CommitteeVote.ABSTAIN]
        if len(usable) == 0:
            return "INCONCLUSIVE", 0.0
        rejects = [o for o in usable if o.vote == CommitteeVote.REJECT]
        approves = [o for o in usable if o.vote == CommitteeVote.APPROVE]
        if rejects:
            return "REJECTED", len(rejects) / len(opinions)
        if approves:
            return "APPROVED", len(approves) / len(opinions)
        return "INCONCLUSIVE", 0.0

    def _build_summary(self, symbol: str, verdict: str, confidence: float, opinions: List[AdvisoryOpinion]) -> str:
        usable = [o for o in opinions if o.vote != CommitteeVote.ABSTAIN]
        return (
            f"Advisory committee for {symbol}: {verdict} "
            f"(confidence={confidence:.1%}, opinions={len(opinions)}, "
            f"usable={len(usable)}). "
            f"ADVISORY ONLY — no execution authority."
        )
