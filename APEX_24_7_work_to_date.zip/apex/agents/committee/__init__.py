"""Advisory committee agent — local agent-side wrapper."""
