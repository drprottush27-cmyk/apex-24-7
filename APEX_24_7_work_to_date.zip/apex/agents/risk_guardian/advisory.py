"""Risk guardian advisory agent — P2-21.

Advisory-only, deterministic, fail-closed.  Wraps the deterministic
``engines.risk.guardian.RiskGuardian`` to provide supplementary risk
commentary and context.  This agent has NO veto authority — the real
RiskGuardian retains full execution veto.  It produces advisory risk
assessments for informational purposes only.  No network calls, no
credential access.
"""

import math
from typing import List, Optional, Dict, Any
from dataclasses import dataclass

from core.logging.logger import logger
from engines.risk.guardian import RiskGuardian, RiskCheckResult


@dataclass(frozen=True)
class RiskAdvisoryCommentary:
    """Immutable advisory risk commentary."""
    symbol: str
    approved: bool
    risk_score: float
    commentary: List[str]
    original_reason: str
    original_checks_passed: List[str]
    original_checks_failed: List[str]
    advisory_only: bool = True


class RiskAdvisoryAgent:
    """Deterministic, hermetic, advisory-only risk commentary agent.

    Wraps the existing ``RiskGuardian.evaluate_order`` and augments its
    result with supplementary advisory commentary.  This agent has ZERO
    execution authority and ZERO veto power — the deterministic RiskGuardian
    remains the sole authority on order approval/rejection.

    This agent exists purely to enrich the advisory pipeline with additional
    risk context (e.g. equity utilization commentary, position concentration
    notes) that may be surfaced in dashboards or notifications.
    """

    def __init__(self, risk_guardian: Optional[RiskGuardian] = None):
        self._risk_guardian = risk_guardian or RiskGuardian()

    def assess(
        self,
        symbol: str,
        risk_check: RiskCheckResult,
        portfolio_equity: float,
        open_positions_count: int,
        daily_pnl_pct: float,
    ) -> RiskAdvisoryCommentary:
        """Produce advisory risk commentary based on a RiskGuardian result.

        This does NOT replace or override the RiskGuardian — it merely
        enriches the advisory output with supplementary commentary.
        """
        sym = symbol.upper() if isinstance(symbol, str) else "UNKNOWN"
        commentary: List[str] = []

        if risk_check.approved:
            commentary.append(f"Risk Guardian approved order for {sym}.")
            if risk_check.approved_quantity > 0:
                commentary.append(f"Approved quantity: {risk_check.approved_quantity}")
            if risk_check.effective_leverage > 1:
                commentary.append(f"Effective leverage: {risk_check.effective_leverage}x")
        else:
            commentary.append(f"Risk Guardian rejected order for {sym}.")
            for check in risk_check.checks_failed:
                commentary.append(f"Failed check: {check}")

        equity_util = self._assess_equity_utilization(portfolio_equity)
        if equity_util:
            commentary.append(equity_util)

        concentration = self._assess_concentration(open_positions_count)
        if concentration:
            commentary.append(concentration)

        drawdown = self._assess_drawdown_risk(daily_pnl_pct)
        if drawdown:
            commentary.append(drawdown)

        risk_score = self._compute_risk_score(
            risk_check.approved, open_positions_count, daily_pnl_pct, portfolio_equity
        )

        logger.info("risk_advisory_agent", symbol=sym, approved=risk_check.approved, risk_score=round(risk_score, 3))

        return RiskAdvisoryCommentary(
            symbol=sym,
            approved=risk_check.approved,
            risk_score=round(risk_score, 4),
            commentary=commentary,
            original_reason=risk_check.reason,
            original_checks_passed=risk_check.checks_passed,
            original_checks_failed=risk_check.checks_failed,
        )

    def _assess_equity_utilization(self, portfolio_equity: float) -> Optional[str]:
        if not math.isfinite(portfolio_equity) or portfolio_equity <= 0:
            return "Equity utilization: UNABLE TO ASSESS (invalid equity)."
        if portfolio_equity < 100:
            return f"Equity utilization: LOW balance (${portfolio_equity:.2f}) — reduced risk capacity."
        if portfolio_equity > 10000:
            return f"Equity utilization: HIGH balance (${portfolio_equity:.2f}) — normal risk capacity."
        return None

    def _assess_concentration(self, open_positions_count: int) -> Optional[str]:
        if open_positions_count >= 4:
            return f"Position concentration: {open_positions_count} open positions — approaching maximum capacity."
        if open_positions_count >= 2:
            return f"Position concentration: {open_positions_count} open positions — moderate exposure."
        return None

    def _assess_drawdown_risk(self, daily_pnl_pct: float) -> Optional[str]:
        if not math.isfinite(daily_pnl_pct):
            return "Daily drawdown: UNABLE TO ASSESS (invalid PnL)."
        if daily_pnl_pct <= -0.02:
            return f"Daily drawdown: ELEVATED ({daily_pnl_pct * 100:.1f}%) — approaching kill threshold."
        if daily_pnl_pct < 0:
            return f"Daily drawdown: MINOR ({daily_pnl_pct * 100:.1f}%)."
        if daily_pnl_pct > 0.03:
            return f"Daily PnL: STRONG ({daily_pnl_pct * 100:.1f}%) — consider profit protection."
        return None

    def _compute_risk_score(
        self,
        approved: bool,
        open_positions: int,
        daily_pnl_pct: float,
        equity: float,
    ) -> float:
        score = 0.0
        if not approved:
            score += 0.4
        if open_positions >= 3:
            score += 0.2
        if math.isfinite(daily_pnl_pct) and daily_pnl_pct <= -0.01:
            score += 0.2
        if math.isfinite(equity) and equity < 200:
            score += 0.1
        return min(score, 1.0)
