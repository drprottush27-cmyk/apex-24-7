"""Risk guardian advisory agent."""
