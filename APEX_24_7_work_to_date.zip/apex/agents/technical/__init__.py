"""Technical analysis advisory agent."""
