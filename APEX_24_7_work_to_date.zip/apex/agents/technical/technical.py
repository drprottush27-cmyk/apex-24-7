"""Technical analysis advisory agent — P2-21.

Advisory-only, deterministic, fail-closed.  Consumes local OHLCV candle data
and produces a structured technical analysis report.  No network calls, no
credential access, no execution authority.  Invalid or insufficient data fails
closed to a neutral/unknown advisory outcome.
"""

import math
from enum import Enum
from typing import List, Optional, Dict, Any
from dataclasses import dataclass

from core.logging.logger import logger
from engines.indicators import TechnicalIndicators


class TrendStrength(str, Enum):
    STRONG_BULLISH = "STRONG_BULLISH"
    BULLISH = "BULLISH"
    NEUTRAL = "NEUTRAL"
    BEARISH = "BEARISH"
    STRONG_BEARISH = "STRONG_BEARISH"


class MomentumState(str, Enum):
    OVERBOUGHT = "OVERBOUGHT"
    OVERSOLD = "OVERSOLD"
    NEUTRAL = "NEUTRAL"


@dataclass(frozen=True)
class TechnicalReport:
    """Immutable advisory technical analysis report."""
    symbol: str
    trend_strength: TrendStrength
    momentum_state: MomentumState
    rsi_value: Optional[float]
    atr_value: Optional[float]
    bollinger_position: Optional[str]
    indicators: Dict[str, Any]
    reasons: List[str]
    advisory_only: bool = True


class TechnicalAnalysisAgent:
    """Deterministic, hermetic, advisory-only technical analysis agent.

    Consumes local OHLCV candle data (highs, lows, closes, volumes) and
    produces a ``TechnicalReport``.  Never contacts a network and never
    produces an execution signal — all output is advisory text and analysis
    that the orchestrator or Risk Guardian may inspect at its discretion.
    """

    MIN_CANDLES = 20

    def __init__(
        self,
        rsi_period: int = 14,
        atr_period: int = 14,
        ema_fast: int = 20,
        ema_slow: int = 50,
        bb_period: int = 20,
    ):
        self._rsi_period = rsi_period
        self._atr_period = atr_period
        self._ema_fast = ema_fast
        self._ema_slow = ema_slow
        self._bb_period = bb_period

    def analyze(
        self,
        symbol: str,
        highs: List[float],
        lows: List[float],
        closes: List[float],
        volumes: List[float],
    ) -> TechnicalReport:
        """Produce an advisory technical analysis report for *symbol*.

        Invalid or insufficient data fails closed to NEUTRAL with no
        actionable advisory content.
        """
        sym = symbol.upper() if isinstance(symbol, str) else "UNKNOWN"
        reasons: List[str] = []

        if not self._validate_inputs(highs, lows, closes, volumes):
            logger.warning("technical_agent_insufficient_data", symbol=sym, count=len(closes))
            return TechnicalReport(
                symbol=sym,
                trend_strength=TrendStrength.NEUTRAL,
                momentum_state=MomentumState.NEUTRAL,
                rsi_value=None,
                atr_value=None,
                bollinger_position=None,
                indicators={},
                reasons=["INSUFFICIENT_DATA: fewer candles than required for reliable analysis"],
            )

        rsi_values = TechnicalIndicators.calculate_rsi(closes, self._rsi_period)
        atr_values = TechnicalIndicators.calculate_atr(highs, lows, closes, self._atr_period)
        ema_fast = TechnicalIndicators.calculate_ema(closes, self._ema_fast)
        ema_slow = TechnicalIndicators.calculate_ema(closes, self._ema_slow)
        bb_upper, bb_middle, bb_lower = TechnicalIndicators.calculate_bollinger_bands(closes, self._bb_period)
        rvol = TechnicalIndicators.calculate_rvol(volumes, 20)

        rsi_val = rsi_values[-1] if rsi_values else None
        atr_val = atr_values[-1] if atr_values else None

        trend = self._assess_trend(closes, ema_fast, ema_slow)
        momentum = self._assess_momentum(rsi_val)
        bb_pos = self._assess_bollinger(closes[-1], bb_upper, bb_middle, bb_lower)

        if rsi_val is not None:
            reasons.append(f"RSI({self._rsi_period})={rsi_val:.1f}")
        if atr_val is not None:
            reasons.append(f"ATR({self._atr_period})={atr_val:.4f}")
        reasons.append(f"RVOL={rvol:.2f}")
        reasons.append(f"TREND={trend.value}")
        reasons.append(f"MOMENTUM={momentum.value}")
        if bb_pos:
            reasons.append(f"BB_POSITION={bb_pos}")

        indicators = {
            "rsi": round(rsi_val, 4) if rsi_val is not None else None,
            "atr": round(atr_val, 6) if atr_val is not None else None,
            "ema_fast": round(ema_fast[-1], 6) if ema_fast else None,
            "ema_slow": round(ema_slow[-1], 6) if ema_slow else None,
            "rvol": round(rvol, 4),
            "bb_upper": round(bb_upper[-1], 6) if bb_upper else None,
            "bb_middle": round(bb_middle[-1], 6) if bb_middle else None,
            "bb_lower": round(bb_lower[-1], 6) if bb_lower else None,
        }

        logger.info("technical_agent_analysis", symbol=sym, trend=trend.value, momentum=momentum.value)

        return TechnicalReport(
            symbol=sym,
            trend_strength=trend,
            momentum_state=momentum,
            rsi_value=round(rsi_val, 4) if rsi_val is not None else None,
            atr_value=round(atr_val, 6) if atr_val is not None else None,
            bollinger_position=bb_pos,
            indicators=indicators,
            reasons=reasons,
        )

    def _validate_inputs(
        self, highs: List[float], lows: List[float], closes: List[float], volumes: List[float]
    ) -> bool:
        if not all(isinstance(x, list) for x in (highs, lows, closes, volumes)):
            return False
        if len(closes) < self.MIN_CANDLES:
            return False
        if len(highs) != len(closes) or len(lows) != len(closes) or len(volumes) != len(closes):
            return False
        if any(not math.isfinite(v) for v in closes[-self.MIN_CANDLES:]):
            return False
        return True

    def _assess_trend(self, closes: List[float], ema_fast: List[float], ema_slow: List[float]) -> TrendStrength:
        if not ema_fast or not ema_slow:
            return TrendStrength.NEUTRAL
        ef = ema_fast[-1]
        es = ema_slow[-1]
        close = closes[-1]
        if not all(math.isfinite(x) for x in (ef, es, close)):
            return TrendStrength.NEUTRAL
        diff_pct = (ef - es) / es if es != 0 else 0.0
        if diff_pct > 0.02 and close > ef:
            return TrendStrength.STRONG_BULLISH
        if diff_pct > 0.005:
            return TrendStrength.BULLISH
        if diff_pct < -0.02 and close < ef:
            return TrendStrength.STRONG_BEARISH
        if diff_pct < -0.005:
            return TrendStrength.BEARISH
        return TrendStrength.NEUTRAL

    def _assess_momentum(self, rsi: Optional[float]) -> MomentumState:
        if rsi is None or not math.isfinite(rsi):
            return MomentumState.NEUTRAL
        if rsi >= 70:
            return MomentumState.OVERBOUGHT
        if rsi <= 30:
            return MomentumState.OVERSOLD
        return MomentumState.NEUTRAL

    def _assess_bollinger(
        self, close: float, upper: List[float], middle: List[float], lower: List[float]
    ) -> Optional[str]:
        if not upper or not middle or not lower:
            return None
        u, m, l = upper[-1], middle[-1], lower[-1]
        if not all(math.isfinite(x) for x in (u, m, l, close)):
            return None
        if u == l:
            return "AT_MIDDLE"
        pos = (close - l) / (u - l)
        if pos >= 0.95:
            return "AT_UPPER"
        if pos <= 0.05:
            return "AT_LOWER"
        if pos >= 0.6:
            return "ABOVE_MIDDLE"
        if pos <= 0.4:
            return "BELOW_MIDDLE"
        return "AT_MIDDLE"
