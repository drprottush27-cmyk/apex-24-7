"""Research advisory agent — P2-21.

Advisory-only, deterministic, fail-closed.  Compiles multi-factor research
insights from locally available data (candles, regime, indicators, existing
signals) into a structured research report.  No network calls, no credential
access, no execution authority.  Invalid or insufficient data fails closed
to a neutral advisory outcome.
"""

import math
from typing import List, Optional, Dict, Any
from dataclasses import dataclass, field

from core.logging.logger import logger
from engines.indicators import TechnicalIndicators
from engines.regime import RegimeClassifier, MarketRegime


@dataclass(frozen=True)
class ResearchFactor:
    """A single research factor with its assessment."""
    name: str
    assessment: str
    weight: float = 1.0
    data: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class ResearchReport:
    """Immutable multi-factor research advisory report."""
    symbol: str
    factors: List[ResearchFactor]
    overall_bias: str
    confidence: float
    summary: str
    advisory_only: bool = True


class ResearchAgent:
    """Deterministic, hermetic, advisory-only research agent.

    Compiles multiple locally available analytical factors into a structured
    research report.  Never contacts a network and never produces an execution
    signal.
    """

    MIN_CANDLES = 30

    def __init__(
        self,
        rsi_period: int = 14,
        ema_fast: int = 20,
        ema_slow: int = 50,
    ):
        self._rsi_period = rsi_period
        self._ema_fast = ema_fast
        self._ema_slow = ema_slow
        self._regime_classifier = RegimeClassifier()

    def research(
        self,
        symbol: str,
        highs: List[float],
        lows: List[float],
        closes: List[float],
        volumes: List[float],
        additional_context: Optional[Dict[str, Any]] = None,
    ) -> ResearchReport:
        """Produce a multi-factor advisory research report.

        *additional_context* is an optional dict of pre-computed advisory data
        (e.g. from other agents) that may enrich the report.  All values are
        treated as advisory input — nothing is executed upon.
        """
        sym = symbol.upper() if isinstance(symbol, str) else "UNKNOWN"

        if not self._validate(highs, lows, closes, volumes):
            logger.warning("research_agent_insufficient_data", symbol=sym)
            return ResearchReport(
                symbol=sym,
                factors=[],
                overall_bias="UNKNOWN",
                confidence=0.0,
                summary="Insufficient data for research analysis.",
            )

        factors: List[ResearchFactor] = []

        trend_factor = self._assess_trend_factor(closes)
        if trend_factor:
            factors.append(trend_factor)

        momentum_factor = self._assess_momentum_factor(closes)
        if momentum_factor:
            factors.append(momentum_factor)

        volatility_factor = self._assess_volatility_factor(highs, lows, closes)
        if volatility_factor:
            factors.append(volatility_factor)

        volume_factor = self._assess_volume_factor(volumes)
        if volume_factor:
            factors.append(volume_factor)

        regime_factor = self._assess_regime_factor(highs, lows, closes)
        if regime_factor:
            factors.append(regime_factor)

        if additional_context:
            ctx_factor = self._assess_context_factor(additional_context)
            if ctx_factor:
                factors.append(ctx_factor)

        overall_bias, confidence = self._aggregate_bias(factors)
        summary = self._build_summary(sym, overall_bias, confidence, factors)

        logger.info("research_agent_complete", symbol=sym, bias=overall_bias, confidence=round(confidence, 3))

        return ResearchReport(
            symbol=sym,
            factors=factors,
            overall_bias=overall_bias,
            confidence=round(confidence, 4),
            summary=summary,
        )

    def _validate(self, highs: List[float], lows: List[float], closes: List[float], volumes: List[float]) -> bool:
        if len(closes) < self.MIN_CANDLES:
            return False
        if len(highs) != len(closes) or len(lows) != len(closes) or len(volumes) != len(closes):
            return False
        if any(not math.isfinite(v) for v in closes[-self.MIN_CANDLES:]):
            return False
        return True

    def _assess_trend_factor(self, closes: List[float]) -> Optional[ResearchFactor]:
        ema_f = TechnicalIndicators.calculate_ema(closes, self._ema_fast)
        ema_s = TechnicalIndicators.calculate_ema(closes, self._ema_slow)
        if not ema_f or not ema_s:
            return None
        ef, es = ema_f[-1], ema_s[-1]
        if not all(math.isfinite(x) for x in (ef, es)):
            return None
        diff_pct = ((ef - es) / es * 100) if es != 0 else 0.0
        if diff_pct > 0.5:
            bias = "BULLISH"
        elif diff_pct < -0.5:
            bias = "BEARISH"
        else:
            bias = "NEUTRAL"
        return ResearchFactor(
            name="EMA_TREND",
            assessment=bias,
            weight=1.0,
            data={"ema_fast": round(ef, 6), "ema_slow": round(es, 6), "diff_pct": round(diff_pct, 3)},
        )

    def _assess_momentum_factor(self, closes: List[float]) -> Optional[ResearchFactor]:
        rsi_vals = TechnicalIndicators.calculate_rsi(closes, self._rsi_period)
        if not rsi_vals:
            return None
        rsi = rsi_vals[-1]
        if not math.isfinite(rsi):
            return None
        if rsi >= 70:
            bias = "BEARISH"
        elif rsi <= 30:
            bias = "BULLISH"
        elif rsi >= 55:
            bias = "SLIGHTLY_BULLISH"
        elif rsi <= 45:
            bias = "SLIGHTLY_BEARISH"
        else:
            bias = "NEUTRAL"
        return ResearchFactor(
            name="RSI_MOMENTUM",
            assessment=bias,
            weight=0.8,
            data={"rsi": round(rsi, 2)},
        )

    def _assess_volatility_factor(self, highs: List[float], lows: List[float], closes: List[float]) -> Optional[ResearchFactor]:
        atr_vals = TechnicalIndicators.calculate_atr(highs, lows, closes, 14)
        if len(atr_vals) < 20:
            return None
        recent_avg = sum(atr_vals[-20:]) / 20
        if recent_avg == 0:
            return None
        current_atr = atr_vals[-1]
        ratio = current_atr / recent_avg
        if ratio > 1.5:
            assessment = "HIGH_VOLATILITY"
        elif ratio < 0.5:
            assessment = "LOW_VOLATILITY"
        else:
            assessment = "NORMAL"
        return ResearchFactor(
            name="VOLATILITY",
            assessment=assessment,
            weight=0.5,
            data={"current_atr": round(current_atr, 6), "avg_atr": round(recent_avg, 6), "ratio": round(ratio, 3)},
        )

    def _assess_volume_factor(self, volumes: List[float]) -> Optional[ResearchFactor]:
        rvol = TechnicalIndicators.calculate_rvol(volumes, 20)
        if rvol >= 2.0:
            assessment = "ELEVATED"
        elif rvol >= 1.5:
            assessment = "ABOVE_AVERAGE"
        elif rvol <= 0.5:
            assessment = "BELOW_AVERAGE"
        else:
            assessment = "NORMAL"
        return ResearchFactor(
            name="VOLUME",
            assessment=assessment,
            weight=0.6,
            data={"rvol": round(rvol, 4)},
        )

    def _assess_regime_factor(self, highs: List[float], lows: List[float], closes: List[float]) -> Optional[ResearchFactor]:
        regime = self._regime_classifier.classify(highs, lows, closes)
        regime_map = {
            MarketRegime.TRENDING_BULL: "TRENDING_BULL",
            MarketRegime.TRENDING_BEAR: "TRENDING_BEAR",
            MarketRegime.RANGING: "RANGING",
            MarketRegime.HIGH_VOLATILITY_EXPANSION: "HIGH_VOL_EXPANSION",
        }
        return ResearchFactor(
            name="MARKET_REGIME",
            assessment=regime_map.get(regime, "UNKNOWN"),
            weight=1.2,
            data={"regime": regime.value},
        )

    def _assess_context_factor(self, context: Dict[str, Any]) -> Optional[ResearchFactor]:
        if not isinstance(context, dict) or not context:
            return None
        bias_str = context.get("overall_bias", context.get("bias", None))
        if isinstance(bias_str, str) and bias_str:
            return ResearchFactor(
                name="EXTERNAL_CONTEXT",
                assessment=bias_str.upper(),
                weight=0.3,
                data={"source": context.get("source", "unknown")},
            )
        return None

    def _aggregate_bias(self, factors: List[ResearchFactor]) -> tuple:
        if not factors:
            return "UNKNOWN", 0.0
        bull_score = 0.0
        bear_score = 0.0
        total_weight = 0.0
        for f in factors:
            w = f.weight
            total_weight += w
            a = f.assessment.upper()
            if "BULLISH" in a and "BEARISH" not in a:
                if "STRONG" in a or a == "TRENDING_BULL":
                    bull_score += w * 1.5
                else:
                    bull_score += w
            elif "BEARISH" in a and "BULLISH" not in a:
                if "STRONG" in a or a == "TRENDING_BEAR":
                    bear_score += w * 1.5
                else:
                    bear_score += w
        if total_weight == 0:
            return "UNKNOWN", 0.0
        net = (bull_score - bear_score) / total_weight
        confidence = min(abs(net), 1.0)
        if net > 0.3:
            bias = "BULLISH"
        elif net < -0.3:
            bias = "BEARISH"
        elif net > 0.1:
            bias = "SLIGHTLY_BULLISH"
        elif net < -0.1:
            bias = "SLIGHTLY_BEARISH"
        else:
            bias = "NEUTRAL"
        return bias, confidence

    def _build_summary(self, symbol: str, bias: str, confidence: float, factors: List[ResearchFactor]) -> str:
        factor_names = [f.name for f in factors]
        return (
            f"Research advisory for {symbol}: {bias} "
            f"(confidence={confidence:.1%}). "
            f"Factors assessed: {', '.join(factor_names)}. "
            f"ADVISORY ONLY — no execution authority."
        )
