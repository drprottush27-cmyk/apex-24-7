"""Research advisory agent."""
