"""Derivatives / funding rate advisory agent — P2-21.

Advisory-only, deterministic, fail-closed.  Analyzes derivatives market
metrics (funding rate, open interest, estimated leverage) from locally
provided data.  No network calls, no credential access, no execution
authority.  Invalid or missing data fails closed to a neutral advisory
outcome.
"""

import math
from enum import Enum
from typing import List, Optional, Dict, Any
from dataclasses import dataclass

from core.logging.logger import logger


class FundingBias(str, Enum):
    VERY_BEARISH = "VERY_BEARISH"
    BEARISH = "BEARISH"
    NEUTRAL = "NEUTRAL"
    BULLISH = "BULLISH"
    VERY_BEARISH_FUNDING = "VERY_BEARISH_FUNDING"


class OiTrend(str, Enum):
    INCREASING = "INCREASING"
    DECREASING = "DECREASING"
    STABLE = "STABLE"
    UNKNOWN = "UNKNOWN"


@dataclass(frozen=True)
class DerivativesReport:
    """Immutable derivatives advisory report."""
    symbol: str
    funding_rate: Optional[float]
    funding_bias: FundingBias
    open_interest: Optional[float]
    oi_trend: OiTrend
    estimated_leverage: Optional[float]
    commentary: List[str]
    advisory_only: bool = True


class DerivativesAgent:
    """Deterministic, hermetic, advisory-only derivatives analysis agent.

    Analyzes funding rate and open interest metrics from locally provided
    data.  Never contacts exchange APIs and never produces an execution
    signal.  All data must be provided by the caller.
    """

    def __init__(
        self,
        high_funding_threshold: float = 0.001,
        low_funding_threshold: float = -0.001,
    ):
        self._high_funding = high_funding_threshold
        self._low_funding = low_funding_threshold

    def analyze(
        self,
        symbol: str,
        funding_rate: Optional[float] = None,
        open_interest: Optional[float] = None,
        previous_oi: Optional[float] = None,
        mark_price: Optional[float] = None,
    ) -> DerivativesReport:
        """Produce an advisory derivatives analysis report.

        All inputs are optional — missing data is handled fail-closed.
        """
        sym = symbol.upper() if isinstance(symbol, str) else "UNKNOWN"
        commentary: List[str] = []

        funding_bias = self._assess_funding(funding_rate, commentary)
        oi_trend = self._assess_oi_trend(open_interest, previous_oi, commentary)
        est_leverage = self._estimate_leverage(open_interest, mark_price, commentary)

        if funding_rate is not None:
            commentary.append(f"Funding rate: {funding_rate:.6f} ({funding_bias.value})")
        else:
            commentary.append("Funding rate: unavailable")

        if open_interest is not None:
            commentary.append(f"Open interest: {open_interest:.2f} ({oi_trend.value})")
        else:
            commentary.append("Open interest: unavailable")

        logger.info("derivatives_agent_complete", symbol=sym, funding_bias=funding_bias.value, oi_trend=oi_trend.value)

        return DerivativesReport(
            symbol=sym,
            funding_rate=round(funding_rate, 8) if funding_rate is not None else None,
            funding_bias=funding_bias,
            open_interest=round(open_interest, 4) if open_interest is not None else None,
            oi_trend=oi_trend,
            estimated_leverage=round(est_leverage, 2) if est_leverage is not None else None,
            commentary=commentary,
        )

    def _assess_funding(self, rate: Optional[float], commentary: List[str]) -> FundingBias:
        if rate is None or not math.isfinite(rate):
            return FundingBias.NEUTRAL
        if rate >= self._high_funding * 2:
            commentary.append("WARNING: Extremely high positive funding — short crowding risk.")
            return FundingBias.VERY_BEARISH
        if rate >= self._high_funding:
            commentary.append("Elevated positive funding — longs paying shorts.")
            return FundingBias.BEARISH
        if rate <= self._low_funding * 2:
            commentary.append("WARNING: Extremely negative funding — long crowding risk.")
            return FundingBias.VERY_BEARISH_FUNDING
        if rate <= self._low_funding:
            commentary.append("Negative funding — shorts paying longs.")
            return FundingBias.BULLISH
        return FundingBias.NEUTRAL

    def _assess_oi_trend(
        self, oi: Optional[float], prev_oi: Optional[float], commentary: List[str]
    ) -> OiTrend:
        if oi is None or prev_oi is None:
            return OiTrend.UNKNOWN
        if not all(math.isfinite(x) for x in (oi, prev_oi)):
            return OiTrend.UNKNOWN
        if prev_oi == 0:
            return OiTrend.UNKNOWN
        change_pct = (oi - prev_oi) / prev_oi
        if change_pct > 0.05:
            commentary.append(f"OI increased {change_pct * 100:.1f}% — new positions opening.")
            return OiTrend.INCREASING
        if change_pct < -0.05:
            commentary.append(f"OI decreased {abs(change_pct) * 100:.1f}% — positions closing.")
            return OiTrend.DECREASING
        return OiTrend.STABLE

    def _estimate_leverage(
        self,
        oi: Optional[float],
        mark_price: Optional[float],
        commentary: List[str],
    ) -> Optional[float]:
        if oi is None or mark_price is None:
            return None
        if not all(math.isfinite(x) for x in (oi, mark_price)):
            return None
        if mark_price <= 0:
            return None
        est_lev = oi / mark_price
        if est_lev > 20:
            commentary.append(f"Estimated leverage ratio elevated ({est_lev:.1f}x) — potential for cascading liquidations.")
        return est_lev
