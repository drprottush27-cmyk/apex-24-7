"""Derivatives / funding rate advisory agent."""
