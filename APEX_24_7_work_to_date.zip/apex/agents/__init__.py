"""APEX trading agents — advisory-only, deterministic, fail-closed.

Every agent in this package is advisory-only: it returns structured analysis
and never has direct execution authority.  Agents never contact external
networks, never read credentials, and never bypass Risk Guardian or the kill
switch.  All inputs are validated; invalid data fails closed to the safest
advisory outcome.
"""
