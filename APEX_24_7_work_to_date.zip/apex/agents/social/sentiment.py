"""Social / sentiment advisory agent — P2-21.

Advisory-only, deterministic, fail-closed.  Compiles social sentiment and
market情绪 summaries from locally provided data.  Never contacts social
media APIs, never reads external credentials, and never produces an execution
signal.  All sentiment inputs are treated as advisory data — nothing is
acted upon.  Invalid or missing data fails closed to a neutral advisory
outcome.
"""

import math
from enum import Enum
from typing import List, Optional, Dict, Any
from dataclasses import dataclass

from core.logging.logger import logger


class SentimentTone(str, Enum):
    VERY_BULLISH = "VERY_BULLISH"
    BULLISH = "BULLISH"
    NEUTRAL = "NEUTRAL"
    BEARISH = "BEARISH"
    VERY_BEARISH = "VERY_BEARISH"
    UNKNOWN = "UNKNOWN"


@dataclass(frozen=True)
class SentimentReading:
    """A single sentiment data point."""
    source: str
    tone: SentimentTone
    score: float
    detail: str = ""


@dataclass(frozen=True)
class SentimentReport:
    """Immutable social/sentiment advisory report."""
    symbol: str
    readings: List[SentimentReading]
    aggregate_tone: SentimentTone
    aggregate_score: float
    confidence: float
    summary: str
    advisory_only: bool = True


class SocialSentimentAgent:
    """Deterministic, hermetic, advisory-only social sentiment agent.

    Compiles sentiment readings from locally provided data into a structured
    report.  Never contacts social media or news APIs.  All sentiment data
    must be provided by the caller — this agent only aggregates and validates.
    """

    MIN_READINGS_FOR_CONFIDENCE = 2

    def __init__(self, bullish_threshold: float = 0.3, bearish_threshold: float = -0.3):
        self._bullish_threshold = bullish_threshold
        self._bearish_threshold = bearish_threshold

    def compile(
        self,
        symbol: str,
        readings: List[Dict[str, Any]],
    ) -> SentimentReport:
        """Compile provided sentiment readings into an advisory report.

        Each reading dict should contain:
        - "source" (str): identification of the data source
        - "score" (float): -1.0 (very bearish) to 1.0 (very bullish)
        - "detail" (str, optional): additional context

        Invalid or malformed readings are silently dropped (fail-closed).
        """
        sym = symbol.upper() if isinstance(symbol, str) else "UNKNOWN"
        valid_readings: List[SentimentReading] = []

        for r in readings:
            reading = self._parse_reading(r)
            if reading:
                valid_readings.append(reading)

        if not valid_readings:
            logger.info("sentiment_agent_no_readings", symbol=sym)
            return SentimentReport(
                symbol=sym,
                readings=[],
                aggregate_tone=SentimentTone.UNKNOWN,
                aggregate_score=0.0,
                confidence=0.0,
                summary="No valid sentiment data available.",
            )

        agg_score = sum(r.score for r in valid_readings) / len(valid_readings)
        agg_tone = self._score_to_tone(agg_score)
        confidence = self._compute_confidence(valid_readings)
        summary = self._build_summary(sym, agg_tone, agg_score, confidence, len(valid_readings))

        logger.info("sentiment_agent_complete", symbol=sym, tone=agg_tone.value, score=round(agg_score, 3))

        return SentimentReport(
            symbol=sym,
            readings=valid_readings,
            aggregate_tone=agg_tone,
            aggregate_score=round(agg_score, 4),
            confidence=round(confidence, 4),
            summary=summary,
        )

    def _parse_reading(self, data: Dict[str, Any]) -> Optional[SentimentReading]:
        if not isinstance(data, dict):
            return None
        source = data.get("source", "unknown")
        if not isinstance(source, str) or not source.strip():
            source = "unknown"
        score = data.get("score", None)
        if score is None or not isinstance(score, (int, float)) or not math.isfinite(score):
            return None
        score = max(-1.0, min(1.0, float(score)))
        tone = self._score_to_tone(score)
        detail = data.get("detail", "")
        if not isinstance(detail, str):
            detail = str(detail)
        return SentimentReading(source=source.strip(), tone=tone, score=round(score, 4), detail=detail)

    def _score_to_tone(self, score: float) -> SentimentTone:
        if score >= 0.6:
            return SentimentTone.VERY_BULLISH
        if score >= self._bullish_threshold:
            return SentimentTone.BULLISH
        if score <= -0.6:
            return SentimentTone.VERY_BEARISH
        if score <= self._bearish_threshold:
            return SentimentTone.BEARISH
        return SentimentTone.NEUTRAL

    def _compute_confidence(self, readings: List[SentimentReading]) -> float:
        if len(readings) < self.MIN_READINGS_FOR_CONFIDENCE:
            return 0.2
        scores = [r.score for r in readings]
        mean = sum(scores) / len(scores)
        variance = sum((s - mean) ** 2 for s in scores) / len(scores)
        agreement = max(0.0, 1.0 - (variance * 2))
        volume_factor = min(len(readings) / 10.0, 1.0)
        return round(agreement * 0.7 + volume_factor * 0.3, 4)

    def _build_summary(
        self, symbol: str, tone: SentimentTone, score: float, confidence: float, count: int
    ) -> str:
        return (
            f"Social sentiment for {symbol}: {tone.value} "
            f"(aggregate score={score:.2f}, confidence={confidence:.1%}, "
            f"readings={count}). "
            f"ADVISORY ONLY — no execution authority."
        )
