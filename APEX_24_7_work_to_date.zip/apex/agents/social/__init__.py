"""Social / sentiment advisory agent."""
