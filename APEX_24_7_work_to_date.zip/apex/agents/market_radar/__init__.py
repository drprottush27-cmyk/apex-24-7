"""Market radar / screening advisory agent."""
