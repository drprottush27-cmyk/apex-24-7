"""Market radar screening advisory agent — P2-21.

Advisory-only, deterministic, fail-closed.  Screens a batch of symbols for
conditions of interest (volume spikes, regime changes, price movements) using
local OHLCV candle data.  No network calls, no credential access, no
execution authority.  Invalid or insufficient data fails closed to an empty
advisory list.
"""

import math
from enum import Enum
from typing import List, Optional, Dict, Any
from dataclasses import dataclass

from core.logging.logger import logger
from engines.indicators import TechnicalIndicators
from engines.regime import RegimeClassifier, MarketRegime


class RadarAlertType(str, Enum):
    VOLUME_SPIKE = "VOLUME_SPIKE"
    REGIME_CHANGE = "REGIME_CHANGE"
    PRICE_BREAKOUT = "PRICE_BREAKOUT"
    PRICE_BREAKDOWN = "PRICE_BREAKDOWN"
    RSI_EXTREME = "RSI_EXTREME"


@dataclass(frozen=True)
class RadarAlert:
    """Immutable advisory radar alert for a single symbol."""
    symbol: str
    alert_type: RadarAlertType
    detail: str
    value: Optional[float] = None
    advisory_only: bool = True


@dataclass(frozen=True)
class RadarScanResult:
    """Immutable advisory scan result across multiple symbols."""
    alerts: List[RadarAlert]
    symbols_scanned: int
    advisory_only: bool = True


class MarketRadarAgent:
    """Deterministic, hermetic, advisory-only market screening agent.

    Screens symbol data for notable conditions and returns advisory alerts.
    Never contacts a network and never produces an execution signal.
    """

    def __init__(
        self,
        volume_spike_threshold: float = 2.0,
        rsi_overbought: float = 70.0,
        rsi_oversold: float = 30.0,
        rsi_period: int = 14,
        min_candles: int = 30,
    ):
        self._volume_spike_threshold = volume_spike_threshold
        self._rsi_overbought = rsi_overbought
        self._rsi_oversold = rsi_oversold
        self._rsi_period = rsi_period
        self._min_candles = min_candles
        self._regime_classifier = RegimeClassifier()

    def scan(
        self,
        symbol_data: Dict[str, Dict[str, List[float]]],
    ) -> RadarScanResult:
        """Screen multiple symbols for advisory alerts.

        *symbol_data* maps symbol -> {"highs": [...], "lows": [...],
        "closes": [...], "volumes": [...]}.

        Invalid or missing data for a symbol is silently skipped (fail-closed:
        no alert rather than a bad advisory).
        """
        alerts: List[RadarAlert] = []
        scanned = 0

        for symbol, data in symbol_data.items():
            sym = symbol.upper() if isinstance(symbol, str) else None
            if sym is None:
                continue

            closes = data.get("closes", [])
            volumes = data.get("volumes", [])
            highs = data.get("highs", [])
            lows = data.get("lows", [])

            if not self._validate(closes, volumes, highs, lows):
                logger.warning("radar_agent_skip_symbol", symbol=sym, reason="insufficient_data")
                continue

            scanned += 1

            vol_alerts = self._check_volume_spike(sym, volumes)
            alerts.extend(vol_alerts)

            rsi_alerts = self._check_rsi_extreme(sym, closes)
            alerts.extend(rsi_alerts)

            breakout_alerts = self._check_breakout(sym, closes, highs, lows)
            alerts.extend(breakout_alerts)

            regime_alert = self._check_regime_change(sym, highs, lows, closes)
            if regime_alert:
                alerts.append(regime_alert)

        logger.info("radar_agent_scan_complete", scanned=scanned, alerts=len(alerts))
        return RadarScanResult(alerts=alerts, symbols_scanned=scanned)

    def _validate(
        self,
        closes: List[float],
        volumes: List[float],
        highs: List[float],
        lows: List[float],
    ) -> bool:
        if len(closes) < self._min_candles or len(volumes) < self._min_candles:
            return False
        if len(highs) != len(closes) or len(lows) != len(closes):
            return False
        recent_closes = closes[-self._min_candles:]
        if any(not math.isfinite(v) for v in recent_closes):
            return False
        return True

    def _check_volume_spike(self, symbol: str, volumes: List[float]) -> List[RadarAlert]:
        rvol = TechnicalIndicators.calculate_rvol(volumes, 20)
        if rvol >= self._volume_spike_threshold:
            return [RadarAlert(
                symbol=symbol,
                alert_type=RadarAlertType.VOLUME_SPIKE,
                detail=f"Relative volume {rvol:.2f}x exceeds threshold {self._volume_spike_threshold}x",
                value=round(rvol, 4),
            )]
        return []

    def _check_rsi_extreme(self, symbol: str, closes: List[float]) -> List[RadarAlert]:
        rsi_vals = TechnicalIndicators.calculate_rsi(closes, self._rsi_period)
        if not rsi_vals:
            return []
        rsi = rsi_vals[-1]
        if rsi >= self._rsi_overbought:
            return [RadarAlert(
                symbol=symbol,
                alert_type=RadarAlertType.RSI_EXTREME,
                detail=f"RSI({self._rsi_period})={rsi:.1f} in overbought territory (>={self._rsi_overbought})",
                value=round(rsi, 4),
            )]
        if rsi <= self._rsi_oversold:
            return [RadarAlert(
                symbol=symbol,
                alert_type=RadarAlertType.RSI_EXTREME,
                detail=f"RSI({self._rsi_period})={rsi:.1f} in oversold territory (<={self._rsi_oversold})",
                value=round(rsi, 4),
            )]
        return []

    def _check_breakout(
        self, symbol: str, closes: List[float], highs: List[float], lows: List[float]
    ) -> List[RadarAlert]:
        if len(closes) < 20:
            return []
        recent_high = max(highs[-20:])
        recent_low = min(lows[-20:])
        current = closes[-1]
        if not all(math.isfinite(x) for x in (recent_high, recent_low, current)):
            return []
        alerts: List[RadarAlert] = []
        if current > recent_high:
            alerts.append(RadarAlert(
                symbol=symbol,
                alert_type=RadarAlertType.PRICE_BREAKOUT,
                detail=f"Price {current:.4f} broke above 20-period high {recent_high:.4f}",
                value=round(current, 6),
            ))
        if current < recent_low:
            alerts.append(RadarAlert(
                symbol=symbol,
                alert_type=RadarAlertType.PRICE_BREAKDOWN,
                detail=f"Price {current:.4f} broke below 20-period low {recent_low:.4f}",
                value=round(current, 6),
            ))
        return alerts

    def _check_regime_change(
        self, symbol: str, highs: List[float], lows: List[float], closes: List[float]
    ) -> Optional[RadarAlert]:
        regime = self._regime_classifier.classify(highs, lows, closes)
        if regime in (MarketRegime.TRENDING_BULL, MarketRegime.TRENDING_BEAR):
            return RadarAlert(
                symbol=symbol,
                alert_type=RadarAlertType.REGIME_CHANGE,
                detail=f"Market regime is {regime.value}",
                value=None,
            )
        return None
