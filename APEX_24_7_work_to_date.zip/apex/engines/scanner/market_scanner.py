import asyncio
import json
from typing import List, Dict, Any

from core.logging.logger import logger
from core.models.market import Candle
from core.models.mtf import TimeframeBias
from engines.signals.mtf_sniper import MTFSniperEngine
from infrastructure.redis.client import get_redis_client
from execution.adapters.binance.client import BinanceFuturesClient
from execution.safety.endpoint_isolation import EndpointGuard

EXCLUDED_STABLES = {
    "USDCUSDT", "FDUSDUSDT", "TUSDUSDT", "BUSDUSDT", "AEURUSDT", "EURUSDT"
}

# Institutional Sector Maps for Binance USD-M Futures
SECTOR_MAP = {
    "DEFI": {
        "AAVEUSDT", "UNIUSDT", "PENDLEUSDT", "CRVUSDT", "MKRUSDT", "LDOUSDT", 
        "SNXUSDT", "COMPUSDT", "DYDXUSDT", "RUNEUSDT", "JUPUSDT", "RAYUSDT", 
        "ENAUSDT", "1INCHUSDT", "SUSHIUSDT", "GMXUSDT", "CAKEUSDT", "CVXUSDT", 
        "INJUSDT", "FXSUSDT", "KAVAUSDT", "LRCUSDT", "BALUSDT", "YFIUSDT",
        "TRUUSDT", "RDNTUSDT", "DRIFTUSDT", "COWUSDT", "MORPHOUSDT"
    },
    "ALPHA_MEME": {
        "DOGEUSDT", "SHIBUSDT", "PEPEUSDT", "WIFUSDT", "BONKUSDT", "FLOKIUSDT", 
        "POPCATUSDT", "BOMEUSDT", "1000SATSUSDT", "MEMEUSDT", "NEIROUSDT", 
        "TURBOUSDT", "BRETTUSDT", "MYROUSDT", "MEWUSDT", "DOGSUSDT", "PEOPLEUSDT"
    },
    "AI": {
        "NEARUSDT", "FETUSDT", "RENDERUSDT", "TAOUSDT", "WLDUSDT", "ARKMUSDT", 
        "IOUSDT", "ATHUSDT", "AIUSDT", "GLMUSDT", "PHBUSDT", "GRTUSDT"
    }
}


class MarketScannerEngine:
    def __init__(self, min_24h_volume_usd: float = 5_000_000.0):
        self.min_volume = min_24h_volume_usd
        self.guard = EndpointGuard()
        self._rest = BinanceFuturesClient(guard=self.guard)
        self.mtf_engine = MTFSniperEngine()

    @property
    def base_url(self) -> str:
        return self._rest.base_url

    @property
    def redis(self):
        return get_redis_client()

    async def fetch_24h_tickers(self) -> List[Dict[str, Any]]:
        return await self._rest.get_24hr_tickers()

    def categorize_symbol(self, sym: str, price_change: float) -> str:
        if sym in SECTOR_MAP["DEFI"]:
            return "DEFI"
        if sym in SECTOR_MAP["ALPHA_MEME"]:
            return "MEME"
        if sym in SECTOR_MAP["AI"]:
            return "AI"
        if price_change >= 8.0:
            return "ALPHA"
        return "CRYPTO"

    def filter_universe(self, tickers: List[Dict[str, Any]], category: str = "ALL") -> List[Dict[str, Any]]:
        screened = []
        category = category.upper()

        for t in tickers:
            sym = t.get("symbol", "")
            if not sym.endswith("USDT") or sym in EXCLUDED_STABLES:
                continue

            try:
                quote_vol = float(t.get("quoteVolume", 0.0))
                price = float(t.get("lastPrice", 0.0))
                price_change_pct = float(t.get("priceChangePercent", 0.0))
                high = float(t.get("highPrice", 0.0))
                low = float(t.get("lowPrice", 0.0))
            except (ValueError, TypeError):
                continue

            if quote_vol < self.min_volume:
                continue

            coin_sector = self.categorize_symbol(sym, price_change_pct)

            # Category filtering logic
            if category == "DEFI" and coin_sector != "DEFI":
                continue
            elif category == "ALPHA" and price_change_pct < 6.0 and coin_sector != "ALPHA":
                continue
            elif category == "MEME" and coin_sector != "MEME":
                continue
            elif category == "AI" and coin_sector != "AI":
                continue

            screened.append({
                "symbol": sym,
                "price": price,
                "price_change_pct": round(price_change_pct, 2),
                "quote_volume_usd": round(quote_vol, 2),
                "quote_volume_m": round(quote_vol / 1_000_000.0, 1),
                "high_24h": high,
                "low_24h": low,
                "sector": coin_sector,
            })

        # Sort: Gainers prioritized in ALPHA category, Volume prioritized in others
        if category == "ALPHA":
            screened.sort(key=lambda x: x["price_change_pct"], reverse=True)
        else:
            screened.sort(key=lambda x: x["quote_volume_usd"], reverse=True)

        return screened

    async def fetch_klines_light(self, symbol: str, interval: str, limit: int = 55) -> List[Candle]:
        try:
            return await self._rest.get_klines(symbol=symbol, interval=interval, limit=limit)
        except Exception:
            return []

    async def scan_market(self, category: str = "ALL", limit: int = 25, force_refresh: bool = False) -> List[Dict[str, Any]]:
        cache_key = f"apex:scanner:{category.lower()}:{limit}"
        if not force_refresh:
            try:
                cached = await self.redis.get(cache_key)
                if cached:
                    return json.loads(cached)
            except Exception:
                pass

        try:
            tickers = await self.fetch_24h_tickers()
        except Exception as e:
            logger.error("scanner_ticker_fetch_failed", error=str(e))
            return []

        filtered = self.filter_universe(tickers, category=category)[:limit]
        results = []
        sem = asyncio.Semaphore(5)

        async def worker(item):
            async with sem:
                return await self._evaluate_candidate(item)

        tasks = [worker(item) for item in filtered]
        candidate_results = await asyncio.gather(*tasks, return_exceptions=True)

        for res in candidate_results:
            if isinstance(res, dict):
                results.append(res)

        if results:
            try:
                await self.redis.set(cache_key, json.dumps(results), ex=45)
            except Exception:
                pass

        return results

    async def _evaluate_candidate(self, item: Dict[str, Any]) -> Dict[str, Any]:
        sym = item["symbol"]
        try:
            c_4h, c_1h = await asyncio.gather(
                self.fetch_klines_light(sym, "4h", limit=55),
                self.fetch_klines_light(sym, "1h", limit=35),
            )

            bias_4h = self.mtf_engine.evaluate_4h_bias(c_4h) if len(c_4h) >= 50 else TimeframeBias.NEUTRAL
            bias_1h = self.mtf_engine.evaluate_1h_momentum(c_1h) if len(c_1h) >= 30 else TimeframeBias.NEUTRAL

            if bias_4h == TimeframeBias.BULLISH and bias_1h == TimeframeBias.BULLISH:
                confluence = "BULLISH_CONFLUENCE"
            elif bias_4h == TimeframeBias.BEARISH and bias_1h == TimeframeBias.BEARISH:
                confluence = "BEARISH_CONFLUENCE"
            else:
                confluence = "MIXED"

            return {
                **item,
                "bias_4h": bias_4h.value,
                "bias_1h": bias_1h.value,
                "confluence": confluence,
            }
        except Exception:
            return {
                **item,
                "bias_4h": "NEUTRAL",
                "bias_1h": "NEUTRAL",
                "confluence": "MIXED",
            }
