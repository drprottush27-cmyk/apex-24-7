import pandas as pd
from enum import Enum
from typing import Tuple, List

class SwingBias(str, Enum):
    BULLISH = "BULLISH"
    BEARISH = "BEARISH"
    NEUTRAL = "NEUTRAL"

def get_confirmed_pivots(highs: pd.Series, lows: pd.Series, left: int = 5, right: int = 5) -> Tuple[List[int], List[int]]:
    """
    Identify confirmed deterministic pivots.
    A pivot at index 'i' cannot be confirmed until index 'i + right' exists.
    """
    high_pivots = []
    low_pivots = []
    n = len(highs)
    
    # Bounded iteration physically prevents lookahead leakage.
    # We stop at n - right, guaranteeing 'right' candles exist.
    for i in range(left, n - right):
        # High Pivot logic: left side strictly greater, right side greater or equal
        left_high_max = highs.iloc[i-left : i].max()
        right_high_max = highs.iloc[i+1 : i+right+1].max()
        
        if highs.iloc[i] > left_high_max and highs.iloc[i] >= right_high_max:
            high_pivots.append(i)
            
        # Low Pivot logic: left side strictly lesser, right side lesser or equal
        left_low_min = lows.iloc[i-left : i].min()
        right_low_min = lows.iloc[i+1 : i+right+1].min()
        
        if lows.iloc[i] < left_low_min and lows.iloc[i] <= right_low_min:
            low_pivots.append(i)
            
    return high_pivots, low_pivots

def calculate_swing_bias(highs: pd.Series, lows: pd.Series, left: int = 5, right: int = 5) -> SwingBias:
    """
    Determine 4H Structural Swing Bias using only confirmed pivots.
    """
    if len(highs) < left + right + 1:
        return SwingBias.NEUTRAL
        
    high_pivots, low_pivots = get_confirmed_pivots(highs, lows, left, right)
    
    # Requires at least two confirmed highs and two confirmed lows
    if len(high_pivots) < 2 or len(low_pivots) < 2:
        return SwingBias.NEUTRAL
        
    latest_high = highs.iloc[high_pivots[-1]]
    prev_high = highs.iloc[high_pivots[-2]]
    
    latest_low = lows.iloc[low_pivots[-1]]
    prev_low = lows.iloc[low_pivots[-2]]
    
    if latest_high > prev_high and latest_low > prev_low:
        return SwingBias.BULLISH
    elif latest_high < prev_high and latest_low < prev_low:
        return SwingBias.BEARISH
    else:
        return SwingBias.NEUTRAL
