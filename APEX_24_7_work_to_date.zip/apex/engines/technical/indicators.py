import numpy as np
import pandas as pd

def calculate_ema(series: pd.Series, length: int) -> pd.Series:
    """
    Calculate Exponential Moving Average (EMA).
    Smoothing convention: Standard adjust=False (alpha = 2 / (length + 1)).
    """
    if len(series) < length:
        return pd.Series(np.nan, index=series.index)
    return series.ewm(span=length, adjust=False).mean()

def _wilder_smooth(series: pd.Series, length: int) -> pd.Series:
    """
    Wilder's Smoothing (SMMA). alpha = 1 / length.
    Ensures exact compliance with standard RSI/ADX definitions.
    """
    res = np.full_like(series.values, np.nan, dtype=np.float64)
    if len(series) < length:
        return pd.Series(res, index=series.index)
    
    # Initialize first valid value as simple moving average
    res[length - 1] = np.mean(series.values[:length])
    for i in range(length, len(series)):
        res[i] = (res[i - 1] * (length - 1) + series.values[i]) / length
        
    return pd.Series(res, index=series.index)

def calculate_rsi(series: pd.Series, length: int = 14) -> pd.Series:
    """
    Wilder's Relative Strength Index (RSI).
    """
    if len(series) < length + 1:
        return pd.Series(np.nan, index=series.index)
        
    delta = series.diff()
    up = delta.where(delta > 0, 0.0)
    down = -delta.where(delta < 0, 0.0)
    
    avg_up = _wilder_smooth(up, length)
    avg_down = _wilder_smooth(down, length)
    
    # Protect against div by zero on flat prices
    rsi = np.zeros_like(avg_up.values)
    rsi[(avg_down == 0) & (avg_up == 0)] = 50.0
    rsi[(avg_down == 0) & (avg_up > 0)] = 100.0
    
    mask = (avg_down > 0)
    rs = avg_up.values[mask] / avg_down.values[mask]
    rsi[mask] = 100.0 - (100.0 / (1.0 + rs))
    
    res = pd.Series(rsi, index=series.index)
    res.iloc[:length] = np.nan
    return res

def calculate_adx(high: pd.Series, low: pd.Series, close: pd.Series, length: int = 14) -> pd.Series:
    """
    Wilder's Average Directional Index (ADX).
    """
    if len(close) < length * 2:
        return pd.Series(np.nan, index=close.index)
        
    tr1 = high - low
    tr2 = (high - close.shift(1)).abs()
    tr3 = (low - close.shift(1)).abs()
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    
    up_move = high - high.shift(1)
    down_move = low.shift(1) - low
    
    plus_dm = np.where((up_move > down_move) & (up_move > 0), up_move, 0.0)
    minus_dm = np.where((down_move > up_move) & (down_move > 0), down_move, 0.0)
    
    plus_dm = pd.Series(plus_dm, index=close.index)
    minus_dm = pd.Series(minus_dm, index=close.index)
    
    atr = _wilder_smooth(tr, length)
    
    # Protect against div by zero on zero-volatility spans
    p_di = np.where(atr > 0, 100.0 * (_wilder_smooth(plus_dm, length) / atr), 0.0)
    m_di = np.where(atr > 0, 100.0 * (_wilder_smooth(minus_dm, length) / atr), 0.0)
    
    dx_denom = p_di + m_di
    dx = np.where(dx_denom > 0, 100.0 * np.abs(p_di - m_di) / dx_denom, 0.0)
    
    adx = _wilder_smooth(pd.Series(dx, index=close.index), length)
    adx.iloc[:length * 2 - 1] = np.nan
    return adx

def calculate_rvol(volume: pd.Series, length: int = 20) -> pd.Series:
    """
    Relative Volume (RVOL) = Volume / SMA(Volume, length).
    """
    if len(volume) < length:
        return pd.Series(np.nan, index=volume.index)
    sma_vol = volume.rolling(window=length, min_periods=length).mean()
    rvol = np.where(sma_vol > 0, volume / sma_vol, 0.0)
    return pd.Series(rvol, index=volume.index)
