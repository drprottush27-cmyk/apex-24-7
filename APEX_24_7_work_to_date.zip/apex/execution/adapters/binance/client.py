"""Consolidated Binance USD-M Futures REST client.

One HTTP session and one EndpointGuard resolve every REST call:

* Public market-data methods never invoke order/account gating and never
  attach API credentials.
* Signed order/account methods always call ``EndpointGuard.assert_can_submit_order``
  BEFORE any network I/O (fail closed).

Rate-limiting protection (P2-20):
* Shared process-level weight tracking and a single global 418-cooldown
  synchronized across all client instances.
* HTTP 418 is the global emergency IP-ban condition: never retried, a shared
  cooldown blocks ALL subsequent requests (public and signed) fail-closed.
* HTTP 429 is distinct from 418 and never writes the global cooldown.  A public
  idempotent GET may retry at most once, only with a valid, bounded Retry-After,
  after actually respecting the requested bounded delay.
* Signed/mutating requests are never automatically retried.
"""
from __future__ import annotations

import hashlib
import hmac
import time
import threading
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from urllib.parse import urlencode

import httpx

from core.config.settings import get_settings
from core.logging.logger import logger
from core.models.market import Candle, MarkPriceData, OpenInterestData, SymbolInfo
from execution.safety.endpoint_isolation import EndpointGuard


# ---------------------------------------------------------------------------
# Rate-limiting constants
# ---------------------------------------------------------------------------

RETRY_AFTER_UPPER_BOUND: int = 60
"""Maximum Retry-After seconds we will accept from Binance.  Values above
this are treated as malformed and ignored."""

DEFAULT_418_COOLDOWN: int = 300
"""Default global cooldown (seconds) when a 418 is received without a valid
Retry-After header."""

HIGH_WEIGHT_WARNING: int = 2000
"""Weight threshold at which a warning is logged (matches prior behavior)."""

# ---------------------------------------------------------------------------
# Shared process-level rate-limit state
#
# There are TWO distinct concepts with SEPARATE state:
#   * _cooldown_until  -- the GLOBAL 418/IP-ban cooldown.  It is written ONLY
#     when an HTTP 418 is received and read to fail-closed every request while
#     active.  A plain HTTP 429 NEVER writes this state.
#   * _last_used_weight -- observed Binance weight, shared for observability.
# ---------------------------------------------------------------------------

_rate_lock = threading.Lock()

_cooldown_until: float = 0.0
_last_used_weight: int = 0


def reset_shared_state() -> None:
    """Reset shared rate-limit state.  Intended for test isolation only."""
    global _cooldown_until, _last_used_weight
    with _rate_lock:
        _cooldown_until = 0.0
        _last_used_weight = 0


def get_cooldown_until() -> float:
    with _rate_lock:
        return _cooldown_until


def is_in_cooldown() -> bool:
    with _rate_lock:
        return time.monotonic() < _cooldown_until


def get_last_used_weight() -> int:
    with _rate_lock:
        return _last_used_weight


class RateLimitError(Exception):
    """Raised when a request is blocked by rate-limit protections."""


# ---------------------------------------------------------------------------
# Retry-After parsing
# ---------------------------------------------------------------------------

def _parse_retry_after(value: Optional[str]) -> Optional[int]:
    """Parse and bound a Retry-After header into whole seconds.

    Returns ``None`` when the value is missing, not a valid non-negative
    integer, negative, fractional, empty, or exceeds the documented safe
    upper bound :data:`RETRY_AFTER_UPPER_BOUND`.  ``int("3.5")`` raises and is
    therefore rejected.  Callers interpret ``None`` as "no acceptable
    Retry-After: do not retry."
    """
    if value is None:
        return None
    try:
        seconds = int(value.strip())
    except (ValueError, TypeError, AttributeError):
        return None
    if seconds < 0:
        return None
    if seconds > RETRY_AFTER_UPPER_BOUND:
        return None
    return seconds


# Clock/sleep abstraction so hermetic tests can assert delay behaviour without
# actually sleeping for up to the bounded maximum.
def _sleep(seconds: float) -> None:
    time.sleep(seconds)


# ---------------------------------------------------------------------------
# Single authoritative rate-limit response processor
# ---------------------------------------------------------------------------

def _process_rate_limit_response(response: httpx.Response) -> None:
    """Record weight and — for HTTP 418 only — establish the shared global
    cooldown.  Raises :class:`RateLimitError` for HTTP 418 (fail closed).

    Responsibilities are deliberately narrow and non-overlapping:
      * record observed weight from ``x-mbx-used-weight-1m`` (safe on bad
        header);
      * classify status;
      * for 418: establish/update the global ``_cooldown_until`` (bounded
        Retry-After if present, else :data:`DEFAULT_418_COOLDOWN`) and raise;
      * for 429: raise nothing about the global cooldown — the request-method
        logic decides whether a public idempotent retry is permitted. 429
        NEVER writes ``_cooldown_until``.
    """
    global _cooldown_until, _last_used_weight

    weight_val = response.headers.get("x-mbx-used-weight-1m")
    parsed_weight = None
    if weight_val:
        try:
            parsed_weight = int(weight_val)
        except (ValueError, TypeError):
            parsed_weight = None

    with _rate_lock:
        if parsed_weight is not None:
            _last_used_weight = parsed_weight

        if response.status_code == 418:
            retry_after = _parse_retry_after(response.headers.get("Retry-After"))
            now = time.monotonic()
            if retry_after is not None:
                _cooldown_until = now + retry_after
            elif _cooldown_until <= now:
                _cooldown_until = now + DEFAULT_418_COOLDOWN
            remaining = max(0, int(_cooldown_until - time.monotonic()))
            raise RateLimitError(f"HTTP 418 IP ban — cooldown {remaining}s")

    if response.status_code == 429:
        retry_after = _parse_retry_after(response.headers.get("Retry-After"))
        raise RateLimitError(f"HTTP 429 rate limit — Retry-After {retry_after}")

    if _last_used_weight > HIGH_WEIGHT_WARNING:
        logger.warning(
            "binance_high_rate_limit_weight",
            used_weight=_last_used_weight,
        )


def _assert_not_in_cooldown() -> None:
    """Fail-closed if the shared global 418 cooldown is active.

    Called before ANY REST request (public or signed) so that during an active
    418/IP-ban cooldown every request is blocked rather than hitting Binance.
    """
    with _rate_lock:
        remaining = _cooldown_until - time.monotonic()
    if remaining > 0:
        raise RateLimitError(
            f"HTTP 418 cooldown active — {int(remaining)}s remaining"
        )


def candles_from_klines(
    symbol: str,
    interval: str,
    rows: List[Any],
) -> List[Candle]:
    candles: List[Candle] = []
    for row in rows:
        candles.append(
            Candle(
                symbol=symbol.upper(),
                exchange="BINANCE",
                timeframe=interval,
                open_time=datetime.fromtimestamp(row[0] / 1000, tz=timezone.utc),
                close_time=datetime.fromtimestamp(row[6] / 1000, tz=timezone.utc),
                open=float(row[1]),
                high=float(row[2]),
                low=float(row[3]),
                close=float(row[4]),
                volume=float(row[5]),
                quote_volume=float(row[7]),
                trades_count=int(row[8]),
                is_closed=True,
            )
        )
    return candles


class BinanceFuturesClient:
    def __init__(
        self,
        guard: Optional[EndpointGuard] = None,
        timeout: float = 10.0,
        http_client: Optional[httpx.AsyncClient] = None,
    ):
        settings = get_settings()
        self.api_key = settings.BINANCE_API_KEY
        self.api_secret = settings.BINANCE_API_SECRET
        self.guard = guard or EndpointGuard()
        self._timeout = timeout
        self._client: Optional[httpx.AsyncClient] = http_client
        self._owns_http_client = http_client is None

    @property
    def base_url(self) -> str:
        return self.guard.base_url().rstrip("/")

    async def _http(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                timeout=self._timeout,
                headers={"User-Agent": "ApexTradingDesk/1.0"},
            )
            self._owns_http_client = True
        return self._client

    async def close(self) -> None:
        if self._owns_http_client and self._client and not self._client.is_closed:
            await self._client.aclose()
        self._client = None

    def _track_rate_limit(self, response: httpx.Response) -> httpx.Response:
        """Single authoritative hook invoked after every REST response.

        Delegates all metadata parsing / state transitions to
        :func:`_process_rate_limit_response` so there is ONE path for weight
        tracking, Retry-After parsing, 418-cooldown establishment, and 429
        classification.  Returns the (possibly retried) response.
        """
        _process_rate_limit_response(response)
        return response

    def _sign_payload(self, params: Dict[str, Any]) -> str:
        params["timestamp"] = int(time.time() * 1000)
        query_string = urlencode(params)
        secret = (self.api_secret or "").encode("utf-8")
        signature = hmac.new(
            secret,
            query_string.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()
        return f"{query_string}&signature={signature}"

    def _signed_headers(self) -> Dict[str, str]:
        return {
            "X-MBX-APIKEY": self.api_key or "",
            "Content-Type": "application/x-www-form-urlencoded",
        }

    def _private(self) -> None:
        """Fail closed BEFORE any signed/account/order network call."""
        self.guard.assert_can_submit_order()

    async def _send_public(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
    ) -> httpx.Response:
        _assert_not_in_cooldown()
        url = f"{self.base_url}{path}"
        http = await self._http()
        resp = await http.request(method, url, params=params)
        try:
            self._track_rate_limit(resp)
        except RateLimitError as e:
            # A 429 on a public idempotent GET with a valid, bounded
            # Retry-After is the ONLY automatically-retried condition.
            if (
                resp.status_code == 429
                and method.upper() == "GET"
                and "429" in str(e)
            ):
                retry_after = _parse_retry_after(resp.headers.get("Retry-After"))
                if retry_after is not None:
                    _sleep(float(retry_after))
                    return await self._send_public_retry(method, url, params, http)
            raise
        return resp

    async def _send_public_retry(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]],
        http: httpx.AsyncClient,
    ) -> httpx.Response:
        """Perform the single permitted public 429 retry (terminal).

        The retry is NOT retried again: ``_track_rate_limit`` raises for a
        second 429, and for a 418 it establishes the global cooldown and fails
        closed.  ``_assert_not_in_cooldown`` guarantees no retry storm.
        """
        _assert_not_in_cooldown()
        resp = await http.request(method, path, params=params)
        self._track_rate_limit(resp)
        return resp

    async def _send_signed(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
    ) -> httpx.Response:
        _assert_not_in_cooldown()
        self._private()
        signed_query = self._sign_payload(dict(params or {}))
        url = f"{self.base_url}{path}?{signed_query}"
        http = await self._http()
        resp = await http.request(method, url, headers=self._signed_headers())
        self._track_rate_limit(resp)
        return resp

    # -- public market data (no order/account gate, no API credentials) --

    async def get_server_time(self) -> int:
        res = await self._send_public("GET", "/fapi/v1/time")
        res.raise_for_status()
        return res.json()["serverTime"]

    async def get_exchange_info(self) -> Dict[str, Any]:
        res = await self._send_public("GET", "/fapi/v1/exchangeInfo")
        res.raise_for_status()
        return res.json()

    async def get_24hr_tickers(self) -> List[Dict[str, Any]]:
        res = await self._send_public("GET", "/fapi/v1/ticker/24hr")
        res.raise_for_status()
        data = res.json()
        if not isinstance(data, list):
            return []
        return data

    async def get_symbol_info(self, symbol: str) -> Optional[SymbolInfo]:
        data = await self.get_exchange_info()
        target = symbol.upper()
        for s in data.get("symbols", []):
            if s.get("symbol") == target:
                min_qty = 0.0
                step_size = 0.0
                tick_size = 0.0
                min_notional = 0.0

                for f in s.get("filters", []):
                    f_type = f.get("filterType")
                    if f_type == "LOT_SIZE":
                        min_qty = float(f.get("minQty", 0.0))
                        step_size = float(f.get("stepSize", 0.0))
                    elif f_type == "PRICE_FILTER":
                        tick_size = float(f.get("tickSize", 0.0))
                    elif f_type in ("MIN_NOTIONAL", "NOTIONAL"):
                        min_notional = float(f.get("notional", f.get("minNotional", 0.0)))

                return SymbolInfo(
                    symbol=s["symbol"],
                    base_asset=s["baseAsset"],
                    quote_asset=s["quoteAsset"],
                    status=s["status"],
                    min_qty=min_qty,
                    step_size=step_size,
                    tick_size=tick_size,
                    min_notional=min_notional,
                    is_trading=(s["status"] == "TRADING"),
                )
        return None

    async def get_klines(
        self,
        symbol: str,
        interval: str,
        limit: int = 100,
        start_time: Optional[int] = None,
        end_time: Optional[int] = None,
    ) -> List[Candle]:
        params: Dict[str, Any] = {
            "symbol": symbol.upper(),
            "interval": interval,
            "limit": limit,
        }
        if start_time:
            params["startTime"] = start_time
        if end_time:
            params["endTime"] = end_time

        res = await self._send_public("GET", "/fapi/v1/klines", params=params)
        res.raise_for_status()
        return candles_from_klines(symbol, interval, res.json())

    async def get_mark_price(self, symbol: str) -> MarkPriceData:
        res = await self._send_public(
            "GET",
            "/fapi/v1/premiumIndex",
            params={"symbol": symbol.upper()},
        )
        res.raise_for_status()
        data = res.json()

        return MarkPriceData(
            symbol=data["symbol"],
            mark_price=float(data["markPrice"]),
            index_price=float(data["indexPrice"]),
            estimated_settle_price=float(data.get("estimatedSettlePrice", 0.0)) if data.get("estimatedSettlePrice") else None,
            funding_rate=float(data["lastFundingRate"]),
            next_funding_time=datetime.fromtimestamp(data["nextFundingTime"] / 1000, tz=timezone.utc),
        )

    async def get_open_interest(self, symbol: str) -> OpenInterestData:
        res = await self._send_public(
            "GET",
            "/fapi/v1/openInterest",
            params={"symbol": symbol.upper()},
        )
        res.raise_for_status()
        data = res.json()

        return OpenInterestData(
            symbol=data["symbol"],
            open_interest=float(data["openInterest"]),
        )

    # -- signed order / account (gated) ---------------------------------

    async def get_account_balance(self) -> Dict[str, Any]:
        resp = await self._send_signed("GET", "/fapi/v2/account")
        resp.raise_for_status()
        return resp.json()

    async def set_leverage(self, symbol: str, leverage: int = 5) -> Dict[str, Any]:
        params = {"symbol": symbol.upper(), "leverage": leverage}
        resp = await self._send_signed("POST", "/fapi/v1/leverage", params)
        resp.raise_for_status()
        return resp.json()

    async def set_margin_type(self, symbol: str, margin_type: str = "ISOLATED") -> Optional[Dict[str, Any]]:
        params = {"symbol": symbol.upper(), "marginType": margin_type.upper()}
        resp = await self._send_signed("POST", "/fapi/v1/marginType", params)
        if resp.status_code == 200:
            return resp.json()
        if "No need to change" in resp.text:
            return {"msg": "unchanged"}
        resp.raise_for_status()
        return resp.json()

    async def post_order(
        self,
        symbol: str,
        side: str,
        order_type: str,
        quantity: float,
        price: Optional[float] = None,
        client_order_id: Optional[str] = None,
        reduce_only: bool = False,
    ) -> Dict[str, Any]:
        params: Dict[str, Any] = {
            "symbol": symbol.upper(),
            "side": side.upper(),
            "type": order_type.upper(),
            "quantity": quantity,
        }

        if client_order_id:
            params["newClientOrderId"] = client_order_id

        if reduce_only:
            params["reduceOnly"] = "true"

        if order_type.upper() == "LIMIT":
            params["price"] = price
            params["timeInForce"] = "GTC"

        resp = await self._send_signed("POST", "/fapi/v1/order", params)
        if resp.status_code != 200:
            logger.error("binance_order_rejected", status=resp.status_code, body=resp.text)
        resp.raise_for_status()
        return resp.json()

    async def cancel_order(self, symbol: str, client_order_id: str) -> Dict[str, Any]:
        params = {
            "symbol": symbol.upper(),
            "origClientOrderId": client_order_id,
        }
        resp = await self._send_signed("DELETE", "/fapi/v1/order", params)
        resp.raise_for_status()
        return resp.json()
