import json
from datetime import datetime, timezone
from typing import Dict, List, Optional
from sqlalchemy import select

from core.logging.logger import logger
from core.models.market import Candle, MarkPriceData
from core.models.schema import MarketSnapshot
from infrastructure.postgres.database import AsyncSessionLocal
from infrastructure.redis.client import get_redis_client
from execution.adapters.binance.rest_client import BinanceFuturesRESTClient
from execution.adapters.binance.ws_client import BinanceFuturesWSClient
from execution.safety.endpoint_isolation import EndpointGuard


class BinanceMarketDataFeed:
    def __init__(self, symbols: List[str], timeframes: List[str]):
        self.symbols = [s.upper() for s in symbols]
        self.timeframes = timeframes
        self.guard = EndpointGuard()
        self.rest_client = BinanceFuturesRESTClient(guard=self.guard)
        self._latest_candles: Dict[str, Candle] = {}
        self._latest_mark_prices: Dict[str, MarkPriceData] = {}

        streams = []
        for s in self.symbols:
            s_low = s.lower()
            streams.append(f"{s_low}@markPrice@1s")
            for tf in self.timeframes:
                streams.append(f"{s_low}@kline_{tf}")

        self.ws_client = BinanceFuturesWSClient(streams=streams, guard=self.guard)
        self.ws_client.add_listener(self._on_stream_event)

    @property
    def redis(self):
        return get_redis_client()

    async def _on_stream_event(self, stream: str, payload: any) -> None:
        try:
            if isinstance(payload, Candle):
                key = f"{payload.symbol}:{payload.timeframe}"
                self._latest_candles[key] = payload

                # 1. Update persistent Redis cache key (TTL: 1 hour)
                await self.redis.set(
                    f"apex:candle:{payload.symbol}:{payload.timeframe}",
                    payload.model_dump_json(),
                    ex=3600
                )

                # 2. Publish to Pub/Sub stream
                channel = f"apex:market:kline:{payload.symbol}:{payload.timeframe}"
                await self.redis.publish(channel, payload.model_dump_json())

                # 3. Persist closed candles to PostgreSQL
                if payload.is_closed:
                    await self._persist_closed_candle(payload)

            elif isinstance(payload, MarkPriceData):
                self._latest_mark_prices[payload.symbol] = payload

                # 1. Update persistent Redis cache key (TTL: 60s)
                await self.redis.set(
                    f"apex:mark:{payload.symbol}",
                    payload.model_dump_json(),
                    ex=60
                )

                # 2. Publish to Pub/Sub stream
                channel = f"apex:market:mark:{payload.symbol}"
                await self.redis.publish(channel, payload.model_dump_json())

        except Exception as e:
            logger.error("data_feed_event_handling_error", error=str(e))

    async def _persist_closed_candle(self, candle: Candle) -> None:
        try:
            async with AsyncSessionLocal() as session:
                snapshot = MarketSnapshot(
                    symbol=candle.symbol,
                    exchange=candle.exchange,
                    timeframe=candle.timeframe,
                    timestamp=candle.close_time,
                    open=candle.open,
                    high=candle.high,
                    low=candle.low,
                    close=candle.close,
                    volume=candle.volume,
                )
                session.add(snapshot)
                await session.commit()
                logger.info("candle_persisted_postgres", symbol=candle.symbol, timeframe=candle.timeframe)
        except Exception as e:
            logger.error("failed_to_persist_candle_snapshot", symbol=candle.symbol, error=str(e))

    async def preload_history(self, symbol: str, timeframe: str, limit: int = 100) -> List[Candle]:
        candles = await self.rest_client.get_klines(symbol=symbol, interval=timeframe, limit=limit)
        if candles:
            latest = candles[-1]
            self._latest_candles[f"{symbol.upper()}:{timeframe}"] = latest
            # Preload into Redis immediately on startup
            await self.redis.set(
                f"apex:candle:{symbol.upper()}:{timeframe}",
                latest.model_dump_json(),
                ex=3600
            )
        return candles

    def get_cached_candle(self, symbol: str, timeframe: str) -> Optional[Candle]:
        return self._latest_candles.get(f"{symbol.upper()}:{timeframe}")

    def get_cached_mark_price(self, symbol: str) -> Optional[MarkPriceData]:
        return self._latest_mark_prices.get(symbol.upper())

    def start(self) -> None:
        self.ws_client.start()

    async def stop(self) -> None:
        await self.ws_client.stop()
        await self.rest_client.close()
