"""Compatibility re-export of the canonical Binance Futures WebSocket client.

Historical ``BinanceFuturesWebSocket`` is the same class as
``BinanceFuturesWSClient`` (the production market-data adapter used by
``BinanceMarketDataFeed``).
"""
from execution.adapters.binance.ws_client import BinanceFuturesWSClient as BinanceFuturesWebSocket

__all__ = ["BinanceFuturesWebSocket"]
