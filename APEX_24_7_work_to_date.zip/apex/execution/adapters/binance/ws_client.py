import json
import asyncio
from datetime import datetime, timezone
from typing import List, Callable, Optional, Dict, Any
import websockets
from websockets.exceptions import ConnectionClosed

from core.logging.logger import logger
from core.models.market import Candle, MarkPriceData
from execution.safety.endpoint_isolation import EndpointGuard


class BinanceFuturesWSClient:
    def __init__(self, streams: List[str], guard: Optional[EndpointGuard] = None):
        formatted = []
        for s in streams:
            if "@" in s:
                symbol_part, stream_part = s.split("@", 1)
                formatted.append(f"{symbol_part.lower()}@{stream_part}")
            else:
                formatted.append(s.lower())
        self.streams = formatted
        self.guard = guard or EndpointGuard()
        self._running = False
        self._task: Optional[asyncio.Task] = None
        self._callbacks: List[Callable[[str, Any], Any]] = []

    @property
    def BASE_WS_URL(self) -> str:
        return self.guard.ws_url()

    def add_listener(self, callback: Callable[[str, Any], Any]) -> None:
        self._callbacks.append(callback)

    def _parse_kline(self, data: Dict[str, Any]) -> Candle:
        k = data["k"]
        return Candle(
            symbol=k["s"],
            exchange="BINANCE",
            timeframe=k["i"],
            open_time=datetime.fromtimestamp(k["t"] / 1000, tz=timezone.utc),
            close_time=datetime.fromtimestamp(k["T"] / 1000, tz=timezone.utc),
            open=float(k["o"]),
            high=float(k["h"]),
            low=float(k["l"]),
            close=float(k["c"]),
            volume=float(k["v"]),
            quote_volume=float(k["q"]),
            trades_count=int(k["n"]),
            is_closed=bool(k["x"]),
        )

    def _parse_mark_price(self, data: Dict[str, Any]) -> MarkPriceData:
        return MarkPriceData(
            symbol=data["s"],
            mark_price=float(data["p"]),
            index_price=float(data["i"]),
            estimated_settle_price=float(data.get("P", 0.0)) if data.get("P") else None,
            funding_rate=float(data["r"]),
            next_funding_time=datetime.fromtimestamp(data["T"] / 1000, tz=timezone.utc),
        )

    async def _handle_message(self, raw_msg: str) -> None:
        try:
            payload = json.loads(raw_msg)
            if "result" in payload and payload.get("id") is not None:
                logger.info("binance_ws_subscription_ack", id=payload.get("id"))
                return

            if "stream" in payload and "data" in payload:
                stream_name = payload["stream"]
                data = payload["data"]
            else:
                stream_name = payload.get("s", "")
                data = payload

            event_type = data.get("e")
            parsed_payload: Any = None
            if event_type == "kline":
                parsed_payload = self._parse_kline(data)
            elif event_type == "markPriceUpdate":
                parsed_payload = self._parse_mark_price(data)
            else:
                parsed_payload = data

            for cb in self._callbacks:
                if asyncio.iscoroutinefunction(cb):
                    await cb(stream_name, parsed_payload)
                else:
                    cb(stream_name, parsed_payload)

        except Exception as e:
            logger.error("ws_message_handling_error", error=str(e), raw=raw_msg[:120])

    async def _connect_loop(self) -> None:
        backoff = 1.0
        headers = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"}

        while self._running:
            try:
                logger.info("connecting_binance_ws", url=self.BASE_WS_URL, streams=self.streams)
                
                connect_kwargs = {
                    "ping_interval": 15,
                    "ping_timeout": 15,
                    "close_timeout": 5,
                    "max_size": 2**22,
                }
                
                try:
                    ws_ctx = websockets.connect(self.BASE_WS_URL, additional_headers=headers, **connect_kwargs)
                except TypeError:
                    ws_ctx = websockets.connect(self.BASE_WS_URL, extra_headers=headers, **connect_kwargs)

                async with ws_ctx as ws:
                    backoff = 1.0
                    logger.info("binance_ws_connected")

                    # Dispatch dynamic subscription RPC
                    sub_payload = {
                        "method": "SUBSCRIBE",
                        "params": self.streams,
                        "id": int(datetime.now(timezone.utc).timestamp())
                    }
                    await ws.send(json.dumps(sub_payload))

                    async for raw_msg in ws:
                        if not self._running:
                            break
                        await self._handle_message(raw_msg)

            except (ConnectionClosed, asyncio.TimeoutError, Exception) as e:
                if not self._running:
                    break
                logger.warning("binance_ws_disconnected", error=str(e), retry_in=backoff)
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 30.0)

    def start(self) -> None:
        if not self._running:
            self._running = True
            self._task = asyncio.create_task(self._connect_loop())

    async def stop(self) -> None:
        self._running = False
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        logger.info("binance_ws_stopped")
