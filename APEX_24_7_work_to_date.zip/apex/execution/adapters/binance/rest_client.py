"""Public market-data facade over the consolidated Binance REST client.

Callers that historically imported ``BinanceFuturesRESTClient`` keep that
name. The class is the same HTTP/URL layer as ``BinanceFuturesClient``:
public methods never invoke order/account gating.
"""
from execution.adapters.binance.client import BinanceFuturesClient


class BinanceFuturesRESTClient(BinanceFuturesClient):
    """Compatibility alias kept so data-feed imports stay stable."""
