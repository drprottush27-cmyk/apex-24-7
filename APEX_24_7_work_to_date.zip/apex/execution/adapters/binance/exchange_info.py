import math
from typing import Any, Dict, Optional

from core.logging.logger import logger
from execution.adapters.binance.client import BinanceFuturesClient
from execution.safety.endpoint_isolation import EndpointGuard


class BinanceExchangeFilterCache:
    def __init__(
        self,
        client: Optional[BinanceFuturesClient] = None,
        guard: Optional[EndpointGuard] = None,
    ):
        self._client = client
        self._guard = guard
        self._symbol_rules: Dict[str, Dict[str, Any]] = {}

    def _rest(self) -> BinanceFuturesClient:
        if self._client is None:
            self._client = BinanceFuturesClient(guard=self._guard)
        return self._client

    @property
    def base_url(self) -> str:
        return self._rest().base_url

    async def sync_rules(self) -> None:
        try:
            data = await self._rest().get_exchange_info()

            for s in data.get("symbols", []):
                sym = s["symbol"]
                rules = {
                    "status": s.get("status"),
                    "contractType": s.get("contractType"),
                    "pricePrecision": s.get("pricePrecision", 2),
                    "quantityPrecision": s.get("quantityPrecision", 3),
                    "minPrice": 0.0,
                    "maxPrice": 10000000.0,
                    "tickSize": 0.01,
                    "minQty": 0.001,
                    "maxQty": 100000.0,
                    "stepSize": 0.001,
                    "minNotional": 5.0,
                }

                for f in s.get("filters", []):
                    f_type = f.get("filterType")
                    if f_type == "PRICE_FILTER":
                        rules["minPrice"] = float(f.get("minPrice", 0.0))
                        rules["maxPrice"] = float(f.get("maxPrice", 0.0))
                        rules["tickSize"] = float(f.get("tickSize", 0.01))
                    elif f_type == "LOT_SIZE":
                        rules["minQty"] = float(f.get("minQty", 0.0))
                        rules["maxQty"] = float(f.get("maxQty", 0.0))
                        rules["stepSize"] = float(f.get("stepSize", 0.001))
                    elif f_type == "MIN_NOTIONAL":
                        rules["minNotional"] = float(f.get("notional", 5.0))

                self._symbol_rules[sym] = rules

            logger.info("binance_exchange_rules_synced", symbols_loaded=len(self._symbol_rules))
        except Exception as e:
            logger.error("failed_to_sync_exchange_rules", error=str(e))

    def format_quantity(self, symbol: str, quantity: float) -> float:
        rules = self._symbol_rules.get(symbol.upper())
        if not rules:
            return round(quantity, 3)

        step = rules["stepSize"]
        precision = rules["quantityPrecision"]
        if step > 0:
            steps_count = math.floor(quantity / step)
            rounded = steps_count * step
            return round(rounded, precision)
        return round(quantity, precision)

    def format_price(self, symbol: str, price: float) -> float:
        rules = self._symbol_rules.get(symbol.upper())
        if not rules:
            return round(price, 2)

        tick = rules["tickSize"]
        precision = rules["pricePrecision"]
        if tick > 0:
            ticks_count = round(price / tick)
            rounded = ticks_count * tick
            return round(rounded, precision)
        return round(price, precision)

    def validate_notional(self, symbol: str, quantity: float, price: float) -> bool:
        rules = self._symbol_rules.get(symbol.upper())
        if not rules:
            return (quantity * price) >= 5.0
        return (quantity * price) >= rules["minNotional"]
