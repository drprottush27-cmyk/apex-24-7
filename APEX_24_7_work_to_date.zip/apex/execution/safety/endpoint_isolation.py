"""Fail-closed endpoint isolation for the Binance adapter.

Testnet support, isolated from production. Guarantees:

* Testnet is DISABLED by default (``BINANCE_USE_TESTNET=False``).
* Order/account operations against PRODUCTION endpoints are REJECTED unless
  the system is genuinely LIVE-enabled (the LIVE_TRADING_ENABLED flag on AND
  the trading mode set to LIVE).
* Testnet NEVER falls back to production: if testnet is requested but its URL
  is missing/invalid, the guard fails closed (raises) instead of leaking to the
  production endpoint.
* There is no automatic transition between environments.
"""
from __future__ import annotations

from urllib.parse import urlparse

from core.config.settings import TradingMode, get_settings
from core.logging.logger import logger

# Official USD-M Futures REST -> market-data WebSocket mapping.
# Never invent a production stream URL for an unrecognized REST host.
_REST_TO_WS = {
    "https://fapi.binance.com": "wss://fstream.binance.com/ws",
    "https://testnet.binancefuture.com": "wss://stream.binancefuture.com/ws",
}


class EndpointIsolationError(Exception):
    """Raised when an order/account operation would cross an isolation boundary
    (e.g. reaching a production endpoint without LIVE being explicitly enabled,
    or reaching production while testnet is configured). Never auto-continues."""


class EndpointGuard:
    """Resolves the active exchange environment and gates private operations.

    Used by the Binance client so that signed/order methods target exactly the
    configured environment and are rejected (fail closed) otherwise.
    """

    def __init__(self, settings=None):
        self._settings = settings or get_settings()
        self._cache: str | None = None
        self._cache_env: str | None = None

    # -- environment resolution ------------------------------------------
    @property
    def use_testnet(self) -> bool:
        return bool(self._settings.BINANCE_USE_TESTNET)

    @property
    def production_url(self) -> str:
        return (self._settings.BINANCE_PRODUCTION_BASE_URL or "").strip()

    @property
    def testnet_url(self) -> str:
        return (self._settings.BINANCE_TESTNET_BASE_URL or "").strip()

    def active_environment(self) -> str:
        """Return 'TESTNET' or 'PRODUCTION' for the current config.

        Fail-closed checks: an empty/malformed production URL is rejected (we
        must never silently place orders at an unknown host); testnet is only
        selected when explicitly requested AND its URL is valid.
        """
        if self.use_testnet:
            if not self._is_valid_url(self.testnet_url):
                logger.error(
                    "endpoint_isolation_invalid_testnet_url_fail_closed",
                    testnet_url=self.testnet_url,
                )
                raise EndpointIsolationError(
                    "BINANCE_USE_TESTNET=True but BINANCE_TESTNET_BASE_URL is "
                    "invalid. Fail closed: refusing to fall back to production."
                )
            return "TESTNET"

        if not self._is_valid_url(self.production_url):
            logger.error(
                "endpoint_isolation_invalid_production_url_fail_closed",
                production_url=self.production_url,
            )
            raise EndpointIsolationError(
                "BINANCE_PRODUCTION_BASE_URL is invalid. Fail closed: refusing "
                "to target an unknown endpoint."
            )
        return "PRODUCTION"

    @staticmethod
    def _is_valid_url(url: str) -> bool:
        if not url:
            return False
        parsed = urlparse(url)
        return parsed.scheme in ("https", "http") and bool(parsed.netloc)

    def base_url(self) -> str:
        env = self.active_environment()
        if self._cache is not None and self._cache_env == env:
            return self._cache
        self._cache_env = env
        self._cache = self.production_url if env == "PRODUCTION" else self.testnet_url
        logger.info(
            "endpoint_isolation_resolved",
            environment=env,
            base_url=self._cache,
        )
        return self._cache

    def ws_url(self) -> str:
        """Official USD-M Futures market-data WebSocket URL for the active REST env.

        Mapped 1:1 from the resolved REST base URL. An unknown REST host fails
        closed instead of silently connecting to production ``fstream.binance.com``.
        """
        rest = self.base_url().rstrip("/")
        mapped = _REST_TO_WS.get(rest)
        if mapped is None:
            logger.error(
                "endpoint_isolation_unknown_ws_mapping_fail_closed",
                rest_base_url=rest,
            )
            raise EndpointIsolationError(
                f"No official WebSocket mapping for REST base URL {rest}. "
                "Fail closed: refusing to guess a production stream host."
            )
        return mapped

    # -- order/account gating --------------------------------------------
    def assert_can_access_environment(self, environment: str) -> None:
        """Fail closed if a private operation is attempted on a disallowed env.

        Only two environments are reachable:
        * TESTNET — only when ``BINANCE_USE_TESTNET=True``.
        * PRODUCTION — only when the system is explicitly LIVE-enabled.

        Anything else (or a mismatch) raises :class:`EndpointIsolationError`
        and never proceeds to a network call.
        """
        active = self.active_environment()

        if environment != active:
            raise EndpointIsolationError(
                f"Endpoint isolation boundary crossed: requested {environment} "
                f"but active environment is {active}. Refusing to leak across "
                "environments (no production fallback)."
            )

        if environment == "PRODUCTION" and not self._is_live_enabled():
            logger.error(
                "endpoint_isolation_production_rejected",
                live_trading_enabled=self._live_enabled(),
                trading_mode=self._settings.TRADING_MODE.value,
            )
            raise EndpointIsolationError(
                "Production order/account endpoint rejected: the system is not "
                "explicitly LIVE-enabled. Fail closed. Required: the "
                "LIVE_TRADING_ENABLED flag on AND trading mode set to LIVE."
            )

        if environment == "TESTNET" and not self.use_testnet:
            raise EndpointIsolationError(
                "Testnet requested but BINANCE_USE_TESTNET is False. Fail closed."
            )

    def assert_can_submit_order(self) -> None:
        """Convenience gate used by order/account clients.

        Never auto-falls-back to production: resolution is authoritative and
        exceptions propagate so the caller treats the attempt as rejected.
        """
        env = self.active_environment()
        self.assert_can_access_environment(env)
        return env

    def _is_live_enabled(self) -> bool:
        return (
            self._live_enabled()
            and self._settings.TRADING_MODE == TradingMode.LIVE
        )

    def _live_enabled(self) -> bool:
        return bool(self._settings.LIVE_TRADING_ENABLED)
