import asyncio
import json
import math
import uuid
from typing import Dict, Optional, Set, List
from datetime import datetime, timezone
from sqlalchemy import select

from core.config.settings import get_settings, TradingMode
from core.logging.logger import logger
from core.models.order import (
    OrderRequest, OrderResult, OrderSide, OrderType, OrderStatus, Position, PendingOrderRecord
)
from core.models.signal import TradeSignal
from core.models.journal import TradeJournalEntry
from core.models.schema import Order as DBOrder, AuditLog
from engines.risk.guardian import RiskCheckResult
from infrastructure.postgres.database import AsyncSessionLocal
from infrastructure.redis.client import get_redis_client
from infrastructure.journal.dispatcher import JournalDispatcher
from infrastructure.notifications.notifier import NotificationGateway
from execution.adapters.binance.client import BinanceFuturesClient
from execution.adapters.binance.exchange_info import BinanceExchangeFilterCache
from execution.safety.kill_switch import KillSwitch, KillSwitchEngaged


def _is_valid_leverage(leverage) -> bool:
    if isinstance(leverage, bool):
        return False
    if not isinstance(leverage, (int, float)):
        return False
    try:
        if not math.isfinite(float(leverage)):
            return False
    except (ValueError, OverflowError):
        return False
    if leverage <= 0:
        return False
    return True


class OrderExecutionManager:
    def __init__(self, on_realized_pnl=None):
        self.settings = get_settings()
        self.journal_dispatcher = JournalDispatcher()
        self.notifier = NotificationGateway()
        self.binance_client = BinanceFuturesClient()
        self.filter_cache = BinanceExchangeFilterCache(client=self.binance_client)

        # Emergency kill switch: fail-closed execution-path veto (P2-14).
        # Checked at the top of execute_order() — the single funnel every
        # order request (orchestrator, agent, provider, direct call, and
        # reduce-only close) must pass through. Once engaged, no order path can
        # bypass it.
        self.kill_switch = KillSwitch()

        self._positions: Dict[str, Position] = {}
        self._position_metadata: Dict[str, dict] = {}
        self._pending_orders: Dict[str, PendingOrderRecord] = {}
        self._initialized = False
        self._on_realized_pnl = on_realized_pnl

        self._dedup_keys: Set[str] = set()
        self._dedup_lock = asyncio.Lock()

    @property
    def redis(self):
        return get_redis_client()

    async def initialize(self) -> None:
        if not self._initialized:
            await self.filter_cache.sync_rules()
            self._initialized = True

    def get_position(self, symbol: str) -> Optional[Position]:
        return self._positions.get(symbol.upper())

    def get_all_positions(self) -> List[Position]:
        return list(self._positions.values())

    async def _reserve_order_identity(self, dedup_key: str, symbol: str, side: OrderSide) -> bool:
        """Atomically check-and-register a duplicate identity.

        Returns True if the identity was freshly reserved (not a duplicate),
        False if it was already registered (duplicate). Runs under the dedup
        lock so concurrent callers cannot both pass the check-and-register.
        """
        async with self._dedup_lock:
            if dedup_key in self._dedup_keys:
                logger.warning(
                    "duplicate_order_rejected",
                    symbol=symbol,
                    side=side.value,
                    dedup_key=dedup_key,
                )
                return False
            self._dedup_keys.add(dedup_key)
            return True

    async def _persist_order(self, order: OrderResult, mode: str, sl: Optional[float], tp: Optional[float]) -> None:
        try:
            async with AsyncSessionLocal() as session:
                db_order = DBOrder(
                    client_order_id=order.client_order_id,
                    exchange_order_id=order.exchange_order_id,
                    symbol=order.symbol,
                    exchange="BINANCE",
                    side=order.side.value,
                    order_type=order.order_type.value,
                    quantity=order.requested_quantity,
                    price=order.avg_fill_price if order.avg_fill_price > 0 else None,
                    stop_loss=sl,
                    take_profit=tp,
                    status=order.status.value,
                    mode=mode,
                )
                session.add(db_order)

                log_entry = AuditLog(
                    event_type="ORDER_EXECUTED",
                    service="ORDER_MANAGER",
                    severity="INFO",
                    details={
                        "client_order_id": order.client_order_id,
                        "symbol": order.symbol,
                        "status": order.status.value,
                        "fill_price": order.avg_fill_price,
                        "qty": order.executed_quantity,
                        "mode": mode,
                    }
                )
                session.add(log_entry)
                await session.commit()
        except Exception as e:
            logger.error("order_db_persistence_failed", client_order_id=order.client_order_id, error=str(e))

    async def execute_order(self, request: OrderRequest) -> OrderResult:
        # FAIL-CLOSED EXECUTION-PATH VETO (P2-14): the emergency kill switch is
        # checked here, at the single execution funnel, BEFORE any dedup
        # reservation, risk sizing, DRY_RUN simulation, or live-exchange call.
        # Every order path — orchestrator, agent, provider, and direct callers,
        # including reduce-only protective closes — passes through this method
        # and is rejected while the switch is engaged. There is no bypass.
        if self.kill_switch.is_engaged():
            logger.error(
                "order_rejected_kill_switch_engaged",
                symbol=request.symbol,
                side=request.side.value,
                reason=self.kill_switch.reason,
            )
            return OrderResult(
                client_order_id=request.client_order_id,
                exchange_order_id="",
                symbol=request.symbol.upper(),
                side=request.side,
                order_type=request.order_type,
                status=OrderStatus.REJECTED,
                requested_quantity=0.0,
                executed_quantity=0.0,
                avg_fill_price=0.0,
                fee=0.0,
                message=f"KILL_SWITCH: execution halted ({self.kill_switch.reason})",
            )

        if not self._initialized:
            await self.initialize()

        sym = request.symbol.upper()

        if request.dedup_key is not None and not await self._reserve_order_identity(request.dedup_key, sym, request.side):
            return OrderResult(
                client_order_id=request.client_order_id,
                exchange_order_id="",
                symbol=sym,
                side=request.side,
                order_type=request.order_type,
                status=OrderStatus.REJECTED,
                requested_quantity=0.0,
                executed_quantity=0.0,
                avg_fill_price=0.0,
                fee=0.0,
                message=f"Duplicate order rejected: {request.dedup_key}",
            )

        if not _is_valid_leverage(request.leverage):
            logger.error("order_rejected_invalid_leverage", symbol=sym, leverage=request.leverage)
            return OrderResult(
                client_order_id=request.client_order_id,
                exchange_order_id="",
                symbol=sym,
                side=request.side,
                order_type=request.order_type,
                status=OrderStatus.REJECTED,
                requested_quantity=0.0,
                executed_quantity=0.0,
                avg_fill_price=0.0,
                fee=0.0,
                message=f"Rejected: invalid leverage {request.leverage}",
            )

        formatted_qty = self.filter_cache.format_quantity(sym, request.quantity)
        formatted_price = self.filter_cache.format_price(sym, request.price) if request.price else None

        is_dry_run = (self.settings.TRADING_MODE == TradingMode.DRY_RUN)

        if is_dry_run:
            slippage_mult = 1.00015 if request.side == OrderSide.BUY else 0.99985
            base_price = formatted_price if formatted_price else 60000.0
            fill_price = round(base_price * slippage_mult, 4)
            simulated_exchange_id = f"sim_{uuid.uuid4().hex[:10]}"

            result = OrderResult(
                client_order_id=request.client_order_id,
                exchange_order_id=simulated_exchange_id,
                symbol=sym,
                side=request.side,
                order_type=request.order_type,
                status=OrderStatus.FILLED,
                requested_quantity=formatted_qty,
                executed_quantity=formatted_qty,
                avg_fill_price=fill_price,
                fee=round(fill_price * formatted_qty * 0.0004, 4),
                message="Simulated fill completed under DRY_RUN mode",
            )
        else:
            try:
                await self.binance_client.set_margin_type(sym, "ISOLATED")
                await self.binance_client.set_leverage(sym, request.leverage)

                raw_resp = await self.binance_client.post_order(
                    symbol=sym,
                    side=request.side.value,
                    order_type=request.order_type.value,
                    quantity=formatted_qty,
                    price=formatted_price,
                    client_order_id=request.client_order_id,
                    reduce_only=request.reduce_only,
                )

                avg_price = float(raw_resp.get("avgPrice", 0.0))
                if avg_price == 0.0 and formatted_price:
                    avg_price = formatted_price

                status_map = {
                    "NEW": OrderStatus.SUBMITTED,
                    "FILLED": OrderStatus.FILLED,
                    "PARTIALLY_FILLED": OrderStatus.PARTIALLY_FILLED,
                    "CANCELED": OrderStatus.CANCELLED,
                    "REJECTED": OrderStatus.REJECTED,
                    "EXPIRED": OrderStatus.EXPIRED,
                }

                result = OrderResult(
                    client_order_id=request.client_order_id,
                    exchange_order_id=str(raw_resp.get("orderId")),
                    symbol=sym,
                    side=request.side,
                    order_type=request.order_type,
                    status=status_map.get(raw_resp.get("status", ""), OrderStatus.SUBMITTED),
                    requested_quantity=formatted_qty,
                    executed_quantity=float(raw_resp.get("executedQty", formatted_qty)),
                    avg_fill_price=avg_price,
                    fee=0.0,
                    message="Live order executed on Binance USD-M Futures",
                )
            except Exception as e:
                logger.error("binance_live_order_failed", symbol=sym, error=str(e))
                return OrderResult(
                    client_order_id=request.client_order_id,
                    exchange_order_id="",
                    symbol=sym,
                    side=request.side,
                    order_type=request.order_type,
                    status=OrderStatus.REJECTED,
                    requested_quantity=formatted_qty,
                    executed_quantity=0.0,
                    avg_fill_price=0.0,
                    fee=0.0,
                    message=f"Live execution failed: {str(e)}",
                )

        if not request.reduce_only and result.status == OrderStatus.FILLED:
            self._update_position_from_fill(result, request.stop_loss, request.take_profit, request.leverage)

        if not request.reduce_only and result.status == OrderStatus.SUBMITTED:
            self._pending_orders[result.client_order_id] = PendingOrderRecord(
                client_order_id=result.client_order_id,
                symbol=result.symbol,
                side=result.side,
                dedup_key=request.dedup_key,
                created_timestamp=datetime.now(timezone.utc)
            )
        elif result.status in (OrderStatus.FILLED, OrderStatus.CANCELLED, OrderStatus.REJECTED):
            self._pending_orders.pop(result.client_order_id, None)

        mode_str = "DRY_RUN" if is_dry_run else "LIVE"
        await self._persist_order(result, mode=mode_str, sl=request.stop_loss, tp=request.take_profit)

        pos = self.get_position(request.symbol)
        if pos:
            await self.redis.set(f"apex:position:{sym}", pos.model_dump_json(), ex=86400)

        logger.info("order_executed_successfully", symbol=sym, mode=mode_str, side=request.side.value, fill=result.avg_fill_price)
        return result

    async def kill_switch_halt(self, reason: str = "") -> str:
        """Operator control: engage the emergency kill switch immediately.

        Once engaged, every subsequent order attempt through ``execute_order``
        is rejected (fail closed). The authoritative halt is applied first;
        a best-effort CRITICAL audit trail is written afterward."""
        halt_reason = self.kill_switch.halt(reason)
        logger.error("kill_switch_engaged", reason=halt_reason)
        from core.models.schema import AuditLog as _AuditLog
        try:
            async with AsyncSessionLocal() as session:
                session.add(_AuditLog(
                    event_type="EMERGENCY_KILL_SWITCH",
                    service="ORDER_MANAGER",
                    severity="CRITICAL",
                    details={"action": "HALT", "reason": halt_reason},
                ))
                await session.commit()
        except Exception as e:  # noqa: BLE001 - audit is best-effort; halt applied regardless
            logger.error("kill_switch_audit_failed", error=str(e))
        return halt_reason

    def kill_switch_release(self, reason: str = "") -> None:
        """Operator control: disengage the emergency kill switch (explicit)."""
        self.kill_switch.release(reason)
        logger.info("kill_switch_released", reason=reason)

    def kill_switch_status(self) -> dict:
        return self.kill_switch.snapshot()

    async def expire_stale_orders(self) -> List[str]:
        expired_ids = []
        now = datetime.now(timezone.utc)
        
        ttl = getattr(self.settings, "ORDER_TTL_SECONDS", 300)
        try:
            ttl_seconds = float(ttl)
            if ttl_seconds <= 0 or math.isnan(ttl_seconds):
                raise ValueError
        except (ValueError, TypeError):
            logger.warning("invalid_order_ttl", ttl=ttl)
            return []

        for client_id, record in list(self._pending_orders.items()):
            age = (now - record.created_timestamp).total_seconds()
            if age >= ttl_seconds:
                del self._pending_orders[client_id]
                expired_ids.append(client_id)
                
                if record.dedup_key:
                    async with self._dedup_lock:
                        self._dedup_keys.discard(record.dedup_key)
                
                expired_result = OrderResult(
                    client_order_id=client_id,
                    exchange_order_id="",
                    symbol=record.symbol,
                    side=record.side,
                    order_type=OrderType.LIMIT,
                    status=OrderStatus.EXPIRED,
                    requested_quantity=0.0,
                    message="Order expired due to TTL"
                )
                
                mode_str = "DRY_RUN" if self.settings.TRADING_MODE == TradingMode.DRY_RUN else "LIVE"
                await self._persist_order(expired_result, mode=mode_str, sl=None, tp=None)
                logger.info("order_expired", client_order_id=client_id, symbol=record.symbol, age=age)
                
        return expired_ids

    def _update_position_from_fill(self, fill: OrderResult, stop_loss: Optional[float], take_profit: Optional[float], leverage: int = 1) -> None:
        sym = fill.symbol.upper()
        self._positions[sym] = Position(
            symbol=sym,
            exchange="BINANCE",
            side=fill.side,
            quantity=fill.executed_quantity,
            entry_price=fill.avg_fill_price,
            mark_price=fill.avg_fill_price,
            stop_loss=stop_loss,
            take_profit=take_profit,
            leverage=leverage,
            unrealized_pnl=0.0,
            realized_pnl=0.0,
        )

    async def submit_from_signal(self, signal: TradeSignal, risk_check: RiskCheckResult) -> Optional[OrderResult]:
        if not risk_check.approved or risk_check.approved_quantity <= 0:
            return None

        if not _is_valid_leverage(risk_check.effective_leverage):
            logger.error("risk_veto_invalid_leverage", leverage=risk_check.effective_leverage, symbol=signal.symbol)
            return None

        order_side = OrderSide.BUY if signal.direction.value == "LONG" else OrderSide.SELL
        order_price = (signal.entry_min + signal.entry_max) / 2.0

        sym = signal.symbol.upper()
        setup_name = (signal.setup_name or "").strip()
        dedup_key = f"{sym}:{order_side.value}:{setup_name}" if setup_name else None
        if dedup_key is None:
            logger.error(
                "duplicate_identity_unavailable_fail_closed",
                symbol=sym,
                side=order_side.value,
            )
            return None

        request = OrderRequest(
            symbol=signal.symbol,
            exchange=signal.exchange,
            side=order_side,
            order_type=OrderType.LIMIT,
            quantity=risk_check.approved_quantity,
            price=order_price,
            stop_loss=signal.stop_loss,
            take_profit=signal.take_profit,
            leverage=risk_check.effective_leverage,
            dedup_key=dedup_key,
        )

        res = await self.execute_order(request)
        if res and res.status in (OrderStatus.FILLED, OrderStatus.SUBMITTED):
            self._position_metadata[signal.symbol.upper()] = {
                "setup_name": signal.setup_name,
                "confluence_reasons": signal.reasons,
                "entry_time": datetime.now(timezone.utc),
                "initial_risk": abs(order_price - signal.stop_loss) if signal.stop_loss else 1.0,
            }
            await self.notifier.send_alert(
                title=f"ENTRY EXECUTED: {signal.symbol} ({signal.direction.value})",
                message=f"Setup: `{signal.setup_name}`\nPrice: `{res.avg_fill_price}`\nQty: `{res.executed_quantity}`\nSL: `{signal.stop_loss}` | TP: `{signal.take_profit}`\nRR: `{signal.risk_reward_ratio}`",
                level="FILL"
            )
        return res

    async def on_mark_price_tick(self, symbol: str, mark_price: float) -> None:
        sym = symbol.upper()
        pos = self._positions.get(sym)
        if not pos:
            return

        if pos.side == OrderSide.BUY:
            new_pnl = round((mark_price - pos.entry_price) * pos.quantity, 4)
        else:
            new_pnl = round((pos.entry_price - mark_price) * pos.quantity, 4)

        new_sl = pos.stop_loss

        if pos.stop_loss is not None:
            initial_risk = abs(pos.entry_price - pos.stop_loss)
            if pos.side == OrderSide.BUY:
                if (mark_price >= pos.entry_price + initial_risk) and (pos.stop_loss < pos.entry_price):
                    new_sl = pos.entry_price
                    await self.notifier.send_alert(
                        title=f"BREAKEVEN ACTIVATED: {sym}",
                        message=f"Profit hit +1R. Stop-Loss adjusted to Entry: `{new_sl}`.",
                        level="INFO"
                    )
            elif pos.side == OrderSide.SELL:
                if (mark_price <= pos.entry_price - initial_risk) and (pos.stop_loss > pos.entry_price):
                    new_sl = pos.entry_price
                    await self.notifier.send_alert(
                        title=f"BREAKEVEN ACTIVATED: {sym}",
                        message=f"Profit hit +1R. Stop-Loss adjusted to Entry: `{new_sl}`.",
                        level="INFO"
                    )

        updated_pos = pos.model_copy(update={
            "mark_price": mark_price,
            "unrealized_pnl": new_pnl,
            "stop_loss": new_sl,
        })
        self._positions[sym] = updated_pos

        if updated_pos.stop_loss is not None:
            hit_sl = (mark_price <= updated_pos.stop_loss) if updated_pos.side == OrderSide.BUY else (mark_price >= updated_pos.stop_loss)
            if hit_sl:
                await self.close_position(sym, mark_price, reason="STOP_LOSS")
                return

        if updated_pos.take_profit is not None:
            hit_tp = (mark_price >= updated_pos.take_profit) if updated_pos.side == OrderSide.BUY else (mark_price <= updated_pos.take_profit)
            if hit_tp:
                await self.close_position(sym, mark_price, reason="TAKE_PROFIT")
                return

        await self.redis.set(f"apex:position:{sym}", updated_pos.model_dump_json(), ex=86400)

    async def close_position(self, symbol: str, exit_price: float, reason: str = "MANUAL") -> Optional[OrderResult]:
        sym = symbol.upper()
        pos = self._positions.get(sym)
        if not pos:
            return None

        close_side = OrderSide.SELL if pos.side == OrderSide.BUY else OrderSide.BUY
        request = OrderRequest(
            symbol=sym,
            exchange=pos.exchange,
            side=close_side,
            order_type=OrderType.MARKET,
            quantity=pos.quantity,
            price=exit_price,
            reduce_only=True,
        )

        result = await self.execute_order(request)

        # The kill switch is a HARD execution halt: if the close order was
        # vetoed (e.g. KILL_SWITCH rejection), NO position state may change and
        # no realized PnL may be journaled. A rejected/blocked close leaves the
        # open position fully intact (fail closed).
        if result is None or result.status not in (OrderStatus.FILLED, OrderStatus.SUBMITTED):
            logger.warning("close_position_order_not_filled", symbol=sym, status=getattr(result, "status", None), reason=reason)
            return result

        price_delta = exit_price - pos.entry_price if pos.side == OrderSide.BUY else pos.entry_price - exit_price
        realized = round(price_delta * pos.quantity, 4)

        if self._on_realized_pnl:
            self._on_realized_pnl(realized)

        meta = self._position_metadata.pop(sym, {})
        initial_risk = meta.get("initial_risk", 1.0)
        risk_reward_achieved = round(abs(price_delta) / initial_risk, 2) if initial_risk > 0 else 0.0

        journal_entry = TradeJournalEntry(
            client_order_id=result.client_order_id,
            symbol=sym,
            direction=pos.side.value,
            setup_name=meta.get("setup_name", "DISCRETIONARY_OR_MANUAL"),
            entry_price=pos.entry_price,
            exit_price=exit_price,
            quantity=pos.quantity,
            realized_pnl=realized,
            risk_reward_achieved=risk_reward_achieved,
            exit_reason=reason,
            confluence_reasons=meta.get("confluence_reasons", [f"Closed via {reason}"]),
            entry_time=meta.get("entry_time", datetime.now(timezone.utc)),
            exit_time=datetime.now(timezone.utc),
        )
        await self.journal_dispatcher.record_trade(journal_entry)

        alert_level = "PROFIT" if realized > 0 else "STOP"
        await self.notifier.send_alert(
            title=f"POSITION CLOSED: {sym} ({reason})",
            message=f"Direction: `{pos.side.value}`\nEntry: `{pos.entry_price}` | Exit: `{exit_price}`\nRealized PnL: `${realized:.2f}`\nR:R: `{risk_reward_achieved}R`",
            level=alert_level
        )

        del self._positions[sym]
        await self.redis.delete(f"apex:position:{sym}")

        async with self._dedup_lock:
            self._dedup_keys.discard(f"{sym}:{pos.side.value}:{meta.get('setup_name', '')}")

        logger.info("position_closed_and_realized", symbol=sym, realized_pnl=realized, reason=reason)
        return result
