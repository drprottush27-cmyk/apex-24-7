import pytest
from core.models.signal import TradeSignal, SignalDirection
from engines.risk.guardian import RiskGuardian


def test_risk_guardian_kill_switch_triggers():
    guardian = RiskGuardian()
    signal = TradeSignal(
        symbol="BTCUSDT",
        timeframe="15m",
        direction=SignalDirection.LONG,
        setup_name="TEST_SETUP",
        entry_min=60000.0,
        entry_max=60000.0,
        stop_loss=59000.0,
        take_profit=62500.0,
        risk_reward_ratio=2.5,
        confidence=0.9,
        confluence_score=90.0,
        regime="TRENDING_BULL"
    )

    # Breaching daily drawdown (-3.5% vs -3.0% threshold)
    result = guardian.evaluate_order(
        signal=signal,
        portfolio_equity=10000.0,
        daily_pnl_pct=-0.035,
        open_positions_count=0
    )

    assert result.approved is False
    assert "DAILY_DRAWDOWN_BREACH" in result.checks_failed


def test_risk_guardian_position_limit():
    guardian = RiskGuardian()
    signal = TradeSignal(
        symbol="BTCUSDT",
        timeframe="15m",
        direction=SignalDirection.LONG,
        setup_name="TEST_SETUP",
        entry_min=60000.0,
        entry_max=60000.0,
        stop_loss=59000.0,
        take_profit=62500.0,
        risk_reward_ratio=2.5,
        confidence=0.9,
        confluence_score=90.0,
        regime="TRENDING_BULL"
    )

    # 3 positions already active under Conservative mode
    result = guardian.evaluate_order(
        signal=signal,
        portfolio_equity=10000.0,
        daily_pnl_pct=0.01,
        open_positions_count=3
    )

    assert result.approved is False
    assert "MAX_POSITIONS_REACHED" in result.checks_failed


def test_risk_guardian_sizing_and_leverage_clamp():
    guardian = RiskGuardian()
    signal = TradeSignal(
        symbol="BTCUSDT",
        timeframe="15m",
        direction=SignalDirection.LONG,
        setup_name="TEST_SETUP",
        entry_min=60000.0,
        entry_max=60000.0,
        stop_loss=59400.0,  # 600 USD stop distance (1%)
        take_profit=61500.0,
        risk_reward_ratio=2.5,
        confidence=0.9,
        confluence_score=90.0,
        regime="TRENDING_BULL"
    )

    # Account equity: $10,000 | 1% risk = $100 | Qty = 100 / 600 = 0.1667 BTC
    result = guardian.evaluate_order(
        signal=signal,
        portfolio_equity=10000.0,
        daily_pnl_pct=0.005,
        open_positions_count=1
    )

    assert result.approved is True
    assert result.approved_quantity > 0
    assert result.effective_leverage <= 5
