"""Focused tests for the P2-14 emergency kill switch.

The kill switch must be a REAL execution-path veto: once engaged, every order
attempt through the single execution boundary (``execute_order``) is rejected —
whether it comes from the trading orchestrator, an agent, a provider, or a
direct caller, including reduce-only protective closes and DRY_RUN (simulated)
orders.

These tests run in DRY_RUN (default) mode, so fills are simulated and no network
or exchange is touched. They verify the fail-closed gate by driving the actual
execution path.
"""

import pytest

from core.models.order import (
    OrderRequest,
    OrderSide,
    OrderType,
    OrderStatus,
)
from execution.order_manager import OrderExecutionManager
from execution.safety.kill_switch import KillSwitch, KillSwitchEngaged


@pytest.fixture
def manager():
    return OrderExecutionManager()


# --------------------------------------------------------------------------- unit
class TestKillSwitchUnit:
    def test_default_not_halted(self):
        k = KillSwitch()
        assert k.is_halted is False
        assert k.is_engaged() is False
        assert k.current_halt() is None
        assert k.reason == ""

    def test_halt_engages_and_records_reason(self):
        k = KillSwitch()
        reason = k.halt("market crash")
        assert k.is_halted is True
        assert k.is_engaged() is True
        assert k.current_halt() == "market crash"
        assert k.reason == "market crash"
        assert k.halted_at is not None

    def test_halt_with_empty_reason_uses_default(self):
        k = KillSwitch()
        reason = k.halt("")
        assert k.is_engaged() is True
        assert reason == "MANUAL_EMERGENCY_HALT"

    def test_release_disengages(self):
        k = KillSwitch()
        k.halt("crash")
        k.release("resolved")
        assert k.is_engaged() is False
        assert k.current_halt() is None
        assert k.reason == ""

    def test_no_auto_release(self):
        k = KillSwitch()
        k.halt("crash")
        assert k.is_engaged() is True  # never auto-clears

    def test_assert_can_execute_raises_when_engaged(self):
        k = KillSwitch()
        assert k.assert_can_execute("order") == ""  # clean -> no reason
        k.halt("emergency")
        with pytest.raises(KillSwitchEngaged):
            k.assert_can_execute("order123")

    def test_snapshot_serializable_no_secrets(self):
        k = KillSwitch()
        k.halt("operator")
        snap = k.snapshot()
        assert snap["halted"] is True
        assert snap["reason"] == "operator"
        assert isinstance(snap["halted_at"], str) or snap["halted_at"] is None


# ------------------------------------------------------------------- integration
class TestKillSwitchExecutionVeto:
    @pytest.mark.asyncio
    async def test_dry_run_fills_when_not_halted(self, manager):
        """Baseline: with the switch NOT engaged, normal execution still works
        (DRY_RUN simulation fills)."""
        req = OrderRequest(
            symbol="BTCUSDT", side=OrderSide.BUY, order_type=OrderType.LIMIT,
            quantity=0.05, price=65000.0, stop_loss=64000.0, take_profit=67500.0,
        )
        res = await manager.execute_order(req)
        assert res.status == OrderStatus.FILLED

    @pytest.mark.asyncio
    async def test_direct_execute_rejected_when_halted(self, manager):
        """The REAL guard: engaging the kill switch blocks a direct
        execute_order() call (the single execution funnel)."""
        await manager.kill_switch_halt("total halt")
        req = OrderRequest(
            symbol="BTCUSDT", side=OrderSide.BUY, order_type=OrderType.LIMIT,
            quantity=0.05, price=65000.0,
        )
        res = await manager.execute_order(req)
        assert res.status == OrderStatus.REJECTED
        assert res.executed_quantity == 0.0
        assert "KILL_SWITCH" in (res.message or "")
        assert manager.get_position("BTCUSDT") is None

    @pytest.mark.asyncio
    async def test_dry_run_not_bypassed_when_halted(self, manager):
        """Even DRY_RUN (simulated) execution is vetoed: no fill, no position."""
        await manager.kill_switch_halt("halt during dry run")
        req = OrderRequest(
            symbol="BTCUSDT", side=OrderSide.BUY, order_type=OrderType.LIMIT,
            quantity=0.05, price=65000.0, stop_loss=64000.0, take_profit=67500.0,
        )
        res = await manager.execute_order(req)
        assert res.status == OrderStatus.REJECTED
        assert manager.get_position("BTCUSDT") is None

    @pytest.mark.asyncio
    async def test_signal_submission_bypass_blocked(self, manager):
        """A signal-driven submission (the orchestrator's path) is vetoed."""
        await manager.kill_switch_halt("signal halt")
        from core.models.signal import TradeSignal, SignalDirection
        from engines.risk.guardian import RiskGuardian, RiskCheckResult
        from execution.adapters.binance.exchange_info import BinanceExchangeFilterCache

        signal = TradeSignal(
            symbol="BTCUSDT",
            exchange="BINANCE",
            timeframe="15m",
            direction=SignalDirection.LONG,
            setup_name="MTF_SNIPER",
            entry_min=65000.0,
            entry_max=65500.0,
            stop_loss=64000.0,
            take_profit=67500.0,
            risk_reward_ratio=2.5,
            confidence=0.9,
            confluence_score=70.0,
            regime="TRENDING",
            reasons=[],
        )
        risk_check = RiskCheckResult(
            approved=True,
            reason="approved",
            approved_quantity=0.05,
            effective_leverage=5,
            checks_passed=["ALL"],
        )
        res = await manager.submit_from_signal(signal, risk_check)
        # Fail closed: no order placed, returns no fill result (None) because the
        # underlying execute_order rejected — OR a rejected OrderResult. Either
        # way no position is opened.
        assert manager.get_position("BTCUSDT") is None

    @pytest.mark.asyncio
    async def test_reduce_only_close_blocked_when_halted(self, manager):
        """Even a reduce-only protective close is vetoed while the kill switch
        is engaged (the operator has commanded a full execution halt)."""
        # Open a position (switch not engaged).
        open_req = OrderRequest(
            symbol="BTCUSDT", side=OrderSide.BUY, order_type=OrderType.LIMIT,
            quantity=0.1, price=60000.0, stop_loss=59000.0, take_profit=63000.0,
        )
        await manager.execute_order(open_req)
        assert manager.get_position("BTCUSDT") is not None

        # Engage the switch, then attempt to close (reduce-only path).
        await manager.kill_switch_halt("halt before close")
        close_res = await manager.close_position("BTCUSDT", exit_price=61000.0)
        assert close_res is not None
        assert close_res.status == OrderStatus.REJECTED
        assert "KILL_SWITCH" in (close_res.message or "")
        # The position is NOT closed by the blocked order.
        assert manager.get_position("BTCUSDT") is not None

    @pytest.mark.asyncio
    async def test_release_reenables_execution(self, manager):
        """Explicitly releasing the kill switch resumes normal execution."""
        await manager.kill_switch_halt("temp halt")
        blocked = OrderRequest(
            symbol="BTCUSDT", side=OrderSide.BUY, order_type=OrderType.LIMIT,
            quantity=0.05, price=65000.0,
        )
        assert (await manager.execute_order(blocked)).status == OrderStatus.REJECTED

        manager.kill_switch_release("resolved")
        assert manager.kill_switch.is_engaged() is False
        res = await manager.execute_order(blocked)
        assert res.status == OrderStatus.FILLED

    @pytest.mark.asyncio
    async def test_halt_state_authoritative_no_reset(self, manager):
        """Once engaged, the halt persists across multiple blocked attempts and
        is never silently cleared."""
        await manager.kill_switch_halt("persistent")
        for _ in range(3):
            req = OrderRequest(
                symbol="BTCUSDT", side=OrderSide.BUY, order_type=OrderType.LIMIT,
                quantity=0.05, price=65000.0,
            )
            res = await manager.execute_order(req)
            assert res.status == OrderStatus.REJECTED
        assert manager.kill_switch.is_engaged() is True

    @pytest.mark.asyncio
    async def test_status_endpoint_observability(self, manager):
        """The manager exposes engaged state (halted/reason) for the control
        plane / status endpoint."""
        assert manager.kill_switch_status()["halted"] is False
        await manager.kill_switch_halt("why")
        status = manager.kill_switch_status()
        assert status["halted"] is True
        assert status["reason"] == "why"