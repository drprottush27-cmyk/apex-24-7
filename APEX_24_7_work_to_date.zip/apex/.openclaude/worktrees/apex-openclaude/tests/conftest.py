import pytest
from infrastructure.postgres.database import engine
from infrastructure.redis.client import close_redis


@pytest.fixture(autouse=True)
async def cleanup_database_and_redis():
    yield
    await engine.dispose()
    await close_redis()
