from fastapi import APIRouter
from infrastructure.postgres.database import check_postgres_health
from infrastructure.redis.client import check_redis_health

router = APIRouter(tags=["System Telemetry"])


@router.get("/health")
async def get_system_health():
    pg_ok = await check_postgres_health()
    redis_ok = await check_redis_health()
    status = "HEALTHY" if (pg_ok and redis_ok) else "DEGRADED"

    return {
        "status": status,
        "services": {
            "postgres": "UP" if pg_ok else "DOWN",
            "redis": "UP" if redis_ok else "DOWN",
        }
    }
