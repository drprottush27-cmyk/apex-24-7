from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel
from typing import Dict, Any, List
from datetime import datetime, timezone
from sqlalchemy import select, desc

from core.models.schema import Order as DBOrder, AuditLog, TradeJournal
from infrastructure.postgres.database import AsyncSessionLocal
from engines.indicators import TechnicalIndicators
from engines.scanner.market_scanner import MarketScannerEngine

router = APIRouter(prefix="/api/v1", tags=["Desk Controls & Telemetry"])


class KillSwitchRequest(BaseModel):
    reason: str
    confirm: bool


class TrackRequest(BaseModel):
    symbols: List[str]


class ExecutionModeRequest(BaseModel):
    active: bool


class ShutdownRequest(BaseModel):
    reason: str
    confirm: bool


@router.get("/orders")
async def get_recent_orders(limit: int = 50):
    async with AsyncSessionLocal() as session:
        stmt = select(DBOrder).order_by(desc(DBOrder.created_at)).limit(limit)
        orders = (await session.execute(stmt)).scalars().all()
        return [
            {
                "client_order_id": o.client_order_id,
                "symbol": o.symbol,
                "side": o.side,
                "order_type": o.order_type,
                "quantity": float(o.quantity),
                "price": float(o.price) if o.price else None,
                "status": o.status,
                "mode": o.mode,
                "created_at": o.created_at.isoformat() if o.created_at else None,
            }
            for o in orders
        ]


@router.get("/history")
async def get_trade_history(limit: int = 30):
    async with AsyncSessionLocal() as session:
        stmt = select(TradeJournal).order_by(desc(TradeJournal.exit_time)).limit(limit)
        records = (await session.execute(stmt)).scalars().all()

        total_trades = len(records)
        wins = sum(1 for r in records if float(r.realized_pnl) > 0)
        losses = sum(1 for r in records if float(r.realized_pnl) < 0)
        net_pnl = round(sum(float(r.realized_pnl) for r in records), 2)
        win_rate = round((wins / total_trades * 100.0), 1) if total_trades > 0 else 0.0

        trades_list = [
            {
                "id": r.id,
                "symbol": r.symbol,
                "direction": r.direction,
                "setup_name": r.setup_name,
                "entry_price": float(r.entry_price),
                "exit_price": float(r.exit_price),
                "quantity": float(r.quantity),
                "realized_pnl": float(r.realized_pnl),
                "rr": float(r.risk_reward_achieved),
                "exit_reason": r.exit_reason,
                "exit_time": r.exit_time.strftime("%H:%M:%S UTC") if r.exit_time else "",
            }
            for r in records
        ]

        return {
            "analytics": {
                "total_pnl": net_pnl,
                "win_rate_pct": win_rate,
                "total_trades": total_trades,
                "wins": wins,
                "losses": losses,
            },
            "trades": trades_list
        }


@router.get("/audit-logs")
async def get_audit_logs(limit: int = 25):
    async with AsyncSessionLocal() as session:
        stmt = select(AuditLog).order_by(desc(AuditLog.created_at)).limit(limit)
        logs = (await session.execute(stmt)).scalars().all()
        return [
            {
                "id": l.id,
                "event_type": l.event_type,
                "service": l.service,
                "severity": l.severity,
                "details": l.details,
                "created_at": l.created_at.strftime("%H:%M:%S") if l.created_at else "",
            }
            for l in logs
        ]


@router.get("/mtf-status")
async def get_mtf_status(request: Request):
    orchestrator = getattr(request.app.state, "orchestrator", None)
    if not orchestrator:
        raise HTTPException(status_code=503, detail="Orchestrator not initialized")

    status = {}
    for sym in orchestrator.symbols:
        c_15m = orchestrator._candle_buffers.get(f"{sym}:15m", [])
        c_1h = orchestrator._candle_buffers.get(f"{sym}:1h", [])
        c_4h = orchestrator._candle_buffers.get(f"{sym}:4h", [])

        bias_4h = orchestrator.mtf_engine.evaluate_4h_bias(c_4h).value if len(c_4h) >= 50 else "BUFFERING"
        bias_1h = orchestrator.mtf_engine.evaluate_1h_momentum(c_1h).value if len(c_1h) >= 30 else "BUFFERING"

        closes_15m = [c.close for c in c_15m]
        highs_15m = [c.high for c in c_15m]
        lows_15m = [c.low for c in c_15m]
        volumes_15m = [c.volume for c in c_15m]

        if len(closes_15m) >= 25:
            regime = orchestrator.mtf_engine.regime_classifier.classify(highs_15m, lows_15m, closes_15m).value
            rvol = round(TechnicalIndicators.calculate_rvol(volumes_15m, 20), 2)
            rsi = round(TechnicalIndicators.calculate_rsi(closes_15m, 14)[-1], 1) if len(closes_15m) > 14 else None
            price = closes_15m[-1]
        else:
            regime, rvol, rsi, price = "BUFFERING", None, None, None

        status[sym] = {
            "price": price,
            "bias_4h": bias_4h,
            "bias_1h": bias_1h,
            "regime_15m": regime,
            "rvol_15m": rvol,
            "rsi_15m": rsi,
            "buffers": {"15m": len(c_15m), "1h": len(c_1h), "4h": len(c_4h)}
        }

    return status


@router.get("/positions")
async def get_active_positions(request: Request):
    orchestrator = getattr(request.app.state, "orchestrator", None)
    if not orchestrator:
        raise HTTPException(status_code=503, detail="Orchestrator not initialized")

    positions = orchestrator.order_manager.get_all_positions()
    return [
        {
            "symbol": p.symbol,
            "side": p.side.value,
            "quantity": p.quantity,
            "entry_price": p.entry_price,
            "mark_price": p.mark_price,
            "stop_loss": p.stop_loss,
            "take_profit": p.take_profit,
            "unrealized_pnl": p.unrealized_pnl,
            "leverage": p.leverage,
        }
        for p in positions
    ]


@router.get("/scanner")
async def get_market_scan(category: str = "ALL", limit: int = 25, refresh: bool = False):
    try:
        scanner = MarketScannerEngine()
        results = await scanner.scan_market(category=category, limit=limit, force_refresh=refresh)
        return {
            "status": "SUCCESS",
            "category": category,
            "candidates_count": len(results),
            "data": results
        }
    except Exception as e:
        return {
            "status": "FAILED",
            "candidates_count": 0,
            "error": str(e),
            "data": []
        }


@router.post("/track")
async def track_symbols(payload: TrackRequest, request: Request):
    orchestrator = getattr(request.app.state, "orchestrator", None)
    if not orchestrator:
        raise HTTPException(status_code=503, detail="Orchestrator not initialized")

    active = await orchestrator.update_tracked_symbols(payload.symbols)
    return {
        "status": "UPDATED",
        "tracked_symbols": active,
        "count": len(active)
    }


@router.get("/mode")
async def get_execution_mode(request: Request):
    orchestrator = getattr(request.app.state, "orchestrator", None)
    if not orchestrator:
        raise HTTPException(status_code=503, detail="Orchestrator not initialized")
    return {
        "auto_execution_active": orchestrator.auto_execution_active,
        "mode": "ACTIVE" if orchestrator.auto_execution_active else "MONITOR_ONLY"
    }


@router.post("/mode")
async def toggle_execution_mode(payload: ExecutionModeRequest, request: Request):
    orchestrator = getattr(request.app.state, "orchestrator", None)
    if not orchestrator:
        raise HTTPException(status_code=503, detail="Orchestrator not initialized")

    state = await orchestrator.set_execution_mode(payload.active)
    return {
        "status": "SUCCESS",
        "auto_execution_active": state,
        "mode": "ACTIVE" if state else "MONITOR_ONLY"
    }


@router.post("/kill-switch")
async def trigger_kill_switch(payload: KillSwitchRequest, request: Request):
    if not payload.confirm:
        raise HTTPException(status_code=400, detail="Explicit confirmation required.")

    # The emergency kill switch MUST actually halt execution: engage the
    # fail-closed execution-path veto on the order manager so every later order
    # attempt is rejected (P2-14). The endpoint no longer merely writes an audit
    # log — it drives the real veto.
    orchestrator = getattr(request.app.state, "orchestrator", None)
    manager = getattr(orchestrator, "order_manager", None) if orchestrator else None
    if manager is None:
        raise HTTPException(status_code=503, detail="Order manager not initialized")

    reason = await manager.kill_switch_halt(payload.reason or "OPERATOR_EMERGENCY_HALT")
    return {"status": "HALTED", "reason": reason,
            "message": f"Trading halted: {reason}. All execution paths are vetoed until explicitly released."}


@router.post("/kill-switch/release")
async def release_kill_switch(payload: KillSwitchRequest, request: Request):
    if not payload.confirm:
        raise HTTPException(status_code=400, detail="Explicit confirmation required.")

    orchestrator = getattr(request.app.state, "orchestrator", None)
    manager = getattr(orchestrator, "order_manager", None) if orchestrator else None
    if manager is None:
        raise HTTPException(status_code=503, detail="Order manager not initialized")

    manager.kill_switch_release(payload.reason or "")
    return {"status": "RUNNING", "message": "Kill switch released; execution re-enabled."}


@router.get("/kill-switch/status")
async def get_kill_switch_status(request: Request):
    orchestrator = getattr(request.app.state, "orchestrator", None)
    manager = getattr(orchestrator, "order_manager", None) if orchestrator else None
    if manager is None:
        raise HTTPException(status_code=503, detail="Order manager not initialized")
    return {"status": "HALTED" if manager.kill_switch_status()["halted"] else "RUNNING",
            "kill_switch": manager.kill_switch_status()}


# -----------------------------------------------------------------------
# Graceful Shutdown (P2-15)
# -----------------------------------------------------------------------

@router.post("/shutdown")
async def trigger_graceful_shutdown(payload: ShutdownRequest, request: Request):
    if not payload.confirm:
        raise HTTPException(status_code=400, detail="Explicit confirmation required.")

    shutdown = getattr(request.app.state, "shutdown", None)
    if shutdown is None:
        raise HTTPException(status_code=503, detail="Graceful shutdown not initialized")

    if shutdown.is_done:
        return {
            "status": shutdown.snapshot()["phase"],
            "shutdown": shutdown.snapshot(),
            "message": "Shutdown already completed.",
        }

    snapshot = await shutdown.run(reason=payload.reason or "OPERATOR_SHUTDOWN")
    return {
        "status": snapshot["phase"],
        "shutdown": snapshot,
        "message": "Graceful shutdown sequence completed." if snapshot["phase"] == "COMPLETED"
                   else "Graceful shutdown completed with errors.",
    }


@router.get("/shutdown/status")
async def get_shutdown_status(request: Request):
    shutdown = getattr(request.app.state, "shutdown", None)
    if shutdown is None:
        raise HTTPException(status_code=503, detail="Graceful shutdown not initialized")
    return {"shutdown": shutdown.snapshot()}
