import os
from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse

from core.security.auth import api_key_auth_middleware

from core.config.settings import get_settings
from api.routes.health import router as health_router
from api.routes.controls import router as controls_router
from core.orchestrator import TradingOrchestrator
from core.logging.logger import logger
from execution.safety.graceful_shutdown import GracefulShutdown

settings = get_settings()
app_title = getattr(settings, "PROJECT_NAME", getattr(settings, "APP_NAME", "Apex Trading Desk"))
WEBAPP_INDEX = Path(__file__).resolve().parent.parent / "webapp" / "index.html"

SHUTDOWN_TIMEOUT = float(getattr(settings, "SHUTDOWN_TIMEOUT_SECONDS", 10))


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("launching_apex_desk_orchestrator")
    orchestrator = TradingOrchestrator(
        symbols=["BTCUSDT", "ETHUSDT", "SOLUSDT"],
        timeframes=["15m", "1h", "4h"]
    )
    await orchestrator.initialize()
    orchestrator.start()
    app.state.orchestrator = orchestrator
    app.state.shutdown = GracefulShutdown(
        order_manager=orchestrator.order_manager,
        orchestrator=orchestrator,
        timeout=SHUTDOWN_TIMEOUT,
    )

    yield

    logger.info("graceful_shutdown_lifespan_triggered")
    snapshot = await app.state.shutdown.run(reason="LIFESPAN_SHUTDOWN")
    logger.info("lifespan_shutdown_complete", phase=snapshot.get("phase"))


app = FastAPI(
    title=app_title,
    description="Automated Institutional Quantitative Desk Control Plane",
    version="1.0.0",
    lifespan=lifespan,
)

allowed_origins = [
    o.strip()
    for o in (getattr(settings, "ALLOWED_ORIGINS", "") or "").split(",")
    if o and o.strip()
]

# Restrict CORS (P1-8): cross-origin is only permitted for explicitly
# allowlisted origins, and never via a "*" wildcard. If no origins are
# configured, no cross-origin access is granted (fail closed). Same-origin
# requests (e.g. the /miniapp webapp) are unaffected and need no CORS header.
if allowed_origins and "*" not in allowed_origins:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=allowed_origins,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        allow_headers=["Authorization", "Content-Type"],
    )

app.middleware("http")(api_key_auth_middleware)

app.include_router(health_router)
app.include_router(controls_router)


@app.get("/miniapp")
@app.head("/miniapp")
async def serve_miniapp():
    return FileResponse(WEBAPP_INDEX)

