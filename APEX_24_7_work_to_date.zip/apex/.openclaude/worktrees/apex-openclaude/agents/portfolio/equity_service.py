import math
from typing import Dict, Optional
from dataclasses import dataclass, field
from datetime import date, datetime, timezone

from core.config.settings import get_settings
from core.models.order import Position
from core.logging.logger import logger


@dataclass
class EquitySnapshot:
    total_equity: float
    available_balance: float
    daily_pnl_pct: float


class PortfolioEquityService:
    def __init__(self):
        settings = get_settings()
        self._initial_balance: float = settings.INITIAL_BALANCE
        self._cumulative_realized_pnl: float = 0.0
        self._daily_open_equity: Optional[float] = None
        self._current_date: Optional[date] = None

    def initialize(self) -> None:
        self._cumulative_realized_pnl = 0.0
        self._daily_open_equity = self._initial_balance
        self._current_date = date.today()
        logger.info("equity_service_initialized", initial_balance=self._initial_balance)

    def record_realized_pnl(self, realized_pnl: float) -> None:
        if not math.isfinite(realized_pnl):
            logger.error("equity_invalid_realized_pnl", value=realized_pnl)
            return
        self._cumulative_realized_pnl += realized_pnl

    def get_equity(
        self, open_positions: Optional[Dict[str, Position]] = None
    ) -> EquitySnapshot:
        today = date.today()
        if self._current_date != today:
            self._reset_daily(today)

        equity = self._initial_balance + self._cumulative_realized_pnl

        unrealized = 0.0
        if open_positions:
            for pos in open_positions.values():
                if math.isfinite(pos.unrealized_pnl):
                    unrealized += pos.unrealized_pnl
        equity += unrealized

        equity = self._sanitize(equity)

        if self._daily_open_equity is None:
            self._daily_open_equity = equity

        daily_pnl_pct = self._compute_daily_pnl_pct(equity)

        available = equity
        if open_positions:
            for pos in open_positions.values():
                if math.isfinite(pos.entry_price) and math.isfinite(pos.quantity):
                    margin = pos.entry_price * pos.quantity / max(pos.leverage, 1)
                    available -= margin
        available = self._sanitize(available)

        return EquitySnapshot(
            total_equity=equity,
            available_balance=available,
            daily_pnl_pct=daily_pnl_pct,
        )

    def get_daily_pnl_pct(
        self, open_positions: Optional[Dict[str, Position]] = None
    ) -> float:
        snapshot = self.get_equity(open_positions)
        return snapshot.daily_pnl_pct

    def _compute_daily_pnl_pct(self, current_equity: float) -> float:
        if (
            self._daily_open_equity is None
            or not math.isfinite(self._daily_open_equity)
            or self._daily_open_equity <= 0
        ):
            return 0.0
        return (current_equity - self._daily_open_equity) / self._daily_open_equity

    def _reset_daily(self, today: date) -> None:
        current_equity = self._initial_balance + self._cumulative_realized_pnl
        current_equity = self._sanitize(current_equity)
        self._daily_open_equity = current_equity
        self._current_date = today
        logger.info("equity_daily_reset", date=str(today), open_equity=current_equity)

    @staticmethod
    def _sanitize(value: float) -> float:
        if not isinstance(value, (int, float)) or not math.isfinite(value):
            logger.error("equity_sanitized_invalid", raw_value=str(value))
            return 0.0
        if value < 0:
            logger.warning("equity_sanitized_negative", raw_value=value)
            return 0.0
        return round(value, 8)
