# APEX 24/7 — Autonomous Crypto Intelligence Desk

## Project Architecture
- **apps/**: Entrypoints for API, Dashboard, Scanner, Execution, and Workers.
- **core/**: Central configuration, typed models, structured logging, events, and health registry.
- **engines/**: Deterministic quantitative signal and market regime calculation engines.
- **agents/**: Sandboxed AI reasoning components operating under strict deterministic guardrails.
- **execution/**: Broker adapters, order lifecycle managers, and state reconciliation engines.
- **infrastructure/**: Dockerized persistence (PostgreSQL 16) and event broker (Redis 7).

## Operating Modes
- Default mode: `DRY_RUN`
- Risk mode: `CONSERVATIVE`
- Direct LLM execution authority: `DISABLED` (Veto held by deterministic Risk Guardian)
