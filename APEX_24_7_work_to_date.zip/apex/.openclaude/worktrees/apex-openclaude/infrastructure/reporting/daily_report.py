import asyncio
import os
import sys
from pathlib import Path
from datetime import datetime, timezone, timedelta
from sqlalchemy import select, and_

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from core.models.schema import TradeJournal
from infrastructure.postgres.database import AsyncSessionLocal
from infrastructure.notifications.notifier import NotificationGateway
from core.logging.logger import logger


class DailyPerformanceReporter:
    def __init__(self):
        self.notifier = NotificationGateway()

    async def generate_daily_briefing(self) -> None:
        now = datetime.now(timezone.utc)
        start_of_day = (now - timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
        end_of_day = start_of_day + timedelta(days=1)

        async with AsyncSessionLocal() as session:
            stmt = select(TradeJournal).where(
                and_(
                    TradeJournal.exit_time >= start_of_day,
                    TradeJournal.exit_time < end_of_day
                )
            )
            trades = (await session.execute(stmt)).scalars().all()

        total_trades = len(trades)
        if total_trades == 0:
            msg = (
                f"📋 *APEX DAILY PERFORMANCE BRIEFING*\n"
                f"Date: `{start_of_day.strftime('%Y-%m-%d')}` UTC\n\n"
                f"• Zero trades closed during this window.\n"
                f"• Capital preserved in accordance with Sniper confluence criteria."
            )
            await self.notifier.send_alert("DAILY BRIEFING: NO TRADES", msg, level="INFO")
            return

        wins = [t for t in trades if float(t.realized_pnl) > 0]
        losses = [t for t in trades if float(t.realized_pnl) <= 0]
        total_pnl = sum(float(t.realized_pnl) for t in trades)
        gross_profit = sum(float(t.realized_pnl) for t in wins)
        gross_loss = abs(sum(float(t.realized_pnl) for t in losses))

        win_rate = (len(wins) / total_trades) * 100.0
        profit_factor = (gross_profit / gross_loss) if gross_loss > 0 else (99.9 if gross_profit > 0 else 0.0)
        avg_rr = sum(float(t.risk_reward_achieved) for t in trades) / total_trades

        pnl_symbol = "🟢" if total_pnl >= 0 else "🔴"

        report = (
            f"📊 *APEX EXECUTIVE DAILY REPORT*\n"
            f"Date: `{start_of_day.strftime('%Y-%m-%d')}` UTC\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"{pnl_symbol} *Net Realized PnL:* `${total_pnl:+.2f} USDT`\n"
            f"🎯 *Win Rate:* `{win_rate:.1f}%` ({len(wins)}W / {len(losses)}L)\n"
            f"⚖️ *Profit Factor:* `{profit_factor:.2f}`\n"
            f"📈 *Average R:R:* `{avg_rr:.2f}R`\n"
            f"🔢 *Total Setups Executed:* `{total_trades}`\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"🛡️ *Risk Enforcement:* All positions executed within strict limits."
        )

        await self.notifier.send_alert(
            title=f"DAILY PERFORMANCE: {pnl_symbol} ${total_pnl:+.2f}",
            message=report,
            level="PROFIT" if total_pnl >= 0 else "STOP"
        )
        logger.info("daily_performance_briefing_dispatched", trades=total_trades, net_pnl=total_pnl)


if __name__ == "__main__":
    reporter = DailyPerformanceReporter()
    asyncio.run(reporter.generate_daily_briefing())
