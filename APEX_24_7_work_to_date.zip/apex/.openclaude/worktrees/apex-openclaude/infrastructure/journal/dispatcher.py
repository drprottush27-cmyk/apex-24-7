import os
import httpx
from datetime import datetime, timezone
from typing import Optional
from core.logging.logger import logger
from core.models.journal import TradeJournalEntry
from core.models.schema import TradeJournal
from infrastructure.postgres.database import AsyncSessionLocal


class JournalDispatcher:
    def __init__(self):
        self.notion_api_key = os.getenv("NOTION_API_KEY", "")
        self.notion_database_id = os.getenv("NOTION_DATABASE_ID", "")

    async def record_trade(self, entry: TradeJournalEntry) -> None:
        # 1. Persist directly to PostgreSQL
        try:
            async with AsyncSessionLocal() as session:
                record = TradeJournal(
                    client_order_id=entry.client_order_id,
                    symbol=entry.symbol,
                    direction=entry.direction,
                    setup_name=entry.setup_name,
                    entry_price=entry.entry_price,
                    exit_price=entry.exit_price,
                    quantity=entry.quantity,
                    realized_pnl=entry.realized_pnl,
                    risk_reward_achieved=entry.risk_reward_achieved,
                    exit_reason=entry.exit_reason,
                    confluence_reasons=entry.confluence_reasons,
                    entry_time=entry.entry_time,
                    exit_time=entry.exit_time,
                )
                session.add(record)
                await session.commit()
                logger.info("trade_journal_persisted_db", symbol=entry.symbol, pnl=entry.realized_pnl)
        except Exception as e:
            logger.error("failed_to_persist_trade_journal", error=str(e))

        # 2. Sync to Notion if credentials exist
        if self.notion_api_key and self.notion_database_id:
            await self._dispatch_to_notion(entry)

    async def _dispatch_to_notion(self, entry: TradeJournalEntry) -> None:
        url = "https://api.notion.com/v1/pages"
        headers = {
            "Authorization": f"Bearer {self.notion_api_key}",
            "Notion-Version": "2022-06-28",
            "Content-Type": "application/json",
        }

        payload = {
            "parent": {"database_id": self.notion_database_id},
            "properties": {
                "Symbol": {"title": [{"text": {"content": entry.symbol}}]},
                "Setup": {"rich_text": [{"text": {"content": entry.setup_name}}]},
                "Direction": {"select": {"name": entry.direction}},
                "Realized PnL": {"number": float(entry.realized_pnl)},
                "R:R": {"number": float(entry.risk_reward_achieved)},
                "Exit Reason": {"select": {"name": entry.exit_reason}},
                "Entry Price": {"number": float(entry.entry_price)},
                "Exit Price": {"number": float(entry.exit_price)},
            }
        }

        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                res = await client.post(url, headers=headers, json=payload)
                if res.status_code in (200, 201):
                    logger.info("notion_journal_synced", symbol=entry.symbol)
                else:
                    logger.warning("notion_sync_failed", status=res.status_code, body=res.text[:120])
        except Exception as e:
            logger.warning("notion_dispatch_error", error=str(e))
