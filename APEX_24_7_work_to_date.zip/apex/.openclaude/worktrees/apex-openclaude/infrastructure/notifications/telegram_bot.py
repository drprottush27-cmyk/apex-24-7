import asyncio
import os
import sys
from pathlib import Path
import httpx

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from core.logging.logger import logger
from engines.agents.ai_auditor import TradingAgentsAuditor


class TelegramBotController:
    def __init__(self):
        self.token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
        self.chat_id = os.getenv("TELEGRAM_CHAT_ID", "").strip()
        self.webapp_url = os.getenv("TELEGRAM_WEBAPP_URL", "").strip()
        self.tg_api = f"https://api.telegram.org/bot{self.token}"
        self.api_base = "http://127.0.0.1:8000/api/v1"
        self.auditor = TradingAgentsAuditor()
        self._running = False

    async def send_message(self, chat_id: str, text: str, reply_markup: dict = None) -> None:
        payload = {
            "chat_id": chat_id,
            "text": text,
            "parse_mode": "Markdown",
        }
        if reply_markup:
            payload["reply_markup"] = reply_markup
        async with httpx.AsyncClient(timeout=10.0) as client:
            try:
                await client.post(f"{self.tg_api}/sendMessage", json=payload)
            except Exception as e:
                logger.error("tg_send_message_failed", error=str(e))

    async def answer_callback(self, callback_id: str, text: str = "") -> None:
        async with httpx.AsyncClient(timeout=10.0) as client:
            try:
                await client.post(
                    f"{self.tg_api}/answerCallbackQuery",
                    json={"callback_query_id": callback_id, "text": text},
                )
            except Exception as e:
                logger.error("tg_answer_callback_failed", error=str(e))

    async def send_control_panel(self, chat_id: str) -> None:
        keyboard = {
            "inline_keyboard": [
                [{"text": "📱 Open Mini App HUD", "web_app": {"url": self.webapp_url}}],
                [
                    {"text": "▶️ GO (EXECUTE)", "callback_data": "mode_go"},
                    {"text": "⏸ PAUSE (ALERTS)", "callback_data": "mode_pause"},
                ],
                [
                    {"text": "🔍 SCAN TOP COINS", "callback_data": "scan_coins"},
                    {"text": "📊 DESK STATUS", "callback_data": "desk_status"},
                ],
                [{"text": "🚨 EMERGENCY KILL SWITCH", "callback_data": "kill_switch"}],
            ]
        }
        msg = (
            "⚡ *APEX QUANTITATIVE TRADING DESK*\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "• *Engine:* Binance USDⓈ-M Futures\n"
            "• *Execution:* Multi-Timeframe Sniper\n"
            "• *Risk Limits:* 5x Isolated Max | Ratchet SL\n"
            "• *AI Co-Pilot:* `/audit <SYMBOL>`\n\n"
            "Select a desk control below:"
        )
        await self.send_message(chat_id, msg, reply_markup=keyboard)

    async def handle_audit_command(self, chat_id: str, symbol: str) -> None:
        clean_sym = symbol.upper()
        if not clean_sym.endswith("USDT"):
            clean_sym += "USDT"

        init_msg = (
            f"🧠 *AI AGENT AUDIT INITIATED*\n"
            f"Target: `{clean_sym}`\n\n"
            f"Deploying multi-agent debate (Market, News & Sentiment) via Gemini[span_0](start_span)[span_0](end_span).\n"
            f"Synthesizing analysis (~20-40s)..."
        )
        await self.send_message(chat_id, init_msg)

        try:
            report = await self.auditor.audit_asset(clean_sym)
            decision = report.get("decision", "No decision returned.")
            error = report.get("error")
            if error:
                verdict_msg = (
                    f"⚠️ *AI AGENT AUDIT ENCOUNTERED ISSUE*\n"
                    f"Target: `{clean_sym}`\n\n"
                    f"`{error}`"
                )
            else:
                verdict_msg = (
                    f"📋 *AI AGENT AUDIT VERDICT: {clean_sym}*\n"
                    f"━━━━━━━━━━━━━━━━━━━━\n"
                    f"{decision}\n"
                    f"━━━━━━━━━━━━━━━━━━━━\n"
                    f"*Source:* TradingAgents Multi-Agent Graph[span_1](start_span)[span_1](end_span)"
                )
            await self.send_message(chat_id, verdict_msg)
        except Exception as e:
            logger.error("audit_dispatch_failed", error=str(e))
            await self.send_message(chat_id, f"❌ *Audit Failed:* `{str(e)}`")

    async def handle_callback(self, cq: dict) -> None:
        cb_id = cq.get("id")
        data = cq.get("data")
        chat_id = str(cq.get("message", {}).get("chat", {}).get("id", self.chat_id))

        async with httpx.AsyncClient(timeout=10.0) as client:
            if data == "mode_go":
                await client.post(f"{self.api_base}/mode", json={"active": True})
                await self.answer_callback(cb_id, "Mode switched to ACTIVE (GO)")
                await self.send_message(chat_id, "▶️ *DESK ACTIVATED:* Order auto-execution enabled.")
            elif data == "mode_pause":
                await client.post(f"{self.api_base}/mode", json={"active": False})
                await self.answer_callback(cb_id, "Mode switched to MONITOR ONLY")
                await self.send_message(chat_id, "⏸ *DESK PAUSED:* Switched to monitor-only alert mode.")
            elif data == "desk_status":
                mode_resp = await client.get(f"{self.api_base}/mode")
                pos_resp = await client.get(f"{self.api_base}/positions")
                m_data = mode_resp.json()
                p_data = pos_resp.json()
                status_str = "ACTIVE (GO)" if m_data.get("auto_execution_active") else "MONITOR ONLY"
                msg = (
                    f"📊 *DESK STATUS TELEMETRY*\n"
                    f"• Operational Mode: `{status_str}`\n"
                    f"• Open Positions: `{len(p_data)}`\n"
                    f"• Engine Health: `ONLINE`"
                )
                await self.answer_callback(cb_id, "Status fetched")
                await self.send_message(chat_id, msg)
            elif data == "scan_coins":
                await self.answer_callback(cb_id, "Scanning market...")
                scan_resp = await client.get(f"{self.api_base}/scanner?category=ALL&limit=5")
                res = scan_resp.json()
                candidates = res.get("data", [])
                if not candidates:
                    await self.send_message(chat_id, "🔍 *Market Scan:* No high-confluence candidates at this moment.")
                else:
                    lines = ["🔍 *TOP INSTITUTIONAL CONFLUENCE CANDIDATES:*\n"]
                    for c in candidates[:5]:
                        lines.append(f"• `{c['symbol']}` | 4H: `{c['bias_4h']}` | 1H: `{c['bias_1h']}` | `{c['confluence']}`")
                    await self.send_message(chat_id, "\n".join(lines))
            elif data == "kill_switch":
                await client.post(
                    f"{self.api_base}/kill-switch",
                    json={"reason": "Telegram Emergency Kill Switch Triggered", "confirm": True}
                )
                await self.answer_callback(cb_id, "KILL SWITCH EXECUTED!")
                await self.send_message(chat_id, "🚨 *EMERGENCY KILL SWITCH ENGAGED:* Trading halted immediately.")

    async def poll(self) -> None:
        self._running = True
        offset = 0
        logger.info("telegram_control_bot_polling_started")

        async with httpx.AsyncClient(timeout=30.0) as client:
            while self._running:
                try:
                    resp = await client.get(
                        f"{self.tg_api}/getUpdates",
                        params={"offset": offset, "timeout": 20}
                    )
                    if resp.status_code == 200:
                        updates = resp.json().get("result", [])
                        for up in updates:
                            offset = up["update_id"] + 1

                            if "message" in up:
                                text = up["message"].get("text", "")
                                sender_id = str(up["message"]["chat"]["id"])
                                if text.startswith("/start") or text.startswith("/desk"):
                                    await self.send_control_panel(sender_id)
                                elif text.startswith("/audit"):
                                    parts = text.split()
                                    target_sym = parts[1].upper() if len(parts) > 1 else "BTCUSDT"
                                    asyncio.create_task(self.handle_audit_command(sender_id, target_sym))

                            elif "callback_query" in up:
                                await self.handle_callback(up["callback_query"])
                    await asyncio.sleep(0.5)
                except asyncio.CancelledError:
                    break
                except Exception as e:
                    logger.error("telegram_bot_poll_error", error=str(e))
                    await asyncio.sleep(5.0)

    def stop(self):
        self._running = False


if __name__ == "__main__":
    bot = TelegramBotController()
    try:
        asyncio.run(bot.poll())
    except KeyboardInterrupt:
        bot.stop()
