import os
import httpx
from typing import Optional, List
from core.logging.logger import logger


class NotificationGateway:
    def __init__(self):
        self.bot_token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
        self.chat_id = os.getenv("TELEGRAM_CHAT_ID", "").strip()
        self.webhook_url = os.getenv("DISCORD_WEBHOOK_URL", "").strip()

    async def send_alert(self, title: str, message: str, level: str = "INFO") -> None:
        emoji_map = {
            "INFO": "ℹ️",
            "SIGNAL": "🎯",
            "FILL": "⚡",
            "PROFIT": "💰",
            "STOP": "🛑",
            "WARNING": "⚠️",
            "CRITICAL": "🚨",
        }
        icon = emoji_map.get(level.upper(), "📌")
        formatted_text = f"{icon} *{title}*\n\n{message}"

        # 1. Telegram Dispatch
        if self.bot_token and self.chat_id:
            tg_url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
            payload = {
                "chat_id": self.chat_id,
                "text": formatted_text,
                "parse_mode": "Markdown",
            }
            try:
                async with httpx.AsyncClient(timeout=5.0) as client:
                    resp = await client.post(tg_url, json=payload)
                    if resp.status_code != 200:
                        logger.warning("telegram_alert_dispatch_failed", status=resp.status_code, body=resp.text[:120])
            except Exception as e:
                logger.warning("telegram_alert_network_error", error=str(e))

        # 2. Discord / General Webhook Dispatch
        if self.webhook_url:
            discord_payload = {"content": f"**{icon} {title}**\n{message}"}
            try:
                async with httpx.AsyncClient(timeout=5.0) as client:
                    await client.post(self.webhook_url, json=discord_payload)
            except Exception as e:
                logger.warning("webhook_alert_network_error", error=str(e))

        logger.info("notification_dispatched", title=title, level=level)
