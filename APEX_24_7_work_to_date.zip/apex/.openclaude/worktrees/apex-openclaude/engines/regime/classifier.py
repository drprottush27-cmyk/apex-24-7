from enum import Enum
from typing import List
from engines.indicators import TechnicalIndicators


class MarketRegime(str, Enum):
    TRENDING_BULL = "TRENDING_BULL"
    TRENDING_BEAR = "TRENDING_BEAR"
    RANGING = "RANGING"
    HIGH_VOLATILITY_EXPANSION = "HIGH_VOLATILITY_EXPANSION"


class RegimeClassifier:
    def __init__(self, ema_fast: int = 20, ema_slow: int = 50, atr_period: int = 14):
        self.ema_fast = ema_fast
        self.ema_slow = ema_slow
        self.atr_period = atr_period

    def classify(self, highs: List[float], lows: List[float], closes: List[float]) -> MarketRegime:
        if len(closes) < self.ema_slow + 5:
            return MarketRegime.RANGING

        ema_f = TechnicalIndicators.calculate_ema(closes, self.ema_fast)
        ema_s = TechnicalIndicators.calculate_ema(closes, self.ema_slow)
        atr_vals = TechnicalIndicators.calculate_atr(highs, lows, closes, self.atr_period)

        current_close = closes[-1]
        curr_ema_f = ema_f[-1]
        curr_ema_s = ema_s[-1]

        if len(atr_vals) >= 20:
            avg_atr = sum(atr_vals[-20:]) / 20
            if atr_vals[-1] > (avg_atr * 1.75):
                return MarketRegime.HIGH_VOLATILITY_EXPANSION

        if curr_ema_f > curr_ema_s and current_close > curr_ema_f:
            return MarketRegime.TRENDING_BULL
        elif curr_ema_f < curr_ema_s and current_close < curr_ema_f:
            return MarketRegime.TRENDING_BEAR

        return MarketRegime.RANGING
