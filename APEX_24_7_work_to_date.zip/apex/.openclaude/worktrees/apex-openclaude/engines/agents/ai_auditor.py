"""AI asset auditor — P2-17 neutralized, fail-closed, advisory-only stub.

Previously this module performed live network calls to Binance Futures public
endpoints and the Google Gemini API, reading an external API credential from
the environment. That violated several safety invariants: live market-data +
external-AI connectivity from agent code, credential access in an
agent/strategy path, non-hermetic behavior, and the ability to produce a
market verdict with no Risk Guardian / Kill Switch / safety gate in its path.

P2-17 rewrites it as a deterministic, hermetic, advisory-only stub:

  * No network calls (no Binance, no Gemini, no HTTP client).
  * No credential access (never reads or uses any API credential).
  * Fail closed: because live market context and live model inference are not
    yet operator-approved, `audit_asset` returns a deterministic `NEUTRAL AVOID`
    advisory verdict. It NEVER fabricates a BULLISH/BEARISH execution mandate.
  * Advisory-only: the returned dict is advisory text; it can never reach any
    order/execution path (no OrderRequest, no adapter, no exchange call).
  * Hermetic and deterministic: safe for unit tests (no network, no secrets).

A future task (requiring explicit human approval for live market data and live
model inference) may integrate a real provider; until then this is the
authoritative safe stub. The `TradingAgentsAuditor` class name and its
`audit_asset(symbol)` interface are preserved so existing importers continue
to work.
"""

from typing import Dict, Any, Optional, Callable, Awaitable


class TradingAgentsAuditor:
    """Deterministic, hermetic, advisory-only asset auditor stub (P2-17).

    The auditor never contacts a network, never reads credentials, and never
    produces an execution signal. When live market/inference context is
    unavailable it fails closed to a `NEUTRAL AVOID` advisory verdict.
    """

    #: Advisory verdict emitted when live context/provider is unavailable.
    NEUTRAL_VERDICT = "NEUTRAL AVOID"

    def __init__(
        self,
        market_context_provider: Optional[Callable[[str], Awaitable[Dict[str, Any]]]] = None,
        decision_provider: Optional[Callable[[Dict[str, Any]], Awaitable[str]]] = None,
    ) -> None:
        """Inject deterministic providers for hermetic testing; default to stub.

        Args:
            market_context_provider: async fn(symbol) -> dict context, or None.
            decision_provider: async fn(context) -> advisory decision str, or None.
        """
        # No credential is read or stored. Live providers are intentionally
        # absent until an operator-approved integration task exists.
        self._market_context_provider = market_context_provider
        self._decision_provider = decision_provider

    async def _fetch_market_context(self, symbol: str) -> Dict[str, Any]:
        """Return deterministic, fail-closed local market context (no network)."""
        if self._market_context_provider is not None:
            try:
                ctx = await self._market_context_provider(symbol)
                if isinstance(ctx, dict):
                    return ctx
            except Exception:
                pass
        # Fail closed: no live market data is available, so no price/volume/
        # funding inputs can be substituted with unsafe defaults.
        return {
            "symbol": symbol,
            "available": False,
            "reason": "live_market_context_unavailable",
        }

    async def _form_decision(self, context: Dict[str, Any]) -> str:
        """Return the advisory decision for the given context.

        Never reaches an order path. If live context is unavailable we fail
        closed to a neutral, non-actionable advisory verdict — never a bullish
        or bearish execution mandate.
        """
        if self._decision_provider is not None:
            try:
                text = await self._decision_provider(context)
                if isinstance(text, str) and text.strip():
                    return text.strip()
            except Exception:
                pass

        available = context.get("available", False)
        if not available:
            return (
                f"{self.NEUTRAL_VERDICT} — critical "
                + "context unavailable; no actionable setup can be assessed."
            )
        return f"{self.NEUTRAL_VERDICT} — advisory analysis unavailable."

    async def audit_asset(self, symbol: str) -> Dict[str, Any]:
        """Produce a deterministic, advisory-only audit for a symbol.

        Returns a dict with keys ``symbol``, ``decision``, ``model``,
        ``advisory_only``, ``live_market_data``, and ``error``. The decision is
        advisory text only and can never be used as an order/execution signal.
        """
        sym = symbol.upper()
        if not sym.endswith("USDT"):
            sym += "USDT"

        context = await self._fetch_market_context(sym)
        decision = await self._form_decision(context)

        return {
            "symbol": sym,
            "decision": decision,
            "model": "deterministic-stub",
            "advisory_only": True,
            "live_market_data": bool(context.get("available", False)),
            "error": None,
        }
