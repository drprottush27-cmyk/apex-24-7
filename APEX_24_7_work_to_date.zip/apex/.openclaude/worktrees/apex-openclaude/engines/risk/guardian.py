import math
from typing import Dict, Any, List, Optional
from pydantic import BaseModel
from core.config.settings import get_settings, RiskMode
from core.models.signal import TradeSignal
from core.logging.logger import logger


def _is_valid_equity(portfolio_equity: Any) -> bool:
    if isinstance(portfolio_equity, bool):
        return False
    if not isinstance(portfolio_equity, (int, float)):
        return False
    if not math.isfinite(portfolio_equity):
        return False
    if portfolio_equity <= 0:
        return False
    return True


class RiskCheckResult(BaseModel):
    approved: bool
    reason: str
    approved_quantity: float = 0.0
    effective_leverage: int = 1
    checks_passed: List[str] = []
    checks_failed: List[str] = []


class RiskGuardian:
    def __init__(self):
        self.settings = get_settings()

    def evaluate_order(
        self,
        signal: TradeSignal,
        portfolio_equity: float,
        daily_pnl_pct: float,
        open_positions_count: int,
    ) -> RiskCheckResult:
        passed = []
        failed = []

        # 0. Portfolio equity must be a valid positive finite value. Invalid or
        # missing equity fails closed — no risk assessment can be performed
        # against a negative, zero, NaN, infinite, or malformed equity value.
        if not _is_valid_equity(portfolio_equity):
            failed.append("INVALID_PORTFOLIO_EQUITY")
            logger.error("risk_veto_invalid_equity", equity=portfolio_equity)
            return RiskCheckResult(
                approved=False,
                reason="Portfolio equity is missing or invalid; risk assessment blocked.",
                checks_failed=failed,
                checks_passed=passed
            )
        passed.append("PORTFOLIO_EQUITY_VALID")

        # 1. Kill switch: Daily Drawdown breach
        if daily_pnl_pct <= -abs(self.settings.DAILY_DRAWDOWN_KILL):
            failed.append("DAILY_DRAWDOWN_BREACH")
            logger.error("risk_veto_daily_drawdown", daily_pnl=daily_pnl_pct, limit=self.settings.DAILY_DRAWDOWN_KILL)
            return RiskCheckResult(
                approved=False,
                reason=f"Circuit Breaker: Daily drawdown {daily_pnl_pct*100:.2f}% breached limit {self.settings.DAILY_DRAWDOWN_KILL*100:.1f}%",
                checks_failed=failed,
                checks_passed=passed
            )
        passed.append("DAILY_DRAWDOWN_SAFE")

        # 2. Max Open Concurrent Positions Check
        max_positions = 3 if self.settings.RISK_MODE == RiskMode.CONSERVATIVE else 5
        if open_positions_count >= max_positions:
            failed.append("MAX_POSITIONS_REACHED")
            return RiskCheckResult(
                approved=False,
                reason=f"Open positions ({open_positions_count}) reached maximum limit ({max_positions})",
                checks_failed=failed,
                checks_passed=passed
            )
        passed.append("CONCURRENT_POSITIONS_SAFE")

        # 3. Risk-Reward Ratio Requirement
        if signal.risk_reward_ratio < 1.8:
            failed.append("SUBPAR_RISK_REWARD")
            return RiskCheckResult(
                approved=False,
                reason=f"Risk/Reward {signal.risk_reward_ratio:.2f} does not meet minimum 1.80 threshold",
                checks_failed=failed,
                checks_passed=passed
            )
        passed.append("RISK_REWARD_ACCEPTABLE")

        # 4. Deterministic Sizing: Max account risk per trade
        risk_per_trade_capital = portfolio_equity * self.settings.RISK_PER_TRADE
        mid_entry = (signal.entry_min + signal.entry_max) / 2.0
        distance_to_stop = abs(mid_entry - signal.stop_loss)

        if distance_to_stop <= 0:
            failed.append("INVALID_STOP_DISTANCE")
            return RiskCheckResult(
                approved=False,
                reason="Invalid stop loss distance of zero",
                checks_failed=failed,
                checks_passed=passed
            )

        calculated_qty = risk_per_trade_capital / distance_to_stop

        # 5. Leverage and Notional Clamping
        max_leverage = min(self.settings.MAX_LEVERAGE, 5)  # Hard non-negotiable ceiling
        max_notional = portfolio_equity * max_leverage
        order_notional = calculated_qty * mid_entry

        if order_notional > max_notional:
            calculated_qty = max_notional / mid_entry
            passed.append("SIZE_CLAMPED_TO_MAX_LEVERAGE")
        else:
            passed.append("SIZE_WITHIN_LEVERAGE_CAP")

        passed.append("POSITION_SIZING_APPROVED")

        return RiskCheckResult(
            approved=True,
            reason="Approved under deterministic risk guidelines",
            approved_quantity=round(calculated_qty, 4),
            effective_leverage=max_leverage,
            checks_passed=passed,
            checks_failed=failed
        )
