import math
from typing import List, Tuple, Optional


class TechnicalIndicators:
    @staticmethod
    def calculate_ema(prices: List[float], period: int) -> List[float]:
        if len(prices) < period:
            return []
        k = 2.0 / (period + 1)
        ema = [sum(prices[:period]) / period]
        for price in prices[period:]:
            ema.append((price * k) + (ema[-1] * (1.0 - k)))
        return ema

    @staticmethod
    def calculate_rsi(prices: List[float], period: int = 14) -> List[float]:
        if len(prices) <= period:
            return []

        gains = []
        losses = []
        for i in range(1, len(prices)):
            diff = prices[i] - prices[i - 1]
            gains.append(max(diff, 0.0))
            losses.append(max(-diff, 0.0))

        if len(gains) < period:
            return []

        avg_gain = sum(gains[:period]) / period
        avg_loss = sum(losses[:period]) / period

        rsi_values = []
        if avg_loss == 0:
            rsi_values.append(100.0)
        else:
            rs = avg_gain / avg_loss
            rsi_values.append(100.0 - (100.0 / (1.0 + rs)))

        for i in range(period, len(gains)):
            avg_gain = ((avg_gain * (period - 1)) + gains[i]) / period
            avg_loss = ((avg_loss * (period - 1)) + losses[i]) / period

            if avg_loss == 0:
                rsi_values.append(100.0)
            else:
                rs = avg_gain / avg_loss
                rsi_values.append(100.0 - (100.0 / (1.0 + rs)))

        return rsi_values

    @staticmethod
    def calculate_atr(highs: List[float], lows: List[float], closes: List[float], period: int = 14) -> List[float]:
        if len(highs) <= period or len(lows) <= period or len(closes) <= period:
            return []

        tr_list = [highs[0] - lows[0]]
        for i in range(1, len(highs)):
            tr = max(
                highs[i] - lows[i],
                abs(highs[i] - closes[i - 1]),
                abs(lows[i] - closes[i - 1])
            )
            tr_list.append(tr)

        atr = [sum(tr_list[:period]) / period]
        for tr in tr_list[period:]:
            atr.append(((atr[-1] * (period - 1)) + tr) / period)

        return atr

    @staticmethod
    def calculate_bollinger_bands(prices: List[float], period: int = 20, std_dev_mult: float = 2.0) -> Tuple[List[float], List[float], List[float]]:
        if len(prices) < period:
            return [], [], []

        middle = []
        upper = []
        lower = []

        for i in range(period, len(prices) + 1):
            window = prices[i - period:i]
            mean = sum(window) / period
            variance = sum((x - mean) ** 2 for x in window) / period
            std_dev = math.sqrt(variance)

            middle.append(mean)
            upper.append(mean + (std_dev_mult * std_dev))
            lower.append(mean - (std_dev_mult * std_dev))

        return upper, middle, lower

    @staticmethod
    def calculate_rvol(volumes: List[float], period: int = 20) -> float:
        if len(volumes) < period + 1:
            return 1.0
        current_vol = volumes[-1]
        avg_vol = sum(volumes[-period - 1:-1]) / period
        return (current_vol / avg_vol) if avg_vol > 0 else 1.0
