from typing import List, Optional
from core.models.market import Candle
from core.models.signal import TradeSignal, SignalDirection
from engines.indicators import TechnicalIndicators
from engines.regime import RegimeClassifier, MarketRegime


class SniperSignalEngine:
    def __init__(self, min_rr: float = 2.0, min_rvol: float = 1.25):
        self.min_rr = min_rr
        self.min_rvol = min_rvol
        self.regime_classifier = RegimeClassifier()

    def evaluate(self, candles: List[Candle]) -> Optional[TradeSignal]:
        if len(candles) < 60:
            return None

        closes = [c.close for c in candles]
        highs = [c.high for c in candles]
        lows = [c.low for c in candles]
        volumes = [c.volume for c in candles]

        regime = self.regime_classifier.classify(highs, lows, closes)
        rvol = TechnicalIndicators.calculate_rvol(volumes, period=20)
        rsi_series = TechnicalIndicators.calculate_rsi(closes, period=14)
        atr_series = TechnicalIndicators.calculate_atr(highs, lows, closes, period=14)

        if not rsi_series or not atr_series:
            return None

        current_rsi = rsi_series[-1]
        current_atr = atr_series[-1]
        current_close = closes[-1]
        latest_candle = candles[-1]

        signal: Optional[TradeSignal] = None

        # Bullish Sniper Setup: Bullish Regime + RVOL Confirmation + Pullback to RSI value
        if regime == MarketRegime.TRENDING_BULL and rvol >= self.min_rvol and 40.0 <= current_rsi <= 55.0:
            stop_loss = current_close - (current_atr * 1.5)
            risk = current_close - stop_loss
            take_profit = current_close + (risk * self.min_rr)
            rr = (take_profit - current_close) / risk

            signal = TradeSignal(
                symbol=latest_candle.symbol,
                timeframe=latest_candle.timeframe,
                direction=SignalDirection.LONG,
                setup_name="SNIPER_BULLISH_TREND_PULLBACK",
                entry_min=current_close * 0.999,
                entry_max=current_close * 1.001,
                stop_loss=round(stop_loss, 4),
                take_profit=round(take_profit, 4),
                risk_reward_ratio=round(rr, 2),
                confidence=0.88,
                confluence_score=85.0,
                regime=regime.value,
                reasons=[
                    f"Aligned with {regime.value}",
                    f"High RVOL confirmation ({rvol:.2f}x)",
                    f"RSI pullback value at {current_rsi:.1f}",
                    f"Target RR >= {self.min_rr}"
                ]
            )

        # Bearish Sniper Setup: Bearish Regime + RVOL Confirmation + Overbought bounce
        elif regime == MarketRegime.TRENDING_BEAR and rvol >= self.min_rvol and 45.0 <= current_rsi <= 60.0:
            stop_loss = current_close + (current_atr * 1.5)
            risk = stop_loss - current_close
            take_profit = current_close - (risk * self.min_rr)
            rr = (current_close - take_profit) / risk

            signal = TradeSignal(
                symbol=latest_candle.symbol,
                timeframe=latest_candle.timeframe,
                direction=SignalDirection.SHORT,
                setup_name="SNIPER_BEARISH_TREND_REJECTION",
                entry_min=current_close * 0.999,
                entry_max=current_close * 1.001,
                stop_loss=round(stop_loss, 4),
                take_profit=round(take_profit, 4),
                risk_reward_ratio=round(rr, 2),
                confidence=0.88,
                confluence_score=85.0,
                regime=regime.value,
                reasons=[
                    f"Aligned with {regime.value}",
                    f"High RVOL confirmation ({rvol:.2f}x)",
                    f"RSI rejection value at {current_rsi:.1f}",
                    f"Target RR >= {self.min_rr}"
                ]
            )

        return signal
