from typing import List, Optional, Dict
from core.models.market import Candle
from core.models.signal import TradeSignal, SignalDirection
from core.models.mtf import TimeframeBias, MTFConfluenceReport
from engines.indicators import TechnicalIndicators
from engines.regime import RegimeClassifier, MarketRegime


class MTFSniperEngine:
    def __init__(self, min_rr: float = 2.0, min_rvol: float = 1.25):
        self.min_rr = min_rr
        self.min_rvol = min_rvol
        self.regime_classifier = RegimeClassifier()

    def evaluate_4h_bias(self, candles_4h: List[Candle]) -> TimeframeBias:
        if len(candles_4h) < 50:
            return TimeframeBias.NEUTRAL

        closes = [c.close for c in candles_4h]
        ema_50 = TechnicalIndicators.calculate_ema(closes, 50)
        ema_20 = TechnicalIndicators.calculate_ema(closes, 20)

        if not ema_50 or not ema_20:
            return TimeframeBias.NEUTRAL

        curr_close = closes[-1]
        if curr_close > ema_50[-1] and ema_20[-1] >= ema_50[-1]:
            return TimeframeBias.BULLISH
        elif curr_close < ema_50[-1] and ema_20[-1] <= ema_50[-1]:
            return TimeframeBias.BEARISH

        return TimeframeBias.NEUTRAL

    def evaluate_1h_momentum(self, candles_1h: List[Candle]) -> TimeframeBias:
        if len(candles_1h) < 30:
            return TimeframeBias.NEUTRAL

        closes = [c.close for c in candles_1h]
        ema_20 = TechnicalIndicators.calculate_ema(closes, 20)
        rsi_14 = TechnicalIndicators.calculate_rsi(closes, 14)

        if not ema_20 or not rsi_14:
            return TimeframeBias.NEUTRAL

        curr_close = closes[-1]
        curr_rsi = rsi_14[-1]

        if curr_close > ema_20[-1] and curr_rsi >= 50.0:
            return TimeframeBias.BULLISH
        elif curr_close < ema_20[-1] and curr_rsi <= 50.0:
            return TimeframeBias.BEARISH

        return TimeframeBias.NEUTRAL

    def evaluate(
        self,
        candles_15m: List[Candle],
        candles_1h: List[Candle],
        candles_4h: List[Candle],
    ) -> Optional[TradeSignal]:
        if len(candles_15m) < 60:
            return None

        bias_4h = self.evaluate_4h_bias(candles_4h)
        bias_1h = self.evaluate_1h_momentum(candles_1h)

        closes_15m = [c.close for c in candles_15m]
        highs_15m = [c.high for c in candles_15m]
        lows_15m = [c.low for c in candles_15m]
        volumes_15m = [c.volume for c in candles_15m]

        regime_15m = self.regime_classifier.classify(highs_15m, lows_15m, closes_15m)
        rvol = TechnicalIndicators.calculate_rvol(volumes_15m, period=20)
        rsi_15m = TechnicalIndicators.calculate_rsi(closes_15m, period=14)
        atr_15m = TechnicalIndicators.calculate_atr(highs_15m, lows_15m, closes_15m, period=14)

        if not rsi_15m or not atr_15m:
            return None

        curr_rsi = rsi_15m[-1]
        curr_atr = atr_15m[-1]
        curr_close = closes_15m[-1]
        latest_candle = candles_15m[-1]

        signal: Optional[TradeSignal] = None

        # STRICT LONG CONFLUENCE: 4H Bullish + 1H Bullish + 15m Trend Pullback with RVOL
        if (
            bias_4h == TimeframeBias.BULLISH
            and bias_1h == TimeframeBias.BULLISH
            and regime_15m == MarketRegime.TRENDING_BULL
            and rvol >= self.min_rvol
            and 40.0 <= curr_rsi <= 55.0
        ):
            stop_loss = curr_close - (curr_atr * 1.5)
            risk = curr_close - stop_loss
            take_profit = curr_close + (risk * self.min_rr)
            rr = (take_profit - curr_close) / risk

            signal = TradeSignal(
                symbol=latest_candle.symbol,
                timeframe="15m",
                direction=SignalDirection.LONG,
                setup_name="MTF_SNIPER_BULLISH_CONFLUENCE",
                entry_min=round(curr_close * 0.9995, 4),
                entry_max=round(curr_close * 1.0005, 4),
                stop_loss=round(stop_loss, 4),
                take_profit=round(take_profit, 4),
                risk_reward_ratio=round(rr, 2),
                confidence=0.92,
                confluence_score=95.0,
                regime=regime_15m.value,
                reasons=[
                    "4H Macro Bias: BULLISH (Price > 4H EMA50)",
                    "1H Momentum Bias: BULLISH (Price > 1H EMA20 & RSI >= 50)",
                    f"15m Regime: {regime_15m.value}",
                    f"15m RVOL Expansion: {rvol:.2f}x (threshold >= {self.min_rvol})",
                    f"15m RSI Pullback: {curr_rsi:.1f}",
                    f"Target RR >= {self.min_rr:.1f}"
                ]
            )

        # STRICT SHORT CONFLUENCE: 4H Bearish + 1H Bearish + 15m Trend Rejection with RVOL
        elif (
            bias_4h == TimeframeBias.BEARISH
            and bias_1h == TimeframeBias.BEARISH
            and regime_15m == MarketRegime.TRENDING_BEAR
            and rvol >= self.min_rvol
            and 45.0 <= curr_rsi <= 60.0
        ):
            stop_loss = curr_close + (curr_atr * 1.5)
            risk = stop_loss - curr_close
            take_profit = curr_close - (risk * self.min_rr)
            rr = (curr_close - take_profit) / risk

            signal = TradeSignal(
                symbol=latest_candle.symbol,
                timeframe="15m",
                direction=SignalDirection.SHORT,
                setup_name="MTF_SNIPER_BEARISH_CONFLUENCE",
                entry_min=round(curr_close * 0.9995, 4),
                entry_max=round(curr_close * 1.0005, 4),
                stop_loss=round(stop_loss, 4),
                take_profit=round(take_profit, 4),
                risk_reward_ratio=round(rr, 2),
                confidence=0.92,
                confluence_score=95.0,
                regime=regime_15m.value,
                reasons=[
                    "4H Macro Bias: BEARISH (Price < 4H EMA50)",
                    "1H Momentum Bias: BEARISH (Price < 1H EMA20 & RSI <= 50)",
                    f"15m Regime: {regime_15m.value}",
                    f"15m RVOL Expansion: {rvol:.2f}x (threshold >= {self.min_rvol})",
                    f"15m RSI Bounce: {curr_rsi:.1f}",
                    f"Target RR >= {self.min_rr:.1f}"
                ]
            )

        return signal
