import os
import httpx
from dotenv import load_dotenv

load_dotenv()
api_key = os.getenv("GOOGLE_API_KEY", "").strip()

# 1. Fetch live available Gemini models for this API key
url = f"https://generativelanguage.googleapis.com/v1beta/models?key={api_key}"
resp = httpx.get(url, timeout=10.0)
available_models = []

if resp.status_code == 200:
    for m in resp.json().get("models", []):
        methods = m.get("supportedGenerationMethods", [])
        if "generateContent" in methods:
            available_models.append(m.get("name", "").replace("models/", ""))
    print(f"Verified Google API Key. Available models: {available_models[:6]}")
else:
    print(f"Warning: Could not fetch models ({resp.status_code}). Using default fallback.")

# Pick the best available model
chosen_model = "gemini-2.5-flash"
priority_list = [
    "gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-3.5-flash",
    "gemini-3.6-flash", "gemini-1.5-flash", "gemini-1.5-pro"
]
for candidate in priority_list:
    if candidate in available_models:
        chosen_model = candidate
        break

print(f"Selected operational Gemini model: {chosen_model}")

# 2. Build the Apex Native Crypto Auditor
auditor_code = f'''import asyncio
import os
import json
import httpx
from datetime import datetime, timezone
from typing import Dict, Any

from core.logging.logger import logger
from infrastructure.redis.client import get_redis_client


class TradingAgentsAuditor:
    def __init__(self):
        self.api_key = os.getenv("GOOGLE_API_KEY", "").strip()
        self.model = "{chosen_model}"

    @property
    def redis(self):
        return get_redis_client()

    async def _fetch_binance_context(self, symbol: str) -> Dict[str, Any]:
        """Fetches live Binance Futures context (24h volume, price action, funding rate)."""
        base_url = "https://fapi.binance.com"
        clean_sym = symbol.upper()
        if not clean_sym.endswith("USDT"):
            clean_sym += "USDT"

        async with httpx.AsyncClient(timeout=8.0) as client:
            try:
                t24_resp, fund_resp = await asyncio.gather(
                    client.get(f"{{base_url}}/fapi/v1/ticker/24hr", params={{"symbol": clean_sym}}),
                    client.get(f"{{base_url}}/fapi/v1/premiumIndex", params={{"symbol": clean_sym}}),
                    return_exceptions=True
                )
                t24 = t24_resp.json() if not isinstance(t24_resp, Exception) and t24_resp.status_code == 200 else {{}}
                fund = fund_resp.json() if not isinstance(fund_resp, Exception) and fund_resp.status_code == 200 else {{}}

                return {{
                    "symbol": clean_sym,
                    "price": float(t24.get("lastPrice", 0.0)),
                    "price_change_24h": float(t24.get("priceChangePercent", 0.0)),
                    "volume_quote_m": round(float(t24.get("quoteVolume", 0.0)) / 1_000_000, 2),
                    "high_24h": float(t24.get("highPrice", 0.0)),
                    "low_24h": float(t24.get("lowPrice", 0.0)),
                    "funding_rate_pct": round(float(fund.get("lastFundingRate", 0.0)) * 100, 4)
                }}
            except Exception as e:
                logger.error("binance_context_fetch_failed", symbol=clean_sym, error=str(e))
                return {{"symbol": clean_sym, "price": 0.0, "price_change_24h": 0.0, "volume_quote_m": 0.0}}

    async def audit_asset(self, symbol: str) -> Dict[str, Any]:
        sym = symbol.upper()
        cache_key = f"apex:ai_audit:{{sym}}"

        # Check cache
        try:
            cached = await self.redis.get(cache_key)
            if cached:
                return json.loads(cached)
        except Exception:
            pass

        ctx = await self._fetch_binance_context(sym)
        prompt = (
            f"You are the Chief Quantitative Risk Auditor of an institutional trading desk.\\n"
            f"Asset: {{ctx['symbol']}}\\n"
            f"Current Binance Futures Price: ${{ctx.get('price', 'N/A')}}\\n"
            f"24h Price Change: {{ctx.get('price_change_24h', 'N/A')}}%\\n"
            f"24h Quote Volume: ${{ctx.get('volume_quote_m', 'N/A')}}M USDT\\n"
            f"8h Predicted Funding Rate: {{ctx.get('funding_rate_pct', 'N/A')}}%\\n\\n"
            f"Perform a concise institutional audit following this structure:\\n"
            f"1. **Market Structure & Liquidity**: Assess volume and current price level.\\n"
            f"2. **Funding & Positioning Bias**: Interpret perpetual funding rate (crowded longs vs shorts).\\n"
            f"3. **Sniper Execution Verdict**: State strictly [BULLISH CONFLUENCE / BEARISH CONFLUENCE / NEUTRAL AVOID] with a 1-sentence risk mandate.\\n"
            f"Keep it under 150 words. Be direct, quantitative, and professional."
        )

        api_url = f"https://generativelanguage.googleapis.com/v1beta/models/{{self.model}}:generateContent?key={{self.api_key}}"
        payload = {{
            "contents": [{{"parts": [{{"text": prompt}}]}}],
            "generationConfig": {{
                "temperature": 0.2,
                "maxOutputTokens": 450
            }}
        }}

        async with httpx.AsyncClient(timeout=25.0) as client:
            try:
                r = await client.post(api_url, json=payload)
                if r.status_code == 200:
                    resp_json = r.json()
                    candidates = resp_json.get("candidates", [])
                    if candidates:
                        text = candidates[0].get("content", {{}}).get("parts", [{{}}])[0].get("text", "")
                        result = {{"symbol": sym, "decision": text.strip(), "model": self.model}}
                        await self.redis.set(cache_key, json.dumps(result), ex=900)
                        return result
                return {{"symbol": sym, "error": f"API {{r.status_code}}: {{r.text[:100]}}", "decision": "Audit failed."}}
            except Exception as e:
                return {{"symbol": sym, "error": str(e), "decision": "Auditor request timed out."}}
'''

with open("engines/agents/ai_auditor.py", "w") as f:
    f.write(auditor_code)

print("ai_auditor.py successfully updated.")
