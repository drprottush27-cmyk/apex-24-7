"""Graceful shutdown sequence for the APEX trading system.

Orchestrates a deterministic, fail-safe shutdown that preserves all safety
invariants.  The shutdown sequence is:

  1. Engage emergency kill switch (immediate execution halt — fail closed).
  2. Stop the market data feed (cancel the WebSocket task).
  3. Stop the trading orchestrator (stop its internal loops).
  4. Log a CRITICAL audit event (durable trail).
  5. Complete (process may exit).

Guarantees:

* The kill switch is ALWAYS engaged FIRST — before any other cleanup.  Once
  engaged, every order attempt is rejected regardless of whether the rest of
  the shutdown completes.
* Shutdown is idempotent: the first call drives the full sequence; subsequent
  calls return the current state immediately (no duplicate side-effects).
* Shutdown is safe to call from a signal handler, the lifespan teardown, or
  the control-plane API — all three use the same atomic entry point.
* DRY_RUN / LIVE_TRADING_ENABLED / Risk Guardian veto / advisory-only AI —
  none of these are modified by the shutdown sequence.
* The kill switch is never auto-released by shutdown.  An operator who wants
  to resume trading must explicitly call release().
"""

from __future__ import annotations

import asyncio
import enum
from datetime import datetime, timezone
from typing import Any, Optional

from core.logging.logger import logger


class _ShutdownPhase(str, enum.Enum):
    IDLE = "IDLE"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"


class GracefulShutdown:
    """Fail-safe shutdown orchestrator.

    Parameters
    ----------
    order_manager : OrderExecutionManager
        The execution manager that owns the kill switch.
    orchestrator : TradingOrchestrator
        The trading orchestrator that owns the data feed and internal loops.
    timeout : float
        Maximum seconds to wait for each asynchronous shutdown step.
    """

    def __init__(self, order_manager: Any, orchestrator: Any, timeout: float = 10.0) -> None:
        self._order_manager = order_manager
        self._orchestrator = orchestrator
        self._timeout = max(timeout, 1.0)

        self._phase: _ShutdownPhase = _ShutdownPhase.IDLE
        self._started_at: Optional[datetime] = None
        self._done_at: Optional[datetime] = None
        self._errors: list[str] = []
        self._lock = asyncio.Lock()

    # ------------------------------------------------------------------
    # public API
    # ------------------------------------------------------------------

    @property
    def is_shutting_down(self) -> bool:
        return self._phase in (_ShutdownPhase.IDLE, _ShutdownPhase.RUNNING)

    @property
    def is_done(self) -> bool:
        return self._phase in (_ShutdownPhase.COMPLETED, _ShutdownPhase.FAILED)

    def snapshot(self) -> dict:
        """Serializable view of the shutdown state (no secrets)."""
        return {
            "phase": self._phase.value,
            "started_at": self._started_at.isoformat() if self._started_at else None,
            "done_at": self._done_at.isoformat() if self._done_at else None,
            "errors": list(self._errors),
            "duration_seconds": (
                round((self._done_at - self._started_at).total_seconds(), 3)
                if self._started_at and self._done_at
                else None
            ),
        }

    async def run(self, reason: str = "SHUTDOWN") -> dict:
        """Execute the full graceful shutdown sequence.

        Idempotent and concurrency-safe: the first invocation drives the
        sequence; concurrent or subsequent calls block on the internal lock and
        return the already-computed snapshot without re-running side-effects.

        Returns the shutdown snapshot.
        """
        async with self._lock:
            if self.is_done:
                return self.snapshot()

            self._phase = _ShutdownPhase.RUNNING
            self._started_at = datetime.now(timezone.utc)
            self._errors.clear()
            logger.info("graceful_shutdown_sequence_started", reason=reason)

            await self._engage_kill_switch(reason)
            await self._stop_data_feed()
            await self._stop_orchestrator()
            await self._log_audit(reason)
            self._complete()

            return self.snapshot()

    # ------------------------------------------------------------------
    # individual shutdown steps
    # ------------------------------------------------------------------

    async def _engage_kill_switch(self, reason: str) -> None:
        """Step 1: Engage the emergency kill switch (immediate, fail closed).

        This is the FIRST action in every shutdown path — before the data
        feed is stopped and before the orchestrator is torn down.  Once the
        kill switch is engaged, every order attempt through the single
        execution funnel is rejected.  There is no bypass.
        """
        try:
            halt_reason = await self._order_manager.kill_switch_halt(
                f"GRACEFUL_SHUTDOWN: {reason}"
            )
            logger.info("graceful_shutdown_kill_switch_engaged", reason=halt_reason)
        except Exception as exc:
            self._errors.append(f"kill_switch_halt: {exc}")
            logger.error(
                "graceful_shutdown_kill_switch_failed",
                error=str(exc),
            )

    async def _stop_data_feed(self) -> None:
        """Step 2: Stop the market data feed (WebSocket + REST client).

        Uses a bounded timeout so a hanging WebSocket connection never blocks
        the shutdown sequence indefinitely.  The kill switch is already engaged
        by this point, so even if the feed stop hangs, no orders can be placed.
        """
        feed = getattr(self._orchestrator, "feed", None) if self._orchestrator else None
        if feed is None:
            return

        try:
            await asyncio.wait_for(feed.stop(), timeout=min(self._timeout, 5.0))
            logger.info("graceful_shutdown_data_feed_stopped")
        except asyncio.TimeoutError:
            self._errors.append("data_feed_stop_timeout")
            logger.error("graceful_shutdown_data_feed_stop_timeout")
        except Exception as exc:
            self._errors.append(f"data_feed_stop: {exc}")
            logger.error(
                "graceful_shutdown_data_feed_stop_failed",
                error=str(exc),
            )

    async def _stop_orchestrator(self) -> None:
        """Step 3: Stop the trading orchestrator (cleanup its internal loops).

        Uses a bounded timeout.  If the stop hangs beyond the deadline, the
        kill switch is already engaged so no execution can proceed — the
        process can be forcefully terminated safely.
        """
        if self._orchestrator is None:
            return

        try:
            await asyncio.wait_for(self._orchestrator.stop(), timeout=self._timeout)
            logger.info("graceful_shutdown_orchestrator_stopped")
        except asyncio.TimeoutError:
            self._errors.append("orchestrator_stop_timeout")
            logger.error("graceful_shutdown_orchestrator_stop_timeout")
        except Exception as exc:
            self._errors.append(f"orchestrator_stop: {exc}")
            logger.error(
                "graceful_shutdown_orchestrator_stop_failed",
                error=str(exc),
            )

    async def _log_audit(self, reason: str) -> None:
        """Step 4: Write a best-effort CRITICAL audit trail of the shutdown.

        Audit logging is best-effort — it must never prevent the shutdown
        from completing.
        """
        try:
            from infrastructure.postgres.database import AsyncSessionLocal
            from core.models.schema import AuditLog

            status_label = "COMPLETED" if not self._errors else "COMPLETED_WITH_ERRORS"
            duration = (
                round(
                    (datetime.now(timezone.utc) - self._started_at).total_seconds(), 3
                )
                if self._started_at
                else 0.0
            )

            async with AsyncSessionLocal() as session:
                session.add(
                    AuditLog(
                        event_type="GRACEFUL_SHUTDOWN",
                        service="GRACEFUL_SHUTDOWN",
                        severity="CRITICAL",
                        details={
                            "action": "SHUTDOWN",
                            "reason": reason,
                            "status": status_label,
                            "errors": self._errors,
                            "duration_seconds": duration,
                        },
                    )
                )
                await session.commit()
            logger.info(
                "graceful_shutdown_audit_logged",
                reason=reason,
                status=status_label,
                duration=duration,
            )
        except Exception as exc:
            self._errors.append(f"audit_log: {exc}")
            logger.error(
                "graceful_shutdown_audit_log_failed",
                error=str(exc),
            )

    def _complete(self) -> None:
        """Transition to COMPLETED or FAILED after all steps have run."""
        self._done_at = datetime.now(timezone.utc)
        duration = round((self._done_at - self._started_at).total_seconds(), 3)
        if self._errors:
            self._phase = _ShutdownPhase.FAILED
            logger.error(
                "graceful_shutdown_sequence_failed",
                errors=self._errors,
                duration=duration,
            )
        else:
            self._phase = _ShutdownPhase.COMPLETED
            logger.info(
                "graceful_shutdown_sequence_completed",
                duration=duration,
            )
