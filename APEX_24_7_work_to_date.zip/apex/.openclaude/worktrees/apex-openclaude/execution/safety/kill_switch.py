"""Fail-closed emergency kill switch for APEX execution.

The kill switch is the operator's authoritative emergency halt. When engaged,
it is an execution-path VETO: every attempt to submit an order through the
single execution boundary (``OrderExecutionManager.execute_order``) is
rejected — regardless of whether the request originates from the trading
orchestrator, an engineering agent, a provider, or a direct caller.

Guarantees:

* Once engaged, execution is blocked on EVERY order path (there is no bypass:
  the check lives inside ``execute_order`` itself, the single funnel every
  order request must pass through).
* Fail closed: a halt is authoritative and unambiguous. ``is_halted()``
  reflects the engaged state; any order attempt while halted returns REJECTED
  with a clear ``KILL_SWITCH`` marker.
* The kill switch carries no enable/disable "off" state that could weaken it.
  It is always available; engaging it halts. Releasing it is an explicit,
  audited operator action.
* A halted state never auto-releases. Only an explicit ``release`` clears it.

The kill switch is advisory-neutral: it blocks execution but does not itself
place, cancel, or modify any order. It does not bypass the Risk Guardian or any
other safety control; it is an additional, outermost fail-closed gate.

Durability note: the halt is authoritative within the running process. Because
the API control plane and the order manager share that process, an engaged
switch is effective immediately on all paths. The engaged state is recorded in
the audit log so operators have a durable trail.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional


class KillSwitchEngaged(Exception):
    """Raised when an order is attempted while the emergency kill switch is
    engaged. Never auto-continues; the caller turns this into a fail-closed
    REJECTED outcome."""


class KillSwitch:
    """Operator-controlled emergency execution halt.

    State is process-authoritative. ``halt``/``release`` are the only ways to
    change it; there is no constructor/flag parameter that arms or disarms the
    feature (engaging is guarded but the gate always exists).
    """

    def __init__(self) -> None:
        self._halted: bool = False
        self._reason: str = ""
        self._halted_at: Optional[datetime] = None

    # -- state query ------------------------------------------------------
    @property
    def is_halted(self) -> bool:
        return self._halted

    @property
    def reason(self) -> str:
        return self._reason

    @property
    def halted_at(self) -> Optional[datetime]:
        return self._halted_at

    def current_halt(self) -> Optional[str]:
        """Return the active halt reason, or None if not halted.

        This is the fail-closed, single source of truth the execution path
        consults. ``None`` (not halted) == execution allowed by this gate.
        """
        return self._reason if self._halted else None

    def is_engaged(self) -> bool:
        return self._halted

    # -- control ----------------------------------------------------------
    def halt(self, reason: str = "") -> str:
        """Engage the emergency halt immediately. Returns the halt reason."""
        self._reason = (reason or "MANUAL_EMERGENCY_HALT").strip()
        self._halted = True
        self._halted_at = datetime.now(timezone.utc)
        return self._reason

    def release(self, reason: str = "") -> None:
        """Disengage the halt (explicit, audited operator action)."""
        self._reason = ""
        self._halted = False
        self._halted_at = None
        self._release_reason = reason

    # -- fail-closed execution gate --------------------------------------
    def assert_can_execute(self, order_ref: str = "") -> str:
        """Raise :class:`KillSwitchEngaged` when the switch is engaged.

        Called by the single execution boundary. On a clean (non-halted) state
        returns the empty string (no reason). Otherwise raises so the caller
        fails closed — it can NEVER proceed to place an order.
        """
        halt = self.current_halt()
        if halt is not None:
            raise KillSwitchEngaged(
                f"kill_switch_engaged reason={halt} order={order_ref or 'unknown'}"
            )
        return ""

    def snapshot(self) -> dict:
        """Serializable, auditable view of the switch state (no secrets)."""
        return {
            "halted": self._halted,
            "reason": self._reason,
            "halted_at": self._halted_at.isoformat() if self._halted_at else None,
        }