from datetime import datetime, timezone
from typing import List, Optional, Dict, Any
import httpx

from core.logging.logger import logger
from core.models.market import SymbolInfo, Candle, MarkPriceData, OpenInterestData


class BinanceFuturesRESTClient:
    BASE_URL = "https://fapi.binance.com"

    def __init__(self, timeout: float = 10.0):
        self._timeout = timeout
        self._client: Optional[httpx.AsyncClient] = None
        self._last_used_weight: int = 0

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                base_url=self.BASE_URL,
                timeout=self._timeout,
                headers={"User-Agent": "ApexTradingDesk/1.0"}
            )
        return self._client

    async def close(self) -> None:
        if self._client and not self._client.is_closed:
            await self._client.aclose()

    def _track_rate_limit(self, response: httpx.Response) -> None:
        weight = response.headers.get("x-mbx-used-weight-1m")
        if weight:
            self._last_used_weight = int(weight)
            if self._last_used_weight > 2000:
                logger.warning("binance_high_rate_limit_weight", used_weight=self._last_used_weight)

    async def get_server_time(self) -> int:
        client = await self._get_client()
        res = await client.get("/fapi/v1/time")
        res.raise_for_status()
        self._track_rate_limit(res)
        return res.json()["serverTime"]

    async def get_symbol_info(self, symbol: str) -> Optional[SymbolInfo]:
        client = await self._get_client()
        res = await client.get("/fapi/v1/exchangeInfo")
        res.raise_for_status()
        self._track_rate_limit(res)
        data = res.json()

        target = symbol.upper()
        for s in data.get("symbols", []):
            if s.get("symbol") == target:
                min_qty = 0.0
                step_size = 0.0
                tick_size = 0.0
                min_notional = 0.0

                for f in s.get("filters", []):
                    f_type = f.get("filterType")
                    if f_type == "LOT_SIZE":
                        min_qty = float(f.get("minQty", 0.0))
                        step_size = float(f.get("stepSize", 0.0))
                    elif f_type == "PRICE_FILTER":
                        tick_size = float(f.get("tickSize", 0.0))
                    elif f_type in ("MIN_NOTIONAL", "NOTIONAL"):
                        min_notional = float(f.get("notional", f.get("minNotional", 0.0)))

                return SymbolInfo(
                    symbol=s["symbol"],
                    base_asset=s["baseAsset"],
                    quote_asset=s["quoteAsset"],
                    status=s["status"],
                    min_qty=min_qty,
                    step_size=step_size,
                    tick_size=tick_size,
                    min_notional=min_notional,
                    is_trading=(s["status"] == "TRADING"),
                )
        return None

    async def get_klines(
        self,
        symbol: str,
        interval: str,
        limit: int = 100,
        start_time: Optional[int] = None,
        end_time: Optional[int] = None,
    ) -> List[Candle]:
        client = await self._get_client()
        params: Dict[str, Any] = {
            "symbol": symbol.upper(),
            "interval": interval,
            "limit": limit,
        }
        if start_time:
            params["startTime"] = start_time
        if end_time:
            params["endTime"] = end_time

        res = await client.get("/fapi/v1/klines", params=params)
        res.raise_for_status()
        self._track_rate_limit(res)

        candles: List[Candle] = []
        for row in res.json():
            candles.append(
                Candle(
                    symbol=symbol.upper(),
                    exchange="BINANCE",
                    timeframe=interval,
                    open_time=datetime.fromtimestamp(row[0] / 1000, tz=timezone.utc),
                    close_time=datetime.fromtimestamp(row[6] / 1000, tz=timezone.utc),
                    open=float(row[1]),
                    high=float(row[2]),
                    low=float(row[3]),
                    close=float(row[4]),
                    volume=float(row[5]),
                    quote_volume=float(row[7]),
                    trades_count=int(row[8]),
                    is_closed=True,
                )
            )
        return candles

    async def get_mark_price(self, symbol: str) -> MarkPriceData:
        client = await self._get_client()
        res = await client.get("/fapi/v1/premiumIndex", params={"symbol": symbol.upper()})
        res.raise_for_status()
        self._track_rate_limit(res)
        data = res.json()

        return MarkPriceData(
            symbol=data["symbol"],
            mark_price=float(data["markPrice"]),
            index_price=float(data["indexPrice"]),
            estimated_settle_price=float(data.get("estimatedSettlePrice", 0.0)) if data.get("estimatedSettlePrice") else None,
            funding_rate=float(data["lastFundingRate"]),
            next_funding_time=datetime.fromtimestamp(data["nextFundingTime"] / 1000, tz=timezone.utc),
        )

    async def get_open_interest(self, symbol: str) -> OpenInterestData:
        client = await self._get_client()
        res = await client.get("/fapi/v1/openInterest", params={"symbol": symbol.upper()})
        res.raise_for_status()
        self._track_rate_limit(res)
        data = res.json()

        return OpenInterestData(
            symbol=data["symbol"],
            open_interest=float(data["openInterest"]),
        )
