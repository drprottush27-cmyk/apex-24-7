import hmac
import hashlib
import time
import httpx
from typing import Dict, Any, Optional
from urllib.parse import urlencode

from core.logging.logger import logger
from core.config.settings import get_settings
from execution.safety.endpoint_isolation import (
    EndpointGuard,
    EndpointIsolationError,
)


class BinanceFuturesClient:
    def __init__(self, guard: Optional[EndpointGuard] = None):
        settings = get_settings()
        self.api_key = settings.BINANCE_API_KEY
        self.api_secret = settings.BINANCE_API_SECRET
        self.guard = guard or EndpointGuard()
        self.base_url = self.guard.base_url()

    def _sign_payload(self, params: Dict[str, Any]) -> str:
        params["timestamp"] = int(time.time() * 1000)
        query_string = urlencode(params)
        signature = hmac.new(
            self.api_secret.encode("utf-8"),
            query_string.encode("utf-8"),
            hashlib.sha256
        ).hexdigest()
        return f"{query_string}&signature={signature}"

    def _headers(self) -> Dict[str, str]:
        return {
            "X-MBX-APIKEY": self.api_key,
            "Content-Type": "application/x-www-form-urlencoded"
        }

    def _private(self) -> None:
        """Fail closed BEFORE any signed/account/order network call."""
        self.guard.assert_can_submit_order()

    async def get_account_balance(self) -> Dict[str, Any]:
        self._private()
        params = self._sign_payload({})
        url = f"{self.base_url}/fapi/v2/account?{params}"
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(url, headers=self._headers())
            resp.raise_for_status()
            return resp.json()

    async def set_leverage(self, symbol: str, leverage: int = 5) -> Dict[str, Any]:
        self._private()
        params = {"symbol": symbol.upper(), "leverage": leverage}
        signed_query = self._sign_payload(params)
        url = f"{self.base_url}/fapi/v1/leverage?{signed_query}"
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.post(url, headers=self._headers())
            resp.raise_for_status()
            return resp.json()

    async def set_margin_type(self, symbol: str, margin_type: str = "ISOLATED") -> Optional[Dict[str, Any]]:
        self._private()
        params = {"symbol": symbol.upper(), "marginType": margin_type.upper()}
        signed_query = self._sign_payload(params)
        url = f"{self.base_url}/fapi/v1/marginType?{signed_query}"
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.post(url, headers=self._headers())
            if resp.status_code == 200:
                return resp.json()
            if "No need to change" in resp.text:
                return {"msg": "unchanged"}
            resp.raise_for_status()
            return resp.json()

    async def post_order(
        self,
        symbol: str,
        side: str,
        order_type: str,
        quantity: float,
        price: Optional[float] = None,
        client_order_id: Optional[str] = None,
        reduce_only: bool = False,
    ) -> Dict[str, Any]:
        self._private()
        params: Dict[str, Any] = {
            "symbol": symbol.upper(),
            "side": side.upper(),
            "type": order_type.upper(),
            "quantity": quantity,
        }

        if client_order_id:
            params["newClientOrderId"] = client_order_id

        if reduce_only:
            params["reduceOnly"] = "true"

        if order_type.upper() == "LIMIT":
            params["price"] = price
            params["timeInForce"] = "GTC"

        signed_query = self._sign_payload(params)
        url = f"{self.base_url}/fapi/v1/order?{signed_query}"

        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.post(url, headers=self._headers())
            if resp.status_code != 200:
                logger.error("binance_order_rejected", status=resp.status_code, body=resp.text)
            resp.raise_for_status()
            return resp.json()

    async def cancel_order(self, symbol: str, client_order_id: str) -> Dict[str, Any]:
        self._private()
        params = {
            "symbol": symbol.upper(),
            "origClientOrderId": client_order_id
        }
        signed_query = self._sign_payload(params)
        url = f"{self.base_url}/fapi/v1/order?{signed_query}"
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.delete(url, headers=self._headers())
            resp.raise_for_status()
            return resp.json()
