import asyncio
import json
import websockets
from typing import Callable, Coroutine, List, Any
from core.logging.logger import logger


class BinanceFuturesWebSocket:
    def __init__(self, streams: List[str]):
        self.streams = streams
        self.base_url = "wss://fstream.binance.com/ws"
        self._running = False
        self._ws = None

    async def start(self, message_handler: Callable[[dict], Coroutine[Any, Any, None]]):
        self._running = True
        backoff = 1

        while self._running:
            try:
                stream_path = "/".join(self.streams)
                url = f"{self.base_url}/{stream_path}"
                logger.info("binance_ws_connecting", url=url)

                async with websockets.connect(
                    url,
                    ping_interval=20,
                    ping_timeout=10,
                    close_timeout=5
                ) as ws:
                    self._ws = ws
                    backoff = 1
                    logger.info("binance_ws_connected_active")

                    while self._running:
                        try:
                            msg = await asyncio.wait_for(ws.recv(), timeout=30.0)
                            data = json.loads(msg)
                            await message_handler(data)
                        except asyncio.TimeoutError:
                            pong_waiter = await ws.ping()
                            await asyncio.wait_for(pong_waiter, timeout=10.0)
                        except websockets.ConnectionClosed as e:
                            logger.warning("binance_ws_connection_closed", reason=str(e))
                            break

            except Exception as e:
                logger.error("binance_ws_exception_reconnecting", error=str(e), backoff_sec=backoff)
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 60)

    async def stop(self):
        self._running = False
        if self._ws:
            await self._ws.close()
            logger.info("binance_ws_stopped_cleanly")
