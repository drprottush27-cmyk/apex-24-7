# APEX Test Status

Last full test run: P2-17 core engine stubs

Targeted test status:
- tests/unit/test_systemd_units.py: PASS (17 passed) — deterministic systemd
  safety invariants: unit + install doc exist; no live-trading env
  (no Environment=/EnvironmentFile=, no TRADING_MODE=LIVE /
  LIVE_TRADING_ENABLED=true / AUTO_EXECUTE=true directives); no secrets or
  credentials embedded; non-root User=apex / Group=apex; explicit
  WorkingDirectory=/home/apex/apex; Type=simple for normal SIGTERM; bounded
  TimeoutStopSec=30; bounded Restart=on-failure + RestartSec=5; start-limit
  burst prevents uncontrolled restart loop; least-privilege hardening
  (NoNewPrivileges, ProtectSystem=strict, PrivateTmp, RestrictSUIDSGID,
  RestrictRealtime, RestrictAddressFamilies); ExecStart uses the existing venv
  uvicorn binary (no shell, binds 127.0.0.1 only); ExecStartPre guards.
  systemd-analyze verify clean (exit 0) on the unit.
- tests/unit/test_graceful_shutdown.py: PASS (16 passed) — GracefulShutdown unit
  + integration: kills switch engaged first, stops feed + orchestrator, audit,
  idempotent/concurrency-safe, timeout handling, DRY_RUN/LIVE preserved, no
  auto-release, control-plane endpoint (/api/v1/shutdown confirm + status)
- tests/unit/test_kill_switch.py: PASS (15 passed) — KillSwitch unit + real
  execution-path veto (direct execute_order, DRY_RUN bypass, signal submission,
  reduce-only close intact, release re-enables, persistence, status)
- tests/unit/test_api_endpoints.py: PASS (4 passed) — includes
  test_kill_switch_requires_confirmation (control-plane engage/release/status +
  real order REJECTED/veto)
- tests/unit/test_orchestrator.py: PASS (84 passed) — includes TestAgentCommittee
  (11), TestFinalReviewCommittee (2), TestOllamaProvider (9), TestProvider
- tests/unit/test_endpoint_isolation.py: PASS (11 passed)
- tests/unit/test_binance_adapter.py: PASS (2 passed)
- tests/unit/test_reconciliation.py: PASS (14 passed)
- tests/unit/test_order_expiry.py: PASS (15 passed)
- tests/unit/test_cors_restriction.py: PASS (5 passed)
- tests/unit/test_api_auth.py: PASS (12 passed)
- tests/unit/test_market_scanner.py: PASS (1 passed)
- tests/unit/test_duplicate_order_protection.py: PASS (16 passed)
- tests/unit/test_risk_leverage_execution.py: PASS (27 passed)
- tests/unit/test_order_manager_startup.py: PASS (6 passed)
- tests/unit/test_portfolio_equity.py: PASS (9 passed)
- tests/unit/test_risk_guardian.py: PASS (3 passed)
- tests/unit/test_order_manager.py / test_position_lifecycle.py: PASS
- tests/unit/test_ai_auditor_stub.py: PASS (12 passed) — hermetic, deterministic
  tests for the P2-17-neutralized advisory audit stub: no HTTP/network client in
  the module; no credential read/storage; default fails closed to NEUTRAL AVOID
  (never fabricates BULLISH/BEARISH mandate); output is advisory-only and cannot
  be used as an order object; deterministic (same input -> same output); symbol
  normalization; injected providers are consulted; provider errors / non-dict
  context / empty decision / network-refused all fail closed to NEUTRAL AVOID;
  audit_asset never raises on provider failure; module contains no execution
  path (no order_manager/order_request/execute_order/leverage/exchange host).

Full suite result: 286 passed, 1 skipped, 0 failed

Known failure: NONE.
(1 skipped = pre-existing intentional Binance WebSocket skip.)

New coverage from P2-17 (core engine stubs — neutralized AI auditor, 12
deterministic hermetic tests):
- no HTTP/network client dependency in the auditor module (no Binance/Gemini/
  telegram host, no httpx/aiohttp/requests)
- no credential is read or stored; audit output carries no credential material
- default path fails closed to a NEUTRAL AVOID advisory verdict; never
  fabricates a BULLISH or BEARISH execution mandate from unavailable context
- output is advisory-only (advisory_only=True, live_market_data=False,
  model='deterministic-stub') and carries no order fields (no quantity/side/
  order_type/entry/stop_loss/take_profit/client_order_id/leverage)
- deterministic: same input -> identical output
- symbol normalization (uppercase + USDT-suffix)
- injected market-context / decision providers are consulted; provider errors,
  non-dict context, empty decision, and network-refused all fail closed to
  NEUTRAL AVOID
- audit_asset never raises on provider failure (error=None, decision present)
- module contains no execution path (no order_manager/OrderRequest/
  execute_order/set_leverage/exchange host)

New coverage from P2-16 (systemd units, 17 deterministic tests):
- unit file and install doc exist; systemd-analyze verify clean
- no live-trading directive or environment (no Environment=/EnvironmentFile=)
- no embedded secrets / credentials / private material in the unit
- User=apex / Group=apex (non-root), explicit WorkingDirectory
- Type=simple => normal SIGTERM semantics for graceful shutdown
- TimeoutStopSec bounded (30) so the GracefulShutdown sequence completes or
  escalates safely
- Restart=on-failure + RestartSec=5 + StartLimitBurst/Interval => bounded
  restart, no uncontrolled loop
- least-privilege hardening present and compatible
- ExecStart uses the existing venv uvicorn binary (no shell), binds only
  127.0.0.1 (no public/live endpoint added)
- ExecStartPre guards are harmless /usr/bin/test checks

Last verified commit:
P2-17 core engine stubs (neutralized AI auditor).

Safety verification: SafetyReviewer APPROVED; `git diff --check` clean;
`git remote -v` shows no remote.