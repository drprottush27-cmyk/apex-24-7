import uvicorn


def main():
    uvicorn.run(
        "api.app:app",
        host="127.0.0.1",
        port=8000,
        reload=False,
        access_log=False,
        workers=1,
    )


if __name__ == "__main__":
    main()
