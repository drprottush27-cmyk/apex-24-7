import hmac
from fastapi import Request
from fastapi.responses import JSONResponse

from core.config.settings import get_settings


async def api_key_auth_middleware(request: Request, call_next):
    public_paths = {"/health", "/docs", "/openapi.json", "/redoc"}

    if request.url.path in public_paths or request.url.path.startswith("/miniapp"):
        return await call_next(request)

    settings = get_settings()
    api_key = settings.API_KEY

    if not api_key:
        return JSONResponse(
            status_code=401,
            content={"detail": "Authentication required"},
        )

    auth_header = request.headers.get("authorization", "")

    if not auth_header.startswith("Bearer "):
        return JSONResponse(
            status_code=401,
            content={"detail": "Invalid authentication scheme"},
        )

    token = auth_header[7:]

    if not hmac.compare_digest(token, api_key):
        return JSONResponse(
            status_code=401,
            content={"detail": "Invalid API key"},
        )

    return await call_next(request)
