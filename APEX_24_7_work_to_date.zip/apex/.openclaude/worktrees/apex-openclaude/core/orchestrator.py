import asyncio
import math
from typing import List, Dict
from core.config.settings import get_settings
from core.logging.logger import logger
from core.models.market import Candle, MarkPriceData
from execution.adapters.binance.data_feed import BinanceMarketDataFeed
from engines.signals.mtf_sniper import MTFSniperEngine
from engines.risk.guardian import RiskGuardian
from execution.order_manager import OrderExecutionManager
from infrastructure.notifications.notifier import NotificationGateway
from agents.portfolio.equity_service import PortfolioEquityService


class TradingOrchestrator:
    def __init__(self, symbols: List[str], timeframes: List[str] = None):
        self.settings = get_settings()
        self.symbols = [s.upper() for s in symbols]
        self.timeframes = timeframes or ["15m", "1h", "4h"]

        self.feed = BinanceMarketDataFeed(symbols=self.symbols, timeframes=self.timeframes)
        self.mtf_engine = MTFSniperEngine(min_rr=2.0, min_rvol=1.20)
        self.risk_guardian = RiskGuardian()
        self.equity_service = PortfolioEquityService()
        self.order_manager = OrderExecutionManager(on_realized_pnl=self.equity_service.record_realized_pnl)
        self.notifier = NotificationGateway()

        self._candle_buffers: Dict[str, List[Candle]] = {}
        self._running = False
        self._initialized = False
        # False = Signal Alert Mode only; True = Automated Order Execution Active (GO mode)
        self.auto_execution_active = True

    async def initialize(self) -> None:
        if self._initialized:
            return
        self._initialized = True
        logger.info("initializing_mtf_orchestrator", symbols=self.symbols, timeframes=self.timeframes)
        self.equity_service.initialize()

        try:
            await self.order_manager.initialize()
        except Exception as e:
            logger.error("order_manager_initialization_failed", error=str(e))
            raise

        for sym in self.symbols:
            for tf in self.timeframes:
                key = f"{sym}:{tf}"
                limit = 80 if tf == "4h" else 100
                history = await self.feed.preload_history(sym, tf, limit=limit)
                self._candle_buffers[key] = history

        self.feed.ws_client.add_listener(self._on_market_event)

    async def update_tracked_symbols(self, new_symbols: List[str]) -> List[str]:
        sanitized = [s.upper() for s in new_symbols if s.endswith("USDT")]
        if not sanitized:
            return self.symbols

        logger.info("hot_reloading_tracked_symbols", current=self.symbols, target=sanitized)
        await self.feed.stop()
        self.symbols = sanitized
        self.feed = BinanceMarketDataFeed(symbols=self.symbols, timeframes=self.timeframes)
        self.feed.ws_client.add_listener(self._on_market_event)

        for sym in self.symbols:
            for tf in self.timeframes:
                key = f"{sym}:{tf}"
                limit = 80 if tf == "4h" else 100
                history = await self.feed.preload_history(sym, tf, limit=limit)
                self._candle_buffers[key] = history

        if self._running:
            self.feed.start()

        logger.info("hot_reload_complete", active_symbols=self.symbols)
        return self.symbols

    async def set_execution_mode(self, active: bool) -> bool:
        self.auto_execution_active = active
        status_text = "ACTIVE (Auto-Execution)" if active else "MONITOR ONLY (Signals/Alerts Only)"
        await self.notifier.send_alert(
            title=f"DESK EXECUTION MODE: {status_text}",
            message=f"Trading OS auto-execution state toggled to: `{active}`.",
            level="INFO"
        )
        return self.auto_execution_active

    async def _on_market_event(self, stream: str, payload: any) -> None:
        if isinstance(payload, MarkPriceData):
            await self.order_manager.on_mark_price_tick(payload.symbol, payload.mark_price)

        elif isinstance(payload, Candle) and payload.is_closed:
            key = f"{payload.symbol}:{payload.timeframe}"
            buffer = self._candle_buffers.setdefault(key, [])
            buffer.append(payload)
            max_len = 100 if payload.timeframe == "4h" else 150
            if len(buffer) > max_len:
                buffer.pop(0)

            if payload.timeframe == "15m":
                await self._evaluate_symbol_mtf(payload.symbol)

    async def _evaluate_symbol_mtf(self, symbol: str) -> None:
        c_15m = self._candle_buffers.get(f"{symbol}:15m", [])
        c_1h = self._candle_buffers.get(f"{symbol}:1h", [])
        c_4h = self._candle_buffers.get(f"{symbol}:4h", [])

        if len(c_15m) < 60 or len(c_1h) < 30 or len(c_4h) < 50:
            return

        signal = self.mtf_engine.evaluate(c_15m, c_1h, c_4h)
        if signal:
            logger.info(
                "mtf_sniper_signal_detected",
                setup=signal.setup_name,
                symbol=signal.symbol,
                direction=signal.direction.value,
                rr=signal.risk_reward_ratio
            )

            await self.notifier.send_alert(
                title=f"SNIPER SIGNAL: {signal.symbol} ({signal.direction.value})",
                message=f"Setup: `{signal.setup_name}`\nEntry: `{signal.entry_min} - {signal.entry_max}`\nSL: `{signal.stop_loss}` | TP: `{signal.take_profit}`\nRR: `{signal.risk_reward_ratio}`\nConfidence: `{signal.confidence * 100:.0f}%`",
                level="SIGNAL"
            )

            if not self.auto_execution_active:
                logger.info("auto_execution_disabled_signal_alerted_only", symbol=signal.symbol)
                return

            open_positions = {
                p.symbol: p for p in self.order_manager.get_all_positions()
            }
            equity_snapshot = self.equity_service.get_equity(open_positions)
            portfolio_equity = equity_snapshot.total_equity
            daily_pnl_pct = equity_snapshot.daily_pnl_pct

            if not math.isfinite(portfolio_equity) or portfolio_equity <= 0:
                logger.error("risk_veto_equity_invalid", equity=portfolio_equity)
                await self.notifier.send_alert(
                    title=f"RISK VETO: {signal.symbol}",
                    message="Signal blocked: Portfolio equity unavailable or invalid.",
                    level="WARNING"
                )
                return

            risk_check = self.risk_guardian.evaluate_order(
                signal=signal,
                portfolio_equity=portfolio_equity,
                daily_pnl_pct=daily_pnl_pct,
                open_positions_count=len(self.order_manager.get_all_positions())
            )

            if risk_check.approved:
                order_result = await self.order_manager.submit_from_signal(signal, risk_check)
                if order_result:
                    logger.info(
                        "mtf_order_placed_from_signal",
                        order_id=order_result.client_order_id,
                        symbol=signal.symbol,
                        fill_price=order_result.avg_fill_price
                    )
            else:
                logger.warning("risk_vetoed_mtf_signal", reasons=risk_check.checks_failed)
                await self.notifier.send_alert(
                    title=f"RISK VETO: {signal.symbol}",
                    message=f"Signal blocked by Risk Guardian:\n• " + "\n• ".join(risk_check.checks_failed),
                    level="WARNING"
                )

    def start(self) -> None:
        self._running = True
        self.feed.start()
        logger.info("mtf_trading_orchestrator_started")

    async def stop(self) -> None:
        self._running = False
        await self.feed.stop()
        logger.info("mtf_trading_orchestrator_stopped")
