from enum import Enum
from typing import Optional
from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class TradingMode(str, Enum):
    DRY_RUN = "DRY_RUN"
    PAPER = "PAPER"
    LIVE = "LIVE"


class RiskMode(str, Enum):
    CONSERVATIVE = "CONSERVATIVE"
    AGGRESSIVE = "AGGRESSIVE"


class AppSettings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore"
    )

    APP_ENV: str = Field(default="development")
    LOG_LEVEL: str = Field(default="INFO")

    # Execution & Risk Controls (Hard-coded safety defaults)
    TRADING_MODE: TradingMode = Field(default=TradingMode.DRY_RUN)
    LIVE_TRADING_ENABLED: bool = Field(default=False)
    RISK_MODE: RiskMode = Field(default=RiskMode.CONSERVATIVE)
    MAX_LEVERAGE: int = Field(default=5, ge=1, le=10)
    RISK_PER_TRADE: float = Field(default=0.01, ge=0.001, le=0.05)
    DAILY_DRAWDOWN_KILL: float = Field(default=0.03, ge=0.01, le=0.10)

    # Portfolio
    INITIAL_BALANCE: float = Field(default=1000.0, gt=0.0)
    ORDER_TTL_SECONDS: int = Field(default=300)
    SHUTDOWN_TIMEOUT_SECONDS: int = Field(default=10)

    # Infrastructure
    DATABASE_URL: str = Field(default="postgresql://apex_user:apex_password@localhost:5432/apex_db")
    REDIS_URL: str = Field(default="redis://localhost:6379/0")
    OLLAMA_URL: str = Field(default="http://localhost:11434")
    OLLAMA_MODEL: str = Field(default="qwen2.5:3b")

    # API Authentication
    API_KEY: Optional[str] = Field(default=None)

    # CORS (Restricted by default — cross-origin is disabled unless explicit
    # origins are allowlisted. NEVER leave a wildcard "*" here.)
    ALLOWED_ORIGINS: str = Field(default="")

    # Exchange Endpoint Isolation (testnet support, disabled by default).
    # When True, ALL order/account operations target the testnet URL only and
    # can NEVER fall back to, or leak into, production. Production endpoints
    # are rejected for order submission unless LIVE is explicitly enabled.
    BINANCE_USE_TESTNET: bool = Field(default=False)
    BINANCE_PRODUCTION_BASE_URL: str = Field(default="https://fapi.binance.com")
    BINANCE_TESTNET_BASE_URL: str = Field(default="https://testnet.binancefuture.com")

    # Exchange Credentials (Never hardcoded, empty strings as default)
    BINANCE_API_KEY: Optional[str] = Field(default=None)
    BINANCE_API_SECRET: Optional[str] = Field(default=None)
    BYBIT_API_KEY: Optional[str] = Field(default=None)
    BYBIT_API_SECRET: Optional[str] = Field(default=None)

    # Alerts
    TELEGRAM_BOT_TOKEN: Optional[str] = Field(default=None)
    TELEGRAM_CHAT_ID: Optional[str] = Field(default=None)

    @field_validator("LIVE_TRADING_ENABLED", mode="after")
    @classmethod
    def validate_live_guard(cls, v: bool, info) -> bool:
        trading_mode = info.data.get("TRADING_MODE")
        if trading_mode == TradingMode.LIVE and not v:
            raise ValueError("LIVE trading mode requires LIVE_TRADING_ENABLED=True explicitly.")
        return v


def get_settings() -> AppSettings:
    return AppSettings()
