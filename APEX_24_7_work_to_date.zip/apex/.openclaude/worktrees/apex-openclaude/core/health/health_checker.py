from enum import Enum
from typing import Dict, Any, Optional
from datetime import datetime, timezone
from pydantic import BaseModel, Field


class HealthStatus(str, Enum):
    HEALTHY = "HEALTHY"
    DEGRADED = "DEGRADED"
    UNHEALTHY = "UNHEALTHY"


class ComponentHealth(BaseModel):
    status: HealthStatus
    details: Dict[str, Any] = Field(default_factory=dict)
    checked_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class HealthRegistry:
    def __init__(self) -> None:
        self._components: Dict[str, ComponentHealth] = {}

    def register(self, name: str, status: HealthStatus, details: Optional[Dict[str, Any]] = None) -> None:
        self._components[name] = ComponentHealth(
            status=status,
            details=details or {},
            checked_at=datetime.now(timezone.utc)
        )

    def get_status(self) -> Dict[str, Any]:
        overall = HealthStatus.HEALTHY
        for comp in self._components.values():
            if comp.status == HealthStatus.UNHEALTHY:
                overall = HealthStatus.UNHEALTHY
                break
            if comp.status == HealthStatus.DEGRADED:
                overall = HealthStatus.DEGRADED

        return {
            "status": overall.value,
            "components": {k: v.model_dump(mode="json") for k, v in self._components.items()},
            "timestamp": datetime.now(timezone.utc).isoformat()
        }


health_registry = HealthRegistry()
