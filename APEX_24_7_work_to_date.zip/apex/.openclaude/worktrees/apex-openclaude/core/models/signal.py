from enum import Enum
from typing import Optional, List
from datetime import datetime, timezone
from pydantic import Field
from core.models.base import ApexBaseModel


class SignalDirection(str, Enum):
    LONG = "LONG"
    SHORT = "SHORT"


class SignalStatus(str, Enum):
    PENDING_RISK = "PENDING_RISK"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    EXECUTED = "EXECUTED"
    CANCELLED = "CANCELLED"


class TradeSignal(ApexBaseModel):
    symbol: str
    exchange: str = "BINANCE"
    timeframe: str
    direction: SignalDirection
    setup_name: str
    entry_min: float
    entry_max: float
    stop_loss: float
    take_profit: float
    risk_reward_ratio: float
    confidence: float = Field(ge=0.0, le=1.0)
    confluence_score: float = Field(ge=0.0, le=100.0)
    regime: str
    reasons: List[str] = Field(default_factory=list)
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
