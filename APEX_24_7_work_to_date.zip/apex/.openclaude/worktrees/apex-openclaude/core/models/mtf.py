from enum import Enum
from typing import Optional, List
from core.models.base import ApexBaseModel


class TimeframeBias(str, Enum):
    BULLISH = "BULLISH"
    BEARISH = "BEARISH"
    NEUTRAL = "NEUTRAL"


class MTFConfluenceReport(ApexBaseModel):
    symbol: str
    bias_4h: TimeframeBias
    bias_1h: TimeframeBias
    regime_15m: str
    rvol_15m: float
    rsi_15m: float
    is_fully_aligned: bool
    confluence_score: float
    reasons: List[str]
