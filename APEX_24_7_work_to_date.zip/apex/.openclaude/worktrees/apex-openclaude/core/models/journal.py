from datetime import datetime, timezone
from typing import List, Optional
from core.models.base import ApexBaseModel


class TradeJournalEntry(ApexBaseModel):
    client_order_id: str
    symbol: str
    direction: str
    setup_name: str
    entry_price: float
    exit_price: float
    quantity: float
    realized_pnl: float
    risk_reward_achieved: float
    exit_reason: str
    confluence_reasons: List[str]
    entry_time: datetime
    exit_time: datetime
