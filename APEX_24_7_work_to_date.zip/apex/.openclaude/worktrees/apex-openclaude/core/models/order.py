import uuid
from enum import Enum
from typing import Optional
from datetime import datetime, timezone
from pydantic import Field
from core.models.base import ApexBaseModel


class OrderSide(str, Enum):
    BUY = "BUY"
    SELL = "SELL"


class OrderType(str, Enum):
    LIMIT = "LIMIT"
    MARKET = "MARKET"
    STOP_MARKET = "STOP_MARKET"


class OrderStatus(str, Enum):
    CREATED = "CREATED"
    SUBMITTED = "SUBMITTED"
    FILLED = "FILLED"
    PARTIALLY_FILLED = "PARTIALLY_FILLED"
    CANCELLED = "CANCELLED"
    REJECTED = "REJECTED"
    EXPIRED = "EXPIRED"


class OrderRequest(ApexBaseModel):
    symbol: str
    exchange: str = "BINANCE"
    side: OrderSide
    order_type: OrderType = OrderType.LIMIT
    quantity: float = Field(gt=0.0)
    price: Optional[float] = None
    stop_loss: Optional[float] = None
    take_profit: Optional[float] = None
    client_order_id: str = Field(default_factory=lambda: f"apex_{uuid.uuid4().hex[:12]}")
    reduce_only: bool = False
    leverage: int = Field(default=1, ge=1)
    dedup_key: Optional[str] = None


class OrderResult(ApexBaseModel):
    client_order_id: str
    exchange_order_id: Optional[str] = None
    symbol: str
    side: OrderSide
    order_type: OrderType
    status: OrderStatus
    requested_quantity: float
    executed_quantity: float = 0.0
    avg_fill_price: float = 0.0
    fee: float = 0.0
    message: Optional[str] = None
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class PendingOrderRecord(ApexBaseModel):
    client_order_id: str
    symbol: str
    side: OrderSide
    dedup_key: Optional[str] = None
    created_timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class Position(ApexBaseModel):
    symbol: str
    exchange: str = "BINANCE"
    side: OrderSide
    quantity: float
    entry_price: float
    mark_price: float
    stop_loss: Optional[float] = None
    take_profit: Optional[float] = None
    leverage: int = 1
    unrealized_pnl: float = 0.0
    realized_pnl: float = 0.0
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
