from datetime import datetime, timezone
from typing import Optional
from pydantic import Field
from core.models.base import ApexBaseModel


class SymbolInfo(ApexBaseModel):
    symbol: str
    base_asset: str
    quote_asset: str
    status: str
    min_qty: float
    step_size: float
    tick_size: float
    min_notional: float
    is_trading: bool = True


class Candle(ApexBaseModel):
    symbol: str
    exchange: str = "BINANCE"
    timeframe: str
    open_time: datetime
    close_time: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float
    quote_volume: float
    trades_count: int = 0
    is_closed: bool = True


class MarkPriceData(ApexBaseModel):
    symbol: str
    mark_price: float
    index_price: float
    estimated_settle_price: Optional[float] = None
    funding_rate: float
    next_funding_time: datetime
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class OpenInterestData(ApexBaseModel):
    symbol: str
    open_interest: float
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
